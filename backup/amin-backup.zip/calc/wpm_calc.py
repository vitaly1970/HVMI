#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""wpm_calc.py — расчёт продукта «Позиционирование участников» (wpm), промпт v7.0.

Считает четыре оси загрузки риска, ведёт журнал значений и отдаёт out/calc.json
по схеме раздела 7 промпта. Веса ядра 2 / 2 / 3 / 3:
  загрузка риска      — место чистой длинной позиции управляющих активами
                        в S&P 500 за десять лет;
  свободный капитал   — доля наличных у управляющих, 6,0 % → 0, 3,0 % → 100;
  механический риск   — загрузка фондов следования тренду, шкала −1…+1 → 0…100;
  позиция маркет-мейкеров — близость цены к точке смены знака.

Каждое число проходит через журнал out/channels.jsonl с источником и датой:
величина без записи в журнале дальше не передаётся (раздел 1 промпта).

Доля наличных у управляющих приходит файлом --spot: ряда в свободном
доступе нет, значение месячное и берётся точечно из публикаций.

Запуск:
    python3 wpm_calc.py --cutoff 2026-08-21 --data data --out out --spot spot.json
"""

import argparse, csv, gzip, io, json, math, os, re, statistics, sys, time, zipfile
import datetime as dt
import urllib.request, urllib.error, urllib.parse

BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/126 Safari/537.36")
YAHOO = "https://query1.finance.yahoo.com/v8/finance/chart/%s?range=%s&interval=1d"
COT_TFF = "https://www.cftc.gov/files/dea/history/fut_fin_txt_%d.zip"
CBOE_CHAIN = "https://cdn.cboe.com/api/global/delayed_quotes/options/%s.json"
FINRA_MARGIN = "https://www.finra.org/sites/default/files/2021-03/margin-statistics.xlsx"
FRED_CSV = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=%s"

# Журнал значений. Классом из набора amin-data, если он рядом; иначе — своя
# запись того же вида, чтобы модуль работал и вне прогона.
try:
    from amin_run import Log
except Exception:
    class Log(object):
        def __init__(self, out="out", code=None, cutoff=None):
            self.path = os.path.join(out, "channels.jsonl")
            self.code, self.cutoff = code, str(cutoff)[:10] if cutoff else None
            os.makedirs(out, exist_ok=True); open(self.path, "a").close()
        def _w(self, rec):
            rec["ts"] = dt.datetime.now().isoformat(timespec="seconds")
            if self.code: rec["продукт"] = self.code
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            return rec
        def get(self, channel, url="", ok=True, note=""):
            return self._w({"вид": "обращение", "канал": channel, "адрес": url,
                            "успех": bool(ok), "пометка": note})
        def series(self, key, channel, last_date="", points=0, note="", layer="быстрый"):
            return self._w({"вид": "ряд", "показатель": key, "канал": channel,
                            "последняя_дата": str(last_date)[:10], "слой": layer,
                            "точек": int(points), "пометка": note})
        def value(self, key, value, source, date, unit="", note=""):
            return self._w({"вид": "значение", "показатель": key, "значение": value,
                            "источник": source, "дата": str(date)[:10],
                            "единица": unit, "пометка": note})
        def gap(self, key, channels=(), reason=""):
            return self._w({"вид": "пробел", "показатель": key,
                            "опрошено": list(channels), "причина": reason})
        def note(self, text):
            return self._w({"вид": "пометка", "текст": text})

WEIGHTS = {"загрузка_риска": 2, "свободный_капитал": 2,
           "механический_риск": 3, "дилерская_гамма": 3}
SECTORS = ["XLK", "XLF", "XLV", "XLY", "XLP", "XLE", "XLI", "XLB", "XLU",
           "XLRE", "XLC"]
WINDOW_DAYS = 3652
MA_WEIGHTS = [(20, 0.2), (50, 0.3), (100, 0.2), (200, 0.3)]   # Р.1, систематики


def http(url, tries=5, binary=False, timeout=90, ua=None):
    delay = 1.0
    for _ in range(tries):
        req = urllib.request.Request(url, headers={"User-Agent": ua or BROWSER_UA,
                                                   "Accept-Encoding": "gzip"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read()
                if r.headers.get("Content-Encoding") == "gzip":
                    raw = gzip.decompress(raw)
            return raw if binary else raw.decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            if e.code in (429, 403, 503):
                time.sleep(delay); delay = min(delay * 2, 20); continue
            return None
        except Exception:
            time.sleep(delay); delay = min(delay * 2, 20)
    return None


def cached(path, fn, binary=False):
    if os.path.exists(path):
        return open(path, "rb").read() if binary else open(path, encoding="utf-8").read()
    data = fn()
    if data is None:
        return None
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    mode = "wb" if binary else "w"
    with open(path, mode, encoding=None if binary else "utf-8") as f:
        f.write(data)
    return data


# ------------------------------------------------------------------ цены

def yahoo(ticker, data_dir, rng="15y"):
    safe = ticker.replace("^", "_")
    txt = cached(os.path.join(data_dir, "y_%s.json" % safe),
                 lambda: http(YAHOO % (urllib.parse.quote(ticker), rng)))
    if not txt:
        return {}
    try:
        res = json.loads(txt)["chart"]["result"][0]
    except Exception:
        return {}
    out = {}
    for t, c in zip(res.get("timestamp") or [], res["indicators"]["quote"][0].get("close") or []):
        if c is not None:
            out[dt.date.fromtimestamp(t)] = float(c)
    return out


# --------------------------------------------------- отчёт о позициях (COT)

def cot_series(cutoff, data_dir, market="S&P 500 Consolidated"):
    """Чистая позиция управляющих активами и фондов с плечом по неделям."""
    out = {}
    for year in range(cutoff.year - 11, cutoff.year + 1):
        path = os.path.join(data_dir, "cot_%d.zip" % year)
        if not os.path.exists(path):
            blob = http(COT_TFF % year, binary=True)
            if blob is None:
                continue
            open(path, "wb").write(blob)
        try:
            z = zipfile.ZipFile(path)
        except zipfile.BadZipFile:
            continue
        name = z.namelist()[0]
        with z.open(name) as f:
            for r in csv.reader(io.TextIOWrapper(f, "utf-8", "replace")):
                if len(r) < 20 or market.lower() not in r[0].lower():
                    continue
                d = _date_any(r[2])
                if not d or d > cutoff:
                    continue
                try:
                    oi = float(r[7])
                    am_long, am_short = float(r[11]), float(r[12])
                    lev_long, lev_short = float(r[14]), float(r[15])
                except (ValueError, IndexError):
                    continue
                if oi <= 0:
                    continue
                out[d] = {"открытый_интерес": oi,
                          "управляющие_нетто_доля": 100.0 * (am_long - am_short) / oi,
                          "плечевые_нетто_доля": 100.0 * (lev_long - lev_short) / oi}
    return out


def _date_any(s):
    s = (s or "").strip().strip('"')
    for f in ("%Y-%m-%d", "%m/%d/%Y", "%Y%m%d"):
        try:
            return dt.datetime.strptime(s[:10], f).date()
        except Exception:
            continue
    return None


# ------------------------------------------------------- нормализация Р.2


def finra_margin(data_dir, log=None):
    """Маржинальный долг и свободные средства на счетах, месячный ряд FINRA."""
    path = os.path.join(data_dir, "margin-statistics.xlsx")
    if not os.path.exists(path):
        blob = http(FINRA_MARGIN, binary=True)
        if log:
            log.get("FINRA маржа", FINRA_MARGIN, ok=bool(blob))
        if not blob:
            return {}
        os.makedirs(data_dir, exist_ok=True)
        open(path, "wb").write(blob)
    # Лист читается без сторонних библиотек: xlsx — это zip с XML.
    try:
        z = zipfile.ZipFile(path)
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            sx = z.read("xl/sharedStrings.xml").decode("utf-8", "replace")
            shared = re.findall(r"<t[^>]*>(.*?)</t>", sx, re.S)
        sheet = z.read("xl/worksheets/sheet1.xml").decode("utf-8", "replace")
    except Exception:
        return {}

    rows = []
    for row in re.findall(r"<row[^>]*>(.*?)</row>", sheet, re.S):
        cells = []
        for c in re.findall(r'<c[^>]*?(?:\\s+t="(\\w+)")?[^>]*>(?:<v>(.*?)</v>|<is><t[^>]*>(.*?)</t></is>)?</c>', row, re.S):
            typ, v, inline = c
            if inline:
                cells.append(inline)
            elif typ == "s" and v.isdigit() and int(v) < len(shared):
                cells.append(shared[int(v)])
            else:
                cells.append(v)
        rows.append(cells)

    out = {}
    for r in rows:
        if not r or not r[0]:
            continue
        m = re.match(r"^(\d{4})-(\d{2})$", str(r[0]).strip())
        if not m:
            continue
        nums = []
        for x in r[1:5]:
            try:
                nums.append(float(x))
            except (TypeError, ValueError):
                nums.append(None)
        key = "%s-%s" % (m.group(1), m.group(2))
        out[key] = {"долг": nums[0] if nums else None,
                    "свободные": sum(v for v in nums[1:3] if v) or None}
    if log and out:
        last = max(out)
        log.series("маржинальный_долг", "FINRA:margin-statistics", last + "-01",
                   len(out), layer="медленный")
    return out


def fred_series(series_id, data_dir, log=None, tries=3):
    """Месячный ряд FRED в виде «дата → значение»."""
    url = FRED_CSV % series_id
    path = os.path.join(data_dir, "fred_%s.csv" % series_id)
    text = None
    if os.path.exists(path):
        text = open(path, encoding="utf-8", errors="replace").read()
    else:
        for _ in range(tries):
            # Ловушка канала: на браузерный заголовок FRED отвечает 503,
            # на заголовок curl отдаёт файл. Проверено 26.08.2026.
            blob = http(url, tries=1, ua="curl/8.5.0")
            if blob:
                text = blob if isinstance(blob, str) else blob.decode("utf-8", "replace")
                os.makedirs(data_dir, exist_ok=True)
                open(path, "w", encoding="utf-8").write(text)
                break
            time.sleep(1.5)
    if log:
        log.get("FRED:" + series_id, url, ok=bool(text))
    if not text:
        return {}
    out = {}
    for row in csv.reader(io.StringIO(text)):
        if len(row) < 2:
            continue
        d = _date_any(row[0])
        try:
            v = float(row[1])
        except (ValueError, TypeError):
            continue
        if d:
            out[d] = v
    if log and out:
        last = max(out)
        log.series(series_id, "FRED:" + series_id, last, len(out), layer="медленный")
    return out


def percentile(values, value, window_points=None):
    xs = list(values)
    if window_points:
        xs = xs[-window_points:]
    if len(xs) < 20:
        return None
    return 100.0 * sum(1 for x in xs if x < value) / len(xs)


def series_window(series, cutoff, days=WINDOW_DAYS):
    lo = cutoff - dt.timedelta(days=days)
    return [series[d] for d in sorted(series) if lo <= d <= cutoff]


# ------------------------------------------ загрузка фондов следования тренду

def trend_exposure(px, cutoff):
    """Сигнал по средним 20/50/100/200 с весами, нормировка на волатильность."""
    ds = sorted(d for d in px if d <= cutoff)
    if len(ds) < 260:
        return None, None
    vals = [px[d] for d in ds]
    last = vals[-1]
    sig, levels = 0.0, []
    for n, w in MA_WEIGHTS:
        ma = sum(vals[-n:]) / n
        levels.append((n, ma))
        sig += w * (1.0 if last > ma else -1.0)
    rets = [vals[i] / vals[i - 1] - 1 for i in range(-63, 0)]
    vol = statistics.pstdev(rets) * math.sqrt(252)
    scale = min(1.0, 0.15 / vol) if vol > 0 else 1.0
    expo = max(-1.0, min(1.0, sig * scale))
    below = [ma for _, ma in levels if ma < last]
    return round(expo, 3), (round(max(below), 1) if below else None)


# ---------------------------------------------------------- дилерская гамма

def _monthly(exp):
    """Месячный срок исполнения — третья пятница месяца."""
    return exp.weekday() == 4 and 15 <= exp.day <= 21


def dealer_gamma(symbol, data_dir, spot_hint=None, cutoff=None, horizon_days=90):
    """Профиль гаммы по опционной цепочке: снимок дня, истории у канала нет.

    Считаются только МЕСЯЧНЫЕ сроки (третья пятница) в пределах 90 дней от среза.
    Проверено 18.08.2026 перебором: на полном наборе сроков накопленная сумма
    нигде не меняет знак и точки смены знака не существует; однодневные и
    недельные контракты перевешивают профиль. Месячный набор до 90 дней даёт
    осмысленный профиль с точкой смены знака."""
    txt = cached(os.path.join(data_dir, "chain_%s.json" % symbol.strip("_")),
                 lambda: http(CBOE_CHAIN % symbol, timeout=180))
    if not txt:
        return None
    try:
        d = json.loads(txt)["data"]
    except Exception:
        return None
    spot = d.get("current_price") or spot_hint
    if not spot:
        return None
    by_strike = {}
    total = 0.0
    for o in d.get("options", []):
        name = o.get("option", "")
        m = re.search(r"[A-Z]+(\d{6})([CP])(\d{8})$", name)
        if not m:
            continue
        y, mo, dd = m.group(1)[:2], m.group(1)[2:4], m.group(1)[4:6]
        try:
            exp = dt.date(2000 + int(y), int(mo), int(dd))
        except ValueError:
            continue
        if not _monthly(exp):
            continue
        if cutoff and (exp - cutoff).days > horizon_days:
            continue
        strike = int(m.group(3)) / 1000.0
        kind = m.group(2)
        gamma = o.get("gamma") or 0.0
        oi = o.get("open_interest") or 0
        if not gamma or not oi:
            continue
        contrib = gamma * oi * 100 * spot * spot * 0.01
        contrib = contrib if kind == "C" else -contrib
        by_strike[strike] = by_strike.get(strike, 0.0) + contrib
        total += contrib
    if not by_strike:
        return None
    ks = sorted(by_strike)
    run, flip = 0.0, None
    for k in ks:
        prev = run
        run += by_strike[k]
        if prev < 0 <= run or prev > 0 >= run:
            flip = k
    walls = sorted(by_strike.items(), key=lambda kv: -abs(kv[1]))[:3]
    return {"цена": spot, "гамма_млрд": round(total / 1e9, 1),
            "точка_смены_знака": flip,
            "скопления": [k for k, _ in walls]}


# ------------------------------------------------------------ Р.9 и Р.10

def forced_cluster(spx, gld, tlt, cutoff, look=10):
    ds = [d for d in sorted(spx) if d <= cutoff][-(look + 1):]
    hits = []
    for i in range(1, len(ds)):
        d, p = ds[i], ds[i - 1]
        if all(s.get(d) is not None and s.get(p) is not None and s[d] < s[p]
               for s in (spx, gld, tlt)):
            hits.append(d)
    return {"сессий": len(hits), "активен": len(hits) >= 2,
            "даты": [d.isoformat() for d in hits]}


def sector_epicenter(sectors, spx, cutoff, years=5):
    lo = cutoff - dt.timedelta(days=365 * years)
    ds = [d for d in sorted(spx) if lo <= d <= cutoff]
    days = []
    for i in range(1, len(ds)):
        d, p = ds[i], ds[i - 1]
        if spx[d] < spx[p]:
            days.append((d, p))
    out = {}
    for t, s in sectors.items():
        devs = []
        for d, p in days:
            if d in s and p in s and spx[p]:
                devs.append(100 * ((s[d] / s[p] - 1) - (spx[d] / spx[p] - 1)))
        if len(devs) >= 5:
            out[t] = round(statistics.median(devs), 3)
    return out


# ---------------------------------------------------------------- Р.8

def score(axes):
    num = den = 0.0
    for k, w in WEIGHTS.items():
        v = axes.get(k)
        if v is None:
            continue
        num += v * w
        den += w
    if den == 0:
        return None, 0.0
    return round(num / den, 1), round(100.0 * den / sum(WEIGHTS.values()), 1)


def run(cutoff, data_dir, out_dir, spot=None, skip_fetch=False, prev=None):
    os.makedirs(out_dir, exist_ok=True)
    spot = spot or {}
    log = Log(out_dir, code="wpm", cutoff=cutoff)
    res = {"срез": cutoff.isoformat(), "оси": {}, "показатели": {}}
    gaps = []

    spx = yahoo("^GSPC", data_dir)
    gld = yahoo("GLD", data_dir)
    tlt = yahoo("TLT", data_dir)
    for name, ser in (("^GSPC", spx), ("GLD", gld), ("TLT", tlt)):
        if ser:
            log.series("цена:" + name, "Yahoo:" + name, max(ser), len(ser))

    # Ось 1 — загрузка риска: место чистой длинной позиции управляющих активами.
    # Отдельно берётся Nasdaq-100: фонды с плечом стоят там иначе, и промпт
    # требует обе величины в выход.
    cot = cot_series(cutoff, data_dir)
    cot_ndx = cot_series(cutoff, data_dir, market="Nasdaq-100 Consolidated")
    if cot:
        last = max(cot)
        days = sorted(cot)
        vals = [cot[d]["управляющие_нетто_доля"] for d in days]
        p = percentile(vals, cot[last]["управляющие_нетто_доля"], window_points=522)
        prev_d = days[-2] if len(days) > 1 else None
        res["показатели"]["управляющие_нетто_доля"] = round(cot[last]["управляющие_нетто_доля"], 1)
        if prev_d:
            res["показатели"]["управляющие_нетто_доля_пред"] = round(cot[prev_d]["управляющие_нетто_доля"], 1)
        res["показатели"]["дата_отчёта_о_позициях"] = last.isoformat()
        if p is not None:
            res["показатели"]["управляющие_место_в_истории"] = round(p, 1)
            res["оси"]["загрузка_риска"] = round(p, 1)
        # Отчёт выходит в пятницу по состоянию на вторник: у ряда собственный
        # лаг публикации, и порогом быстрого слоя он не проверяется.
        log.series("позиции управляющих S&P 500", "CFTC:fut_fin_txt", last, len(days),
                   layer="медленный", note="недельный слой, лаг публикации три дня")
        log.value("управляющие_нетто_доля", res["показатели"]["управляющие_нетто_доля"],
                  "CFTC Traders in Financial Futures", last, unit="% ОИ")
    else:
        gaps.append("позиции управляющих")
        log.gap("управляющие_нетто_доля", ["CFTC:fut_fin_txt"], "архив не отдал строк рынка")

    if cot_ndx:
        lastn = max(cot_ndx)
        daysn = sorted(cot_ndx)
        valsn = [cot_ndx[d]["плечевые_нетто_доля"] for d in daysn]
        pn = percentile(valsn, cot_ndx[lastn]["плечевые_нетто_доля"], window_points=522)
        res["показатели"]["плечевые_нетто_доля_ndx"] = round(cot_ndx[lastn]["плечевые_нетто_доля"], 1)
        if len(daysn) > 1:
            res["показатели"]["плечевые_нетто_доля_ndx_пред"] = round(cot_ndx[daysn[-2]]["плечевые_нетто_доля"], 1)
        if pn is not None:
            res["показатели"]["плечевые_место_в_истории"] = round(pn, 1)
        log.value("плечевые_нетто_доля_ndx", res["показатели"]["плечевые_нетто_доля_ndx"],
                  "CFTC Traders in Financial Futures", lastn, unit="% ОИ")
    else:
        gaps.append("позиции фондов с плечом по Nasdaq-100")
        log.gap("плечевые_нетто_доля_ndx", ["CFTC:fut_fin_txt"],
                "рынок Nasdaq-100 Consolidated не найден в архиве")

    # Ось 2 — свободный капитал: доля наличных у управляющих, 6,0 % → 0, 3,0 % → 100.
    cash_rec = spot.get("кэш_управляющих") or {}
    cash = cash_rec.get("значение")
    if cash is not None:
        res["оси"]["свободный_капитал"] = round(max(0.0, min(100.0,
                                                             (6.0 - float(cash)) / 3.0 * 100)), 1)
        res["показатели"]["кэш_управляющих"] = cash
        log.value("кэш_управляющих", cash, cash_rec.get("источник", "опрос управляющих"),
                  cash_rec.get("дата", ""), unit="%")
    else:
        gaps.append("доля наличных у управляющих")
        log.gap("кэш_управляющих", ["опрос BofA Global Fund Manager Survey"],
                "ряда в свободном доступе нет, точечное значение не подано")

    # Ось 3 — механический риск: загрузка фондов следования тренду.
    expo, level = trend_exposure(spx, cutoff)
    d0 = max(d for d in spx if d <= cutoff) if spx else None
    if expo is not None:
        res["оси"]["механический_риск"] = round((expo + 1) / 2 * 100, 1)
        res["показатели"]["загрузка_следования_тренду"] = expo
        res["показатели"]["уровень_разворота"] = level
        if d0 and level:
            res["показатели"]["запас_до_разворота_проц"] = round(
                (spx[d0] - level) / spx[d0] * 100, 2)
        log.value("загрузка_следования_тренду", expo, "расчёт по ценам Yahoo", d0, unit="−1…+1")
    else:
        gaps.append("загрузка_следования_тренду")
        log.gap("загрузка_следования_тренду", ["Yahoo:^GSPC"],
                "ряд индекса не собран, загрузка не считается")

    if d0:
        res["показатели"]["цена_индекса"] = round(spx[d0], 2)
        wk = [d for d in spx if d <= cutoff - dt.timedelta(days=7)]
        if wk:
            base = spx[max(wk)]
            res["показатели"]["изменение_за_неделю_проц"] = round((spx[d0] - base) / base * 100, 2)
        log.value("цена_индекса", res["показатели"]["цена_индекса"], "Yahoo:^GSPC", d0, unit="пункт")
    else:
        gaps.append("цена_индекса")
        log.gap("цена_индекса", ["Yahoo:^GSPC"], "котировка индекса на срез не получена")

    # Ось 4 — позиция маркет-мейкеров: близость цены к точке смены знака.
    g = dealer_gamma("_SPX", data_dir, spot_hint=spx[d0] if d0 else None,
                     cutoff=cutoff) if not skip_fetch else None
    if g and g.get("точка_смены_знака"):
        dist = abs(g["цена"] - g["точка_смены_знака"]) / g["цена"] * 100
        res["оси"]["дилерская_гамма"] = round(max(0.0, 100 - 10 * dist), 1)
        res["показатели"]["гамма"] = g
        res["показатели"]["расстояние_до_смены_знака_проц"] = round(dist, 2)
        log.value("точка_смены_знака", g["точка_смены_знака"], "CBOE опционная цепочка _SPX",
                  cutoff, unit="страйк", note="канал без истории: снимок текущего дня")
    else:
        gaps.append("опционный профиль")
        log.gap("точка_смены_знака", ["CBOE:_SPX"], "цепочка не дала точки смены знака")

    res["оценка"], res["покрытие"] = score(res["оси"])
    res["чувствительность"] = {}
    for k in list(res["оси"]):
        sub = dict(res["оси"]); sub.pop(k)
        res["чувствительность"][k] = score(sub)[0]

    # Медленный слой: маржинальный долг, свободные деньги на счетах, денежные фонды.
    marg = finra_margin(data_dir, log)
    if marg:
        keys = sorted(marg)
        cur = keys[-1]
        res["показатели"]["маржинальный_долг_млн"] = marg[cur]["долг"]
        if marg[cur]["свободные"]:
            res["показатели"]["свободные_деньги_на_счетах_млн"] = marg[cur]["свободные"]
        if len(keys) > 1 and marg[keys[-2]]["долг"]:
            res["показатели"]["маржинальный_долг_месяц_назад_млн"] = marg[keys[-2]]["долг"]
        if len(keys) > 12 and marg[keys[-13]]["долг"]:
            res["показатели"]["маржинальный_долг_год_назад_млн"] = marg[keys[-13]]["долг"]
        log.value("маржинальный_долг_млн", marg[cur]["долг"], "FINRA margin statistics",
                  cur + "-01", unit="млн долл.")
    else:
        gaps.append("маржинальная статистика")
        log.gap("маржинальный_долг_млн", ["FINRA:margin-statistics"], "файл не получен")

    mmf = fred_series("RMFSL", data_dir, log)
    if mmf:
        last_m = max(mmf)
        res["показатели"]["денежные_фонды_розницы_млрд"] = round(mmf[last_m], 1)
        log.value("денежные_фонды_розницы_млрд", round(mmf[last_m], 1), "FRED:RMFSL",
                  last_m, unit="млрд долл.")
    else:
        gaps.append("денежные фонды розницы")
        log.gap("денежные_фонды_розницы_млрд", ["FRED:RMFSL"], "канал не ответил за три попытки")

    res["кластер_вынужденных_продаж"] = forced_cluster(spx, gld, tlt, cutoff)
    log.value("кластер_вынужденных_продаж",
              res["кластер_вынужденных_продаж"]["сессий"], "расчёт по ценам Yahoo",
              cutoff, unit="сессий из 10")
    res["секторный_эпицентр"] = None
    if res["кластер_вынужденных_продаж"]["активен"]:
        sect = {t: yahoo(t, data_dir) for t in SECTORS}
        res["секторный_эпицентр"] = sector_epicenter(sect, spx, cutoff)

    # Наблюдение активных менеджеров с августа 2026 года платное, ряд не берётся.
    for key, chans, why in (
            ("наблюдение NAAIM", ["NAAIM"], "выгрузка отдаёт страницу входа, доступ платный"),
            ("короткие продажи", ["FINRA короткие продажи"], "срез конца месяца ещё не опубликован")):
        gaps.append(key)
        log.gap(key, chans, why)

    res["пробелы"] = gaps
    res["снимок_прошлого_прогона"] = prev or {}

    # Схема не допускает пустых значений: неполученное живёт в «пробелах».
    res["показатели"] = {k: v for k, v in res["показатели"].items() if v is not None}
    res["оси"] = {k: v for k, v in res["оси"].items() if v is not None}
    if res["секторный_эпицентр"] is None:
        res.pop("секторный_эпицентр")

    json.dump(res, open(os.path.join(out_dir, "calc.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutoff", required=True)
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="out")
    ap.add_argument("--spot", default=None)
    ap.add_argument("--skip-fetch", action="store_true")
    ap.add_argument("--prev", default=None,
                    help="файл со снимком прошлого прогона")
    a = ap.parse_args()
    cut = dt.datetime.strptime(a.cutoff, "%Y-%m-%d").date()
    spot = json.load(open(a.spot, encoding="utf-8")) if a.spot and os.path.exists(a.spot) else {}
    prev = json.load(open(a.prev, encoding="utf-8")) if a.prev and os.path.exists(a.prev) else None
    r = run(cut, a.data, a.out, spot, a.skip_fetch, prev)
    for k, v in r["оси"].items():
        print("%-20s %s" % (k, v))
    print("оценка %s, покрытие %s %%" % (r["оценка"], r["покрытие"]))
    print("кластер: %(сессий)s из 10, активен: %(активен)s" % r["кластер_вынужденных_продаж"])


if __name__ == "__main__":
    main()
