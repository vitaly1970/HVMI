#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""mh_charts.py — шесть графиков выпуска «Здоровье рынка» одним запуском.

Строит строго из рядов прогона (out/series.pkl и out/calc.json), сам ничего
не считает и не досчитывает. Построитель — `charts.band_series` скилла
report-format: зоны по оси значений, пунктир порога, серое прошлое и акцент
на последнем квартале.

    python3 mh_charts.py --out out --build build [--skill <путь к assets>]
"""

import argparse, json, os, pickle, sys
import numpy as np
import pandas as pd

SKILL = "/mnt/skills/user/report-format/assets"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="out")
    ap.add_argument("--build", default="build")
    ap.add_argument("--skill", default=SKILL)
    a = ap.parse_args()
    os.makedirs(a.build, exist_ok=True)
    sys.path.insert(0, a.skill)
    import matplotlib
    matplotlib.use("Agg")
    import charts as ch

    calc = json.load(open(os.path.join(a.out, "calc.json"), encoding="utf-8"))
    ser = pickle.load(open(os.path.join(a.out, "series.pkl"), "rb"))
    cut = calc["срез"]
    date_ru = pd.Timestamp(cut).strftime("%d.%m.%Y")
    made = []

    def num(x, n=1):
        return ("%.*f" % (n, float(x))).replace(".", ",")

    def five_years(s):
        return s[s.index >= s.index[-1] - pd.Timedelta(days=365 * 5)]

    # 1 — Score с фоновыми зонами пятых частей истории
    sc = ser["score"]
    bounds = [float(np.percentile(sc, p)) for p in (20, 40, 60, 80)]
    zones = [(float(sc.min()), bounds[0], "red"),
             (bounds[0], bounds[1], "gold"),
             (bounds[1], bounds[2], "muted"),
             (bounds[2], bounds[3], "green"),
             (bounds[3], float(sc.max()), "green")]
    ch.band_series(os.path.join(a.build, "c1_score.png"),
                   sc.index.to_pydatetime(), sc.to_numpy(float),
                   "Здоровье рынка, оценка 0–100: %s на %s"
                   % (num(calc["score"]), date_ru),
                   recent=63, zones=zones, ylabel="оценка")
    made.append("c1_score.png")

    # 2 — доля бумаг выше 200-дневной средней
    a2 = ser["above200"]
    ch.band_series(os.path.join(a.build, "c2_above200.png"),
                   a2.index.to_pydatetime(), a2.to_numpy(float),
                   "Доля бумаг S&P 500 выше 200-дневной средней, %%: %s на %s"
                   % (num(calc["компоненты"]["above200"]["значение"]), date_ru),
                   recent=63, ylabel="%",
                   threshold=(20, "порог T1: капитуляция ширины"))
    made.append("c2_above200.png")

    # 3 — равный вес против капвзвешенного, коридор ±2σ и порог T6
    e = five_years(ser["EQW"].dropna())
    b = ser["band_EQW"]
    lo = b["lo"].reindex(e.index).to_numpy(float)
    hi = b["hi"].reindex(e.index).to_numpy(float)
    ch.band_series(os.path.join(a.build, "c3_eqw.png"),
                   e.index.to_pydatetime(), e.to_numpy(float),
                   "Равновзвешенный S&P 500 к капвзвешенному (RSP/SPY): "
                   "%s на %s" % (num(e.iloc[-1], 3), date_ru),
                   recent=63, band=(lo, hi), ylabel="отношение цен")
    made.append("c3_eqw.png")

    # 4 — имплайд-корреляция и имплайд-дисперсия двумя панелями
    for key, fname, ttl, yl in (
            ("COR3M", "c4a_cor3m.png",
             "Заложенная в опционах связь между бумагами (COR3M), пункты",
             "пункты"),
            ("DSPX", "c4b_dspx.png",
             "Заложенный в опционах разброс бумаг (DSPX), пункты", "пункты")):
        s = five_years(ser[key].dropna())
        ch.band_series(os.path.join(a.build, fname), s.index.to_pydatetime(),
                       s.to_numpy(float),
                       "%s: %s на %s" % (ttl, num(s.iloc[-1], 2), date_ru),
                       recent=63, ylabel=yl)
        made.append(fname)

    # 5 — высокая бета к низкой волатильности, коридор ±2σ и порог T5
    h = five_years(ser["HBLV"].dropna())
    b = ser["band_HBLV"]
    lo = b["lo"].reindex(h.index).to_numpy(float)
    hi = b["hi"].reindex(h.index).to_numpy(float)
    ch.band_series(os.path.join(a.build, "c5_hblv.png"),
                   h.index.to_pydatetime(), h.to_numpy(float),
                   "Высокая бета к низкой волатильности (SPHB/SPLV): %s на %s"
                   % (num(h.iloc[-1], 3), date_ru),
                   recent=63, band=(lo, hi), ylabel="отношение цен")
    made.append("c5_hblv.png")

    print("Графики собраны в %s: %s" % (a.build, ", ".join(made)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
