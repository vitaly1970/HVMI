#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""lead_fetch.py — цены для выпуска «Ротация секторов».

Качает дневные цены одиннадцати секторных фондов, двух опорных бумаг и
четырёх факторных фондов в каталог /home/claude/data, откуда их читают
lead_run.py и r_calc.py. Ключ платного канала берётся из amin_secrets:
в промпте и в модулях его больше нет.

Дата начала закреплена на 2018-01-01 и не пересчитывается: от неё живут
и текущий срез, и историческая проверка раздела R.

Запуск:
    python3 lead_fetch.py [--data /home/claude/data] [--start 2018-01-01]
"""

import argparse
import os
import sys
import time
import urllib.request

from amin_secrets import tiingo_url

СЕКТОРА = ["XLK", "XLF", "XLV", "XLY", "XLP", "XLE", "XLI", "XLB", "XLU", "XLRE", "XLC"]
ОПОРНЫЕ = ["SPY", "RSP"]
ФАКТОРНЫЕ = ["MTUM", "QUAL", "USMV", "VLUE"]
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36")


def fetch(ticker, data_dir, start, tries=3):
    url = tiingo_url(ticker, start)
    delay = 1.0
    for _ in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=90) as r:
                text = r.read().decode("utf-8", "replace")
            if "date" not in text.split("\n")[0]:
                return 0
            path = os.path.join(data_dir, ticker + ".csv")
            open(path, "w", encoding="utf-8").write(text)
            return len([l for l in text.split("\n") if l.strip()]) - 1
        except Exception:
            time.sleep(delay)
            delay = min(delay * 2, 10)
    return 0


def main():
    ap = argparse.ArgumentParser(description="Цены для «Ротации секторов»")
    ap.add_argument("--data", default="/home/claude/data")
    ap.add_argument("--start", default="2018-01-01")
    ap.add_argument("--only", default="", help="через запятую: качать только эти бумаги")
    a = ap.parse_args()
    os.makedirs(a.data, exist_ok=True)

    tickers = ([t.strip().upper() for t in a.only.split(",") if t.strip()]
               if a.only else СЕКТОРА + ОПОРНЫЕ + ФАКТОРНЫЕ)
    пусто = []
    for t in tickers:
        n = fetch(t, a.data, a.start)
        print("%-6s %5d точек" % (t, n) if n else "%-6s не получен" % t)
        if not n:
            пусто.append(t)
    if пусто:
        print("НЕ ПОЛУЧЕНЫ: " + ", ".join(пусто))
        sys.exit(1)
    print("готово: %d бумаг в %s" % (len(tickers), a.data))


if __name__ == "__main__":
    main()
