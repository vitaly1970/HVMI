#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""amin_secrets.py — ключи платных каналов, одно место на всю серию.

Ключ жил в трёх местах сразу: тридцатью повторениями в готовых адресах промпта
«Ротация секторов», строкой в промпте «Здоровье рынка» и строкой в его
расчётном модуле. Смена ключа означала правку всех трёх, и любая забытая
копия ломала прогон молча. Теперь значение хранится в настройках сайта, а
модули спрашивают его отсюда.

Порядок поиска, первое найденное побеждает:
  1. переменная окружения (TIINGO_KEY) — годится для разовой подмены;
  2. настройки сайта: GET /api/secret/tiingo под служебным секретом, который
     лежит в файле state-token рядом с модулями;
  3. файл ~/.amin/secrets.json вида {"tiingo": "…"} — на случай прогона
     без сети.

Значение из настроек сайта запоминается на время сессии: спрашивать его
на каждый адрес незачем.

Взять ключ:

    from amin_secrets import tiingo_key
    key = tiingo_key()
"""

import json
import os
import urllib.request

SITE = "https://www.americaninvestor.capital"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36")

_cache = {}


def _token():
    """Служебный секрет: рядом с модулями либо в переменной окружения."""
    env = os.environ.get("AMIN_STATE_TOKEN")
    if env:
        return env.strip()
    here = os.path.dirname(os.path.abspath(__file__))
    for path in (os.path.join(here, "state-token"),
                 os.path.join(os.getcwd(), "state-token")):
        if os.path.exists(path):
            return open(path, encoding="utf-8").read().strip()
    return None


def _from_site(name):
    tok = _token()
    if not tok:
        return None
    req = urllib.request.Request(SITE + "/api/secret/" + name,
                                 headers={"User-Agent": UA,
                                          "Authorization": "Bearer " + tok})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            body = json.loads(r.read().decode("utf-8", "replace"))
        return body.get("value") if body.get("ok") else None
    except Exception:
        return None


def _from_file(name):
    path = os.path.expanduser("~/.amin/secrets.json")
    if not os.path.exists(path):
        return None
    try:
        return (json.load(open(path, encoding="utf-8")) or {}).get(name)
    except Exception:
        return None


def secret(name, env_var=None):
    """Ключ по имени: окружение, настройки сайта, запасной файл."""
    if name in _cache:
        return _cache[name]
    value = os.environ.get(env_var or (name.upper() + "_KEY"))
    if not value:
        value = _from_site(name)
    if not value:
        value = _from_file(name)
    if not value:
        raise RuntimeError(
            "ключ %r не найден: задайте переменную окружения, положите его в "
            "настройки сайта (тогда его отдаст /api/secret/%s) или в "
            "~/.amin/secrets.json" % (name, name))
    _cache[name] = value
    return value


def tiingo_key():
    """Ключ канала цен Tiingo."""
    return secret("tiingo", "TIINGO_KEY")


def tiingo_url(ticker, start="2018-01-01"):
    """Готовый адрес дневных цен одной бумаги с подставленным ключом."""
    return ("https://api.tiingo.com/tiingo/daily/%s/prices"
            "?startDate=%s&format=csv&columns=date,adjClose&token=%s"
            % (ticker, start, tiingo_key()))
