#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""amin_store — склад рабочих файлов продукта в хранилище на сайте.

Задача: расчётный модуль, построитель графиков и скрипт сборки не должны
переписываться каждым прогоном. Рабочий каталог стирается между сессиями,
установленный набор правил обновляется только его руками, а хранилище на
сайте живёт всегда и уже используется для промптов.

Ключ хранилища собирается как <код продукта>-<имя файла без точек>:
    aicm-calc · aicm-charts · aicm-build · aicm-spot
Разбор ключа на стороне amin_run требует, чтобы первая часть была кодом
продукта из реестра, поэтому имя пишется без дефисов.

Положить файл:
    python3 amin_store.py put aicm calc aicm_calc.py
Достать всё, что лежит по продукту, в текущий каталог:
    python3 amin_store.py pull aicm
Достать один файл:
    python3 amin_store.py get aicm calc aicm_calc.py
Посмотреть, что лежит:
    python3 amin_store.py list aicm

Формат записи повторяет формат промптов: заголовок с именем файла, размером,
отпечатком и числом частей, затем части по 400 КБ в gzip+base64.
"""

import base64
import gzip
import hashlib
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets"))
import amin_run  # noqa: E402

PART = 400_000
INDEX = "index"          # перечень имён, лежащих по продукту


def _key(code, name):
    return "%s-%s" % (code, name.replace("-", "").replace("_", ""))


def put(code, name, path):
    raw = open(path, "rb").read()
    blob = base64.b64encode(gzip.compress(raw)).decode()
    parts = [blob[i:i + PART] for i in range(0, len(blob), PART)] or [""]
    for i, chunk in enumerate(parts, 1):
        amin_run.state_put(_key(code, name + str(i)), {"часть": chunk})
    amin_run.state_put(_key(code, name), {
        "файл": os.path.basename(path),
        "отпечаток": hashlib.sha256(raw).hexdigest()[:12],
        "упаковка": "gzip+base64",
        "частей": len(parts),
        "байт": len(raw),
    })
    try:
        idx = _read(_key(code, INDEX)) or {}
    except Exception:                    # noqa: BLE001
        idx = {}
    names = idx.get("имена") or []
    if name not in names:
        names.append(name)
    amin_run.state_put(_key(code, INDEX),
                       {"имена": sorted(names),
                        "файлы": dict(idx.get("файлы") or {},
                                      **{name: os.path.basename(path)})})
    print("положено %s → %s (%d байт, %d частей)"
          % (path, _key(code, name), len(raw), len(parts)))


def _read(key, tries=5, pause=20):
    """Чтение ключа с повтором: защита сайта отвечает 429 на частые обращения,
    а комплект читается десятками ключей подряд (правка 06.09.2026)."""
    for i in range(tries):
        try:
            return amin_run.state_get(key)
        except Exception as e:  # noqa: BLE001
            if "429" in str(e) and i < tries - 1:
                time.sleep(pause * (i + 1))
                continue
            raise


def get(code, name, path=None):
    meta = _read(_key(code, name))
    if not meta or "частей" not in meta:
        raise SystemExit("в хранилище нет файла %s по продукту %s" % (name, code))
    blob = ""
    for i in range(1, meta["частей"] + 1):
        blob += _read(_key(code, name + str(i)))["часть"]
        time.sleep(0.5)
    raw = gzip.decompress(base64.b64decode(blob))
    got = hashlib.sha256(raw).hexdigest()[:12]
    if got != meta["отпечаток"]:
        raise SystemExit("отпечаток не сошёлся: %s против %s" % (got, meta["отпечаток"]))
    out = path or meta["файл"]
    open(out, "wb").write(raw)
    print("достано %s → %s (%d байт, отпечаток %s)" % (_key(code, name), out, len(raw), got))
    return out


def pull(code, target="."):
    idx = _read(_key(code, INDEX)) or {}
    names = idx.get("имена") or []
    files = idx.get("файлы") or {}
    if not names:
        raise SystemExit("по продукту %s в хранилище ничего не лежит" % code)
    for name in names:
        get(code, name, os.path.join(target, files.get(name, name)))


def show(code):
    idx = _read(_key(code, INDEX)) or {}
    print(json.dumps(idx, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    cmd = sys.argv[1]
    if cmd == "put":
        put(sys.argv[2], sys.argv[3], sys.argv[4])
    elif cmd == "get":
        get(sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv) > 4 else None)
    elif cmd == "pull":
        pull(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else ".")
    elif cmd == "list":
        show(sys.argv[2])
    else:
        raise SystemExit(__doc__)
