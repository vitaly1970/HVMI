import statistics as st, os, math, sys
# журнал источников (скилл amin-data): без записи в него ни одно число не идёт в выпуск
sys.path.insert(0, "/mnt/skills/user/amin-data/assets")
from amin_run import Log
LOG_DIR = os.environ.get("RUN_OUT", "out")
SEC0 = ["XLK","XLF","XLV","XLY","XLP","XLE","XLI","XLB","XLU","XLRE","XLC"]
CORE = ["SPY","RSP"]
ALL0 = SEC0 + CORE
W, KEEP, TOL = 63, 150, 0.001
WINDOWS = [42, 63, 84]   # окна проверки устойчивости
MIN_SEC = 6              # меньше — выборка нерепрезентативна, цикл останавливается
DISP_P25 = 0.0432        # калибровка 2026-07-24, панель 11 секторов; происхождение в G
NARROW_P80 = 0.026
# Снимок паёв прошлого выпуска. Прогон подаёт его файлом --prev, чтобы модуль
# не правился по месту: правка кода в прогоне ломает происхождение цифр.
PREV_SNAPSHOT = {}
if "--prev" in sys.argv:
    import json as _json
    _p = sys.argv[sys.argv.index("--prev") + 1]
    if os.path.exists(_p):
        PREV_SNAPSHOT = _json.load(open(_p, encoding="utf-8"))
OUT = "/home/claude"
LOG_OUT = "out"          # каталог журнала каналов для гейта раздела S

RU = {"XLK":"Технологии","XLF":"Финансы","XLV":"Здравоохранение","XLY":"Товары длительного спроса",
      "XLP":"Товары повседневного спроса","XLE":"Энергетика","XLI":"Промышленность","XLB":"Материалы",
      "XLU":"Коммунальные услуги","XLRE":"Недвижимость","XLC":"Коммуникации"}

# --- кэш ---
cache = {}
if os.path.exists(f"{OUT}/cache.txt"):
    dates = []
    for line in open(f"{OUT}/cache.txt"):
        line = line.strip()
        if not line or ":" not in line: continue
        k, v = line.split(":", 1)
        if k == "DATES": dates = v.split(",")
        elif k in ALL0: cache[k] = dict(zip(dates, map(float, v.split(","))))

# --- дельта/полные CSV ---
fresh = {}
for t in ALL0:
    f = f"{OUT}/data/{t}.csv"
    if not os.path.exists(f): continue
    lines = [l.strip() for l in open(f) if l.strip()]
    if len(lines) < 2: continue
    hd = lines[0].split(",")
    if "date" not in hd or "adjClose" not in hd: continue
    di, ci = hd.index("date"), hd.index("adjClose")
    rows = {}
    for l in lines[1:]:
        r = l.split(",")
        if len(r) <= max(di, ci): continue
        try: rows[r[di][:10]] = float(r[ci])
        except ValueError: continue
    if rows: fresh[t] = rows

# --- проверка сдвига adjClose и стыковка ---
shifted = []
for t in ALL0:
    if t in cache and t in fresh:
        common = set(cache[t]) & set(fresh[t])
        if common and any(abs(fresh[t][d]/cache[t][d]-1) > TOL for d in common):
            shifted.append(t); continue
        cache[t] = {**cache[t], **fresh[t]}
    elif t in fresh: cache[t] = fresh[t]
if shifted:
    print("ADJ-СДВИГ: " + " ".join(shifted) + " — перекачать ПОЛНЫМИ ссылками и перезапустить"); raise SystemExit

# --- пропуски: секторы цикл не валят, опорные ряды валят ---
missing = [t for t in ALL0 if t not in cache]
core_missing = [t for t in CORE if t in missing]
if core_missing:
    print(f"СТОП: нет опорных рядов {core_missing} — расчёт невозможен"); raise SystemExit
SEC = [t for t in SEC0 if t not in missing]
ALL = SEC + CORE
sec_missing = [t for t in SEC0 if t in missing]
if sec_missing:
    print(f"ПРОПУЩЕНЫ СЕКТОРА (нет данных, исключены из расчёта): {' '.join(sec_missing)}")
if len(SEC) < MIN_SEC:
    print(f"СТОП: секторов с данными {len(SEC)} из 11, минимум {MIN_SEC} — выборка нерепрезентативна"); raise SystemExit

dts = sorted(set.intersection(*(set(cache[t]) for t in ALL)))[-KEEP:]
WMAX = max(WINDOWS)
if len(dts) <= W:
    print(f"СТОП: истории мало — {len(dts)} дат, нужно больше {W}"); raise SystemExit
px = {t: [cache[t][d] for d in dts] for t in ALL}
asof = dts[-1]
N = len(dts)
WIN_OK = [w for w in WINDOWS if N > w]
if len(WIN_OK) < len(WINDOWS):
    print(f"ЧУВСТВИТЕЛЬНОСТЬ: окна {[w for w in WINDOWS if w not in WIN_OK]} пропущены — истории {N} дат не хватает")

def block(win, end=None):
    """Метрики Guard на окне win, конец окна = end (индекс+1 в dts)."""
    end = N if end is None else end
    i1, i0 = end-1, end-1-win
    r  = {t: px[t][i1]/px[t][i0]-1.0 for t in ALL}
    rl = {t: r[t]-r["SPY"] for t in SEC}
    d  = st.pstdev(list(rl.values()))
    nr = r["SPY"]-r["RSP"]
    m  = st.median([abs(v) for v in rl.values()])
    strg = {t: v for t, v in rl.items() if abs(v) > m}
    ts = int(any(v > 0 for v in strg.values()) and any(v < 0 for v in strg.values()))
    return r, rl, d, nr, m, strg, ts

def verdict(d, nr, ts):
    cd = None if DISP_P25 is None else d > DISP_P25
    cn = nr <= NARROW_P80
    if cd is False or not cn or not ts:
        r = []
        if cd is False: r.append("низкая дисперсия")
        if not cn: r.append("узкий рынок (тема)")
        if not ts: r.append("односторонность")
        return "LOW_SECTORNESS: " + ", ".join(r), cd, cn
    if cd is None:
        return "УСЛОВНО-REGIME=1 (DISP_P25 не задан; NARROW и TWO_SIDED пройдены)", cd, cn
    return "SECTOR_ROTATION_REGIME=1", cd, cn

ret63, rel, disp, narrow, med, strong, two_sided = block(W)
regime, cond_disp, cond_narrow = verdict(disp, narrow, two_sided)

LOG = Log(out=LOG_DIR, code="lead", cutoff=asof)
for _t in ALL:
    _r = cache[_t]
    LOG.series("цены_" + _t.lower(), "Tiingo", max(_r), len(_r))
print(f"=== СРЕЗ {asof} ===")
print(f"ОХВАТ: секторов в расчёте {len(SEC)} из 11 | дат в кэше {N} | базовое окно {W} дн.")
print(f"GUARD: DISP={disp:.4f} (P25={'н/з' if DISP_P25 is None else DISP_P25}) | NARROW={narrow:+.4f} (<= +{NARROW_P80}: {cond_narrow}) | TWO_SIDED={two_sided}")
print(f"РЕЖИМ: {regime}")
print("RelRet63: " + "  ".join(f"{t}:{rel[t]:+.3f}" for t in SEC))

# --- нормализация на волатильность ---
# z_cs  — положение сектора в текущем срезе (rel / кросс-секционное СКО)
# IR    — опережение, делённое на собственную волатильность отставания за окно
def relvol(t, win, end=None):
    end = N if end is None else end
    i1 = end-1; i0 = i1-win
    s = [(px[t][k]/px[t][k-1]-1.0) - (px["SPY"][k]/px["SPY"][k-1]-1.0) for k in range(i0+1, i1+1)]
    return st.pstdev(s) if len(s) > 1 else 0.0

zcs, ir, rv = {}, {}, {}
for t in SEC:
    rv[t] = relvol(t, W)
    zcs[t] = rel[t]/disp if disp > 0 else 0.0
    ir[t] = rel[t]/(rv[t]*math.sqrt(W)) if rv[t] > 0 else 0.0
print("НОРМАЛИЗАЦИЯ (z_cs = положение среди секторов; IR = опережение / собственная волатильность):")
for t in sorted(SEC, key=lambda x: -rel[x]):
    print(f"  {RU[t]} ({t}): rel={rel[t]*100:+.1f}%  z_cs={zcs[t]:+.2f}  IR={ir[t]:+.2f}  vol_отн_дн={rv[t]*100:.2f}%")

# --- производные для отчёта Quarterly Leadership Monitor (печатает скрипт, интерпретатор не считает сам) ---
rank = sorted(rel.items(), key=lambda kv: -kv[1])
print("РАНЖИРОВАНИЕ (против S&P 500, 63 торговых дня):")
for i, (t, v) in enumerate(rank, 1):
    print(f"  {i}. {RU[t]} ({t}): {v*100:+.1f}%")
print(f"СПРЕД лидер-аутсайдер: {(rank[0][1]-rank[-1][1])*100:.1f} п.п. | секторов выше SPY: {sum(1 for v in rel.values() if v > 0)} из {len(SEC)}")
print(f"NARROW: запас до порога +{NARROW_P80*100:.1f}%: {(NARROW_P80-narrow)*100:.2f} п.п. ({(NARROW_P80-narrow)/NARROW_P80*100:.0f}% порога)")
print(f"СИЛЬНЫЕ (|отклонение| выше медианы {med*100:.1f}%): плюс {[t for t,v in strong.items() if v>0]} / минус {[t for t,v in strong.items() if v<0]}")

# --- устойчивость к выбору окна ---
print("ЧУВСТВИТЕЛЬНОСТЬ К ОКНУ:")
print("  окно | DISP    | NARROW   | TWO_SIDED | лидер | аутсайдер | вердикт")
verds = []
for w in WIN_OK:
    _, rl_w, d_w, nr_w, _, _, ts_w = block(w)
    v_w, _, _ = verdict(d_w, nr_w, ts_w)
    rk = sorted(rl_w.items(), key=lambda kv: -kv[1])
    verds.append(v_w.split(":")[0].split(" (")[0])
    print(f"  {w:>4} | {d_w:.4f}  | {nr_w:+.4f}  | {ts_w:^9} | {rk[0][0]:<5} | {rk[-1][0]:<9} | {v_w}")
print(f"  ВЫВОД: вердикт по окнам {'СОВПАДАЕТ' if len(set(verds))==1 else 'РАСХОДИТСЯ — сигнал зависит от выбора окна'}")

# --- риск-блок по спреду лидер-аутсайдер ---
L, A = rank[0][0], rank[-1][0]
i1 = N-1; i0 = i1-W
sp = [(px[L][k]/px[L][i0]-1.0) - (px[A][k]/px[A][i0]-1.0) for k in range(i0, i1+1)]
dsp = [sp[k]-sp[k-1] for k in range(1, len(sp))]
sp_vol_d = st.pstdev(dsp) if len(dsp) > 1 else 0.0
peak = sp[0]; mdd = 0.0
for v in sp:
    peak = max(peak, v); mdd = min(mdd, v-peak)
print(f"РИСК СПРЕДА {L}-{A} за {W} дн.: текущий {sp[-1]*100:+.1f} п.п. | дневная волатильность {sp_vol_d*100:.2f} п.п. | макс. просадка спреда {mdd*100:.1f} п.п.")
print(f"  отношение спред/волатильность за окно: {sp[-1]/(sp_vol_d*math.sqrt(W)):+.2f}" if sp_vol_d > 0 else "  отношение спред/волатильность: н/д")

# --- история метрик по дням (для графика; PIT-журнал её не ждёт) ---
hist = []
for end in range(W+1, N+1):
    _, _, d_h, nr_h, _, _, _ = block(W, end)
    hist.append((dts[end-1], d_h, nr_h))
print(f"ИСТОРИЯ МЕТРИК: {len(hist)} дневных точек, {hist[0][0]} → {hist[-1][0]} (в чат не печатается, идёт в график)")

# --- графики SVG ---
def svg_bars(path):
    w, h, ml, mt, bh, gap = 720, 60+len(rank)*26, 250, 40, 18, 8
    mx = max(abs(v) for _, v in rank) or 1.0
    zx = ml + (w-ml-60)/2
    sc = (w-ml-60)/2/mx
    p = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" font-family="Helvetica,Arial,sans-serif">',
         f'<rect width="{w}" height="{h}" fill="#ffffff"/>',
         f'<text x="12" y="22" font-size="13" font-weight="bold">Отставание и опережение секторов к S&amp;P 500 за квартал, п.п.</text>',
         f'<text x="12" y="38" font-size="10" fill="#666">данные на {asof}</text>']
    for i, (t, v) in enumerate(rank):
        y = mt + i*(bh+gap)
        x = zx if v >= 0 else zx + v*sc
        p.append(f'<text x="{ml-8}" y="{y+13}" font-size="11" text-anchor="end">{RU[t]} ({t})</text>')
        p.append(f'<rect x="{x:.1f}" y="{y}" width="{abs(v)*sc:.1f}" height="{bh}" fill="{"#2f6f3e" if v>=0 else "#8f2f2f"}"/>')
        lx = zx + v*sc + (6 if v >= 0 else -6)
        p.append(f'<text x="{lx:.1f}" y="{y+13}" font-size="11" text-anchor="{"start" if v>=0 else "end"}">{v*100:+.1f}</text>')
    p.append(f'<line x1="{zx:.1f}" y1="{mt-6}" x2="{zx:.1f}" y2="{mt+len(rank)*(bh+gap)}" stroke="#000" stroke-width="1.5"/>')
    p.append(f'<text x="{zx:.1f}" y="{mt-10}" font-size="10" text-anchor="middle">S&amp;P 500</text></svg>')
    open(path, "w").write("\n".join(p))

def svg_lines(path):
    w, h, ml, mr, mt, mb = 720, 300, 60, 60, 46, 40
    xs = list(range(len(hist)))
    dd = [x[1] for x in hist]; nn = [x[2] for x in hist]
    def ax(v, lo, hi, y0, y1): return y1 - (v-lo)/((hi-lo) or 1)*(y1-y0)
    dlo, dhi = min(dd), max(dd); nlo, nhi = min(nn+[NARROW_P80]), max(nn+[NARROW_P80])
    px_ = lambda i: ml + i*(w-ml-mr)/max(len(xs)-1, 1)
    p = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" font-family="Helvetica,Arial,sans-serif">',
         f'<rect width="{w}" height="{h}" fill="#ffffff"/>',
         f'<text x="12" y="20" font-size="13" font-weight="bold">Динамика метрик Guard, дневные значения на окне {W} дней</text>',
         f'<text x="12" y="36" font-size="10" fill="#666">DISP — разброс секторов (левая шкала); NARROW — узость рынка (правая шкала); пунктир — порог NARROW +{NARROW_P80*100:.1f}%</text>']
    pl = " ".join(f"{px_(i):.1f},{ax(v, dlo, dhi, mt, h-mb):.1f}" for i, v in enumerate(dd))
    p.append(f'<polyline points="{pl}" fill="none" stroke="#1f4e79" stroke-width="2"/>')
    pl2 = " ".join(f"{px_(i):.1f},{ax(v, nlo, nhi, mt, h-mb):.1f}" for i, v in enumerate(nn))
    p.append(f'<polyline points="{pl2}" fill="none" stroke="#8f2f2f" stroke-width="2"/>')
    ty = ax(NARROW_P80, nlo, nhi, mt, h-mb)
    p.append(f'<line x1="{ml}" y1="{ty:.1f}" x2="{w-mr}" y2="{ty:.1f}" stroke="#8f2f2f" stroke-dasharray="4,3" stroke-width="1"/>')
    p.append(f'<line x1="{ml}" y1="{h-mb}" x2="{w-mr}" y2="{h-mb}" stroke="#000"/>')
    p.append(f'<text x="{ml}" y="{h-mb+16}" font-size="10">{hist[0][0]}</text>')
    p.append(f'<text x="{w-mr}" y="{h-mb+16}" font-size="10" text-anchor="end">{hist[-1][0]}</text>')
    p.append(f'<text x="{ml-8}" y="{mt+4}" font-size="10" text-anchor="end" fill="#1f4e79">{dhi:.3f}</text>')
    p.append(f'<text x="{ml-8}" y="{h-mb}" font-size="10" text-anchor="end" fill="#1f4e79">{dlo:.3f}</text>')
    p.append(f'<text x="{w-mr+8}" y="{mt+4}" font-size="10" fill="#8f2f2f">{nhi:+.3f}</text>')
    p.append(f'<text x="{w-mr+8}" y="{h-mb}" font-size="10" fill="#8f2f2f">{nlo:+.3f}</text>')
    p.append('</svg>')
    open(path, "w").write("\n".join(p))

# Выгрузка для графиков выпуска: отклонения секторов к рынку на дату среза.
# Прежде их рисовал сборочный скрипт продукта, снятый 27.08.2026; теперь
# картинки строит r_charts.py, и брать числа ему больше неоткуда.
import json as _j
_j.dump({"asof": asof, "rank": [[t, v] for t, v in rank], "RU": RU},
        open("/home/claude/devdata.json", "w"), ensure_ascii=False)
print("ВЫГРУЗКА: devdata.json (отклонения секторов для графика выпуска)")

svg_bars(f"{OUT}/chart_sectors.svg")
if len(hist) >= 5: svg_lines(f"{OUT}/chart_metrics.svg"); nch = 2
else: print(f"ГРАФИК МЕТРИК: пропущен — точек истории {len(hist)}, нужно 5+"); nch = 1
print(f"ГРАФИКИ: {nch} шт. → chart_sectors.svg" + (", chart_metrics.svg" if nch == 2 else ""))

# --- слой 2 (потоки в секторные фонды по книге SSGA) ---
# ПОЧИНЕНО 23.08.2026: колонка паёв бралась поиском по подстроке и попадала в
# «Exchange Volume (shares)» — дневной оборот вместо количества паёв. Теперь
# колонки берутся точными именами, как в разделе R. Прошлый снимок принимается
# в формате раздела R (число паёв на сектор); старый формат «паи и цена» тоже
# читается. Логика расчёта потока прежняя: изменение паёв на цену пая.
snap = {}
if os.path.exists(f"{OUT}/data/ssga.xlsx"):
    try:
        import openpyxl

        def _num(v):
            if v is None: return None
            t = str(v).replace(",", "").replace("$", "").strip()
            mul = 1e9 if t.endswith("B") else (1e6 if t.endswith("M") else 1.0)
            try: return float(t.rstrip("MB").strip()) * mul
            except ValueError: return None

        wb = openpyxl.load_workbook(f"{OUT}/data/ssga.xlsx", data_only=True)
        book_asof = ""
        for ws in wb.worksheets:
            head = None
            for row in ws.iter_rows(values_only=True):
                vals = [str(c).strip() if c is not None else "" for c in row]
                if head is None:
                    if "Ticker" in vals: head = {v: i for i, v in enumerate(vals) if v}
                    continue
                tk = vals[head["Ticker"]].replace("\u00ae", "").strip().upper()
                if tk in SEC and "Shares Outstanding" in head and "NAV" in head:
                    so, nav = _num(row[head["Shares Outstanding"]]), _num(row[head["NAV"]])
                    if so and nav:
                        snap[tk] = {"so": so, "nav": nav}
                        book_asof = vals[head.get("As of**", 0)] or book_asof
        if snap:
            print(f"S2 СНИМОК (книга SSGA на {book_asof}): " +
                  "  ".join(f"{t}:паёв={snap[t]['so']/1e6:.2f}млн/цена={snap[t]['nav']:.2f}"
                            for t in sorted(snap)))
            if PREV_SNAPSHOT:
                flows = {}
                for t in sorted(set(snap) & set(PREV_SNAPSHOT)):
                    prev = PREV_SNAPSHOT[t]
                    prev_so = prev["so"] if isinstance(prev, dict) else float(prev)
                    flows[t] = (snap[t]["so"] - prev_so) * snap[t]["nav"] / 1e6
                print("S2 ПОТОКИ против прошлого снимка, млн долларов:")
                for t, v in sorted(flows.items(), key=lambda r: -r[1]):
                    print(f"  {RU[t]} ({t}): {v:+,.0f}")
                for t, v in flows.items():
                    LOG.value(f"поток_{t.lower()}", round(v, 1),
                              "книга фондов SSGA", book_asof or asof, "млн долларов")
                LOG.value("потоки_фондов", len(flows), "книга фондов SSGA",
                          book_asof or asof, "секторов")
            else:
                LOG.gap("потоки_фондов", channels=["книга фондов SSGA"],
                        reason="прошлого снимка нет — первый цикл")
                print("S2: прошлого снимка нет — потоки со следующего цикла")
            print("S2 СНИМОК ДЛЯ СЛЕДУЮЩЕГО ЦИКЛА: " +
                  repr({t: round(snap[t]["so"]) for t in sorted(snap)}))
        else:
            print("S2: книга разобрана, секторных строк нет — нет данных")
    except Exception as e: print(f"S2: xlsx не разобран — нет данных ({e})")
else: print("S2: файл SSGA не получен — нет данных")
print("СТАТУСЫ: Guard=OK | S1=НЕТ ДАННЫХ | S2=%s |" % ("ПОТОКИ СЧИТАЮТСЯ" if snap else "НЕТ ДАННЫХ") + "  S3=НЕТ ДАННЫХ | S4=НЕТ ДАННЫХ | SRC/состояния НЕ считаются")
LOG.value("рассеяние_disp", round(disp, 4), "расчёт по ценам Tiingo", asof)
LOG.value("концентрация_narrow", round(narrow, 4), "расчёт по ценам Tiingo", asof)
LOG.value("двусторонность", int(two_sided), "расчёт по ценам Tiingo", asof)
LOG.value("ранжирование_секторов", rank[0][0] + "→" + rank[-1][0], "расчёт по ценам Tiingo", asof)
LOG.value("ir_секторов", round(max(ir.values()), 3), "расчёт по ценам Tiingo", asof)
LOG.value("спред_лидер_аутсайдер", round((rank[0][1] - rank[-1][1]) * 100, 1), "расчёт по ценам Tiingo", asof, "п.п.")
LOG.value("устойчивость_окна", ";".join(str(w) for w in WINDOWS), "расчёт по ценам Tiingo", asof)
print(f"ПОЛНОТА ДАННЫХ: неполная — работает только ценовой слой; DISP_P25 {'не задан' if DISP_P25 is None else 'задан'}")

# --- новый кэш для следующего файла ---
with open(f"{OUT}/cache_new.txt", "w") as f:
    f.write("DATES:" + ",".join(dts) + "\n")
    for t in ALL: f.write(t + ":" + ",".join(f"{cache[t][d]:.2f}" for d in dts) + "\n")
print(f"КЭШ: {len(dts)} дат × {len(ALL)} тикеров → cache_new.txt")

# --- журнал каналов прогона (гейт раздела S, скилл amin-data) ----------------
# Числа не пересчитываются: в журнал идут ровно те величины, что напечатаны выше.
try:
    import sys as _sys
    _sys.path.insert(0, "/mnt/skills/user/amin-data/assets")
    from amin_run import Log as _Log
    _log = _Log(LOG_OUT)
    for _t in ALL:
        _log.series("цены_" + _t.lower(),
                    channel=f"Tiingo · {_t} · цены закрытия с поправкой на дивиденды и сплиты",
                    last_date=dts[-1], points=len(dts), layer="быстрый")
    for _t in missing:
        _log.gap("цены_" + _t.lower(), channels=["Tiingo"], reason="ряд не получен")
    _asof = dts[-1]
    _log.value("рассеяние_disp", round(disp, 4), "скрипт E, блок GUARD", _asof, "")
    _log.value("концентрация_narrow", round(narrow, 4), "скрипт E, блок GUARD", _asof, "")
    _log.value("двусторонность", int(two_sided), "скрипт E, блок GUARD", _asof, "")
    _log.value("ранжирование_секторов", len(rank), "скрипт E, блок РАНЖИРОВАНИЕ",
               _asof, "секторов")
    _log.value("ir_секторов", len(SEC), "скрипт E, блок НОРМАЛИЗАЦИЯ", _asof, "секторов")
    _log.value("спред_лидер_аутсайдер", round((rank[0][1] - rank[-1][1]) * 100, 1),
               "скрипт E, блок СПРЕД", _asof, "п.п.")
    _log.value("устойчивость_окна", len(WINDOWS),
               "скрипт E, блок ЧУВСТВИТЕЛЬНОСТЬ К ОКНУ", _asof, "окна")
    print(f"ЖУРНАЛ КАНАЛОВ: записи ценового слоя и вычисленных величин → {LOG_OUT}/channels.jsonl")
except Exception as _e:
    print(f"ЖУРНАЛ КАНАЛОВ: не записан — {_e}. Гейт раздела S остановит выдачу.")