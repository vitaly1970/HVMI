#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""credit_calc.py — замороженный расчёт выпуска «Кредитный цикл» (код `credit`).

Один файл на назначение: каналы Фазы 0, разбор отчётности, точечные значения
Фазы 1 и расчётное ядро Р.2–Р.10 промпта Amin_Weekly_Credit_Monitor.md v2.5.

    python3 credit_calc.py --cutoff ГГГГ-ММ-ДД --data data --out out

Один запуск делает всё: качает ряды (кэш в --data), считает блок Р, ведёт
журнал источников через amin_run.Log и пишет out/calc.json и out/charts.json.
Повторный запуск берёт кэш и не ходит в сеть.

ПОЧЕМУ ФАЙЛ ЗАМОРОЖЕН. Прогон 11.08.2026 и прогон 14.08.2026 писали расчёт
заново, и классификатор режима разошёлся: на одних и тех же данных первый дал
«Здоровый», второй — «Ухудшение». Модуль запускают, а не переписывают; дефект
чинится здесь, после чего архив скилла пересобирается.

ЛОВУШКИ, ЗАШИТЫЕ В КОД
 * спреды ICE BofA живут три года — перцентиль считается по доступной истории,
   длинные окна берутся по BAA10Y (с 1986);
 * все перцентили и Z каузальные: точка не видит будущего;
 * guard по датам в проверках на истории — наблюдение вне окна ряда
   отбрасывается, иначе старые эпизоды получают доходность от первой даты ряда;
 * отношение оборота к запасу не публикуется при отрицательной чистой позиции;
 * агрегат при числе эпизодов меньше пяти не строится;
 * квартальные факты XBRL приходят накопительным итогом — годовая величина
   собирается из четырёх кварталов, при их нехватке берётся годовой факт;
 * заброшенный тег долга с устаревшей датой отсекается свежестью: у части
   эмитентов он держит значение пятилетней давности (Ford — 291 млн от 2020),
   и без отсева медиана долговой нагрузки корзины занижается втрое;
 * ряды с постоянным лагом канала (коммерческие бумаги, финансовые условия,
   банковский кредит) пишутся в журнал с пометкой замены, иначе проверка
   свежести валит чистый выпуск;
 * плоский словарь весов сценариев лежит под ключом «сценарии»: проверка перед
   выдачей сверяет сумму именно по нему, вложенные величины ей мешают.
"""
import argparse, gzip, io, json, math, os, re, sys, time
import concurrent.futures as cf
import datetime as dt
import urllib.request, urllib.parse
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import amin_run
from amin_run import Log

DAY = 252
DATA = "data"
RECOVERY = 0.40


def _date(v):
    """Дата из строки или объекта. Один разбор на модуль: даты приходят и из
    аргументов, и из снимков, и из отчётности."""
    if isinstance(v, dt.date):
        return v
    return dt.datetime.strptime(str(v)[:10], "%Y-%m-%d").date()


def _http(url, headers, tries=4, pause=1.2):
    """Единственный загрузчик модуля. Ретраи с растущей паузой; ответ,
    сжатый gzip, распаковывается — EDGAR отдаёт факты только так."""
    last = None
    for i in range(tries):
        try:
            rq = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(rq, timeout=90) as r:
                d = r.read()
                if r.headers.get("Content-Encoding") == "gzip":
                    d = gzip.decompress(d)
                return d
        except Exception as e:
            last = e
            time.sleep(pause * (i + 1))
    raise last


# ═════════════════ Фаза 0 · каналы данных ═════════════════
PROXY = ("https://www.americaninvestor.capital/app/api/proxy?url="
         "https://fred.stlouisfed.org/graph/fredgraph.csv?id=%s")
UA_FRED = {"User-Agent": "curl/8.5.0", "Accept": "text/csv,*/*"}

FRED = {
 # А. Цена кредита
 "hy": "BAMLH0A0HYM2", "ig": "BAMLC0A0CM", "bbb": "BAMLC0A4CBBB",
 "bb": "BAMLH0A1HYBB", "b": "BAMLH0A2HYB", "ccc": "BAMLH0A3HYC",
 "aaa": "BAMLC0A1CAAA", "aa": "BAMLC0A2CAA", "a": "BAMLC0A3CA",
 "hy_yield": "BAMLH0A0HYM2EY", "vix": "VIXCLS",
 "baa10y": "BAA10Y", "aaa10y": "AAA10Y",
 # Б. Международный разрез
 "eu_hy": "BAMLHE00EHYIOAS", "em_corp": "BAMLEMCBPIOAS", "asia": "BAMLEMRACRPIASIAOAS",
 # Г. Количество и поток
 "bank_credit": "TOTBKCR", "ci": "BUSLOANS", "consumer": "CONSUMER", "realln": "REALLN",
 "nfc_debt": "BCNSDODNS", "hh_debt": "CMDEBT", "gdp": "GDP",
 "sloos_ci_large": "DRTSCILM", "sloos_ci_small": "DRTSCIS", "sloos_cc": "DRTSCLCC",
 "sloos_sub": "SUBLPDRCSN", "sloos_demand": "DRISCFLM",
 # Д. Фондирование
 "cp_fin": "DCPF3M", "cp_nonfin": "DCPN3M", "cp_out": "COMPOUT", "cp_ab": "ABCOMP",
 "cp_nfin_out": "NFINCP", "cp_fin_out": "FINCPN", "tbill3m": "DTB3", "sofr": "SOFR",
 "nfci": "NFCI", "anfci": "ANFCI", "stlfsi": "STLFSI4",
 # Ж. Дефолтный цикл
 "del_business": "DRBLACBS", "del_consumer": "DRCLACBS", "del_cc": "DRCCLACBS",
 "del_mortgage": "DRSFRMACBS", "del_cre": "DRCRELEXFACBS", "del_all": "DRALACBS",
 "co_business": "CORBLACBS", "co_consumer": "CORCACBS", "co_cc": "CORCCACBS",
 # З. Кривая
 "dgs1": "DGS1", "dgs2": "DGS2", "dgs3": "DGS3", "dgs5": "DGS5",
 "dgs7": "DGS7", "dgs10": "DGS10", "dgs20": "DGS20", "dgs30": "DGS30",
 # длинная база рынка
 "nasdaq": "NASDAQCOM",
}




def fred_one(key, sid):
    p = os.path.join(DATA, "fred_%s.csv" % key)
    if os.path.exists(p) and os.path.getsize(p) > 200:
        return key, sid, "кэш"
    try:
        raw = _http(PROXY % sid, UA_FRED)
        txt = raw.decode("utf-8", "replace")
        if "DATE" not in txt[:200].upper():
            return key, sid, "ОТКАЗ: не CSV"
        open(p, "w", encoding="utf-8").write(txt)
        return key, sid, "ok"
    except Exception as e:
        return key, sid, "ОТКАЗ: %s" % e


def fetch_fred():
    todo = list(FRED.items())
    res = []
    with cf.ThreadPoolExecutor(max_workers=6) as ex:
        futs = [ex.submit(fred_one, k, s) for k, s in todo]
        for f in cf.as_completed(futs):
            res.append(f.result())
    bad = [r for r in res if r[2].startswith("ОТКАЗ")]
    # второй проход по неполученным рядам — норма промпта
    if bad:
        time.sleep(3)
        again = []
        for k, s, _ in bad:
            again.append(fred_one(k, s))
        res = [r for r in res if not r[2].startswith("ОТКАЗ")] + again
    for k, s, st in sorted(res):
        print("%-16s %-22s %s" % (k, s, st))
    print("ИТОГО отказов:", sum(1 for r in res if r[2].startswith("ОТКАЗ")))

# ── ФРБ Нью-Йорка и котировки фондов ──
UA_WEB = {"User-Agent": "Mozilla/5.0 (compatible; AmInResearch/1.0)"}

NYFED = [
    # позиции по корпоративным облигациям инвестиционного рейтинга
    "PDPOSCSBND-L13", "PDPOSCSBND-G13", "PDPOSCSBND-G5L10", "PDPOSCSBND-G10",
    # ниже инвестиционного
    "PDPOSCSBND-BELL13", "PDPOSCSBND-BELG13", "PDPOSCSBND-BELG5L10", "PDPOSCSBND-BELG10",
    # обороты
    "PDTRCSIND-L13", "PDTRCSIND-G13", "PDTRCSIND-G5L10", "PDTRCSIND-G10",
    "PDTRCSIND-BELL13", "PDTRCSIND-BELG13", "PDTRCSIND-BELG5L10", "PDTRCSIND-BELG10",
]

ETF = ["BIZD", "BKLN", "SRLN", "HYG", "LQD", "SPY", "ANGL", "JNK"]




def fetch_nyfed(key):
    p = os.path.join(DATA, "nyfed_%s.json" % key)
    if os.path.exists(p) and os.path.getsize(p) > 200:
        return key, "кэш"
    try:
        raw = _http("https://markets.newyorkfed.org/api/pd/get/%s.json" % key, UA_WEB)
        j = json.loads(raw.decode("utf-8"))
        open(p, "w", encoding="utf-8").write(json.dumps(j, ensure_ascii=False))
        n = len(j.get("pd", {}).get("timeseries", []))
        return key, "ok n=%d" % n
    except Exception as e:
        return key, "ОТКАЗ: %s" % e


def fetch_yahoo(sym):
    p = os.path.join(DATA, "yh_%s.json" % sym)
    if os.path.exists(p) and os.path.getsize(p) > 400:
        return sym, "кэш"
    u = ("https://query1.finance.yahoo.com/v8/finance/chart/%s"
         "?period1=-1893456000&period2=9999999999&interval=1d"
         % urllib.parse.quote(sym))
    try:
        raw = _http(u, {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        j = json.loads(raw.decode("utf-8"))
        res = j["chart"]["result"][0]
        n = len(res["timestamp"])
        open(p, "w", encoding="utf-8").write(json.dumps(j, ensure_ascii=False))
        return sym, "ok n=%d" % n
    except Exception as e:
        return sym, "ОТКАЗ: %s" % e

# ── EDGAR: справочник эмитентов и факты XBRL ──
UA_SEC = {"User-Agent": "American Investor Research research@americaninvestor.capital",
          "Accept-Encoding": "gzip, deflate", "Host": "data.sec.gov"}

BASKET = ["AAL", "ACI", "APA", "AR", "BHC", "CAR", "CCL", "CHTR", "COTY", "CYH",
          "F", "KHC", "M", "NRG", "OXY", "RCL", "SIRI", "THC", "UAL", "WDC"]
BDC = ["ARCC", "OBDC", "FSK", "PSEC", "GBDC", "MAIN", "BXSL", "HTGC"]




def sec_tickers():
    p = os.path.join(DATA, "company_tickers.json")
    if not os.path.exists(p):
        raw = _http("https://www.sec.gov/files/company_tickers.json",
                    {"User-Agent": UA_SEC["User-Agent"]})
        open(p, "wb").write(raw)
    j = json.load(open(p, encoding="utf-8"))
    return {v["ticker"].upper(): int(v["cik_str"]) for v in j.values()}


def sec_facts(tk, cik):
    p = os.path.join(DATA, "cf_%s.json" % tk)
    if os.path.exists(p) and os.path.getsize(p) > 5000:
        return tk, "кэш"
    try:
        raw = _http("https://data.sec.gov/api/xbrl/companyfacts/CIK%010d.json" % cik, UA_SEC)
        open(p, "wb").write(raw)
        return tk, "ok %d КБ" % (len(raw) // 1024)
    except Exception as e:
        return tk, "ОТКАЗ: %s" % e


def fetch_market():
    """Дилерская статистика ФРБ Нью-Йорка и котировки фондов."""
    res = []
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        res += list(ex.map(fetch_nyfed, NYFED))
    with cf.ThreadPoolExecutor(max_workers=4) as ex:
        res += list(ex.map(fetch_yahoo, ETF))
    bad = [k for k, st in res if st.startswith("ОТКАЗ")]
    print("  рынок: %d рядов, отказов %d" % (len(res), len(bad)))
    if bad:
        print("  не получены:", ", ".join(bad))
    return res


def fetch_edgar(only=None):
    """Факты XBRL по корзине эмитентов и по фондам прямого кредитования.
    only — качать лишь перечисленные тикеры (перенос корзины из снимка не
    отменяет свежих фактов фондов: их доля дохода записью считается каждый
    прогон)."""
    m = sec_tickers()
    want = only if only is not None else BASKET + BDC
    todo = [(t, m[t]) for t in want if t in m]
    miss = [t for t in want if t not in m]
    res = []
    with cf.ThreadPoolExecutor(max_workers=5) as ex:
        futs = [ex.submit(sec_facts, t, c) for t, c in todo]
        for f in cf.as_completed(futs):
            res.append(f.result())
    bad = [k for k, st in res if st.startswith("ОТКАЗ")]
    print("  EDGAR: %d эмитентов, отказов %d" % (len(res), len(bad)))
    if miss:
        print("  нет в справочнике SEC:", ", ".join(miss))
    return res


def basket_rows(data=DATA):
    """Фундаментал корзины эмитентов: строка на эмитента, отсев помечается."""
    return [issuer(tk) for tk in BASKET]


def свежий_квартал(rows, cutoff, дней=100):
    """Разобранная отчётность годится, если самый свежий факт корзины моложе
    квартала. Отчётность выходит четыре раза в год, а прогон недельный —
    качать девяносто мегабайт фактов каждую неделю незачем."""
    даты = []
    for r in (rows or []):
        d = r.get("ebitda_дата")
        if d:
            try:
                даты.append(_date(d))
            except Exception:
                pass
    if not даты:
        return False
    return (_date(cutoff) - max(даты)).days <= дней

# ═════════════════ Разбор отчётности ═════════════════
EBIT = ["OperatingIncomeLoss"]
DA = ["DepreciationDepletionAndAmortization", "DepreciationAmortizationAndAccretionNet",
      "DepreciationAndAmortization", "DepreciationDepletionAndAmortizationExcludingAmortizationOfDeferredCharges",
      "CostOfServicesDepreciationAndAmortization"]
INT = ["InterestExpense", "InterestExpenseDebt", "InterestExpenseNonoperating",
       "InterestAndDebtExpense", "InterestIncomeExpenseNet",
       "InterestExpenseBorrowings"]
OCF = ["NetCashProvidedByUsedInOperatingActivities",
       "NetCashProvidedByUsedInOperatingActivitiesContinuingOperations"]
CAPEX = ["PaymentsToAcquirePropertyPlantAndEquipment",
         "PaymentsToAcquireProductiveAssets",
         "PaymentsToAcquirePropertyPlantAndEquipmentAndIntangibleAssets"]
DEBT_TOTAL = ["DebtLongtermAndShorttermCombinedAmount",
              "LongTermDebtAndCapitalLeaseObligationsIncludingCurrentMaturities",
              "LongTermDebt"]
DEBT_LT = ["LongTermDebtNoncurrent", "LongTermDebtAndCapitalLeaseObligations"]
DEBT_CUR = ["LongTermDebtCurrent", "LongTermDebtAndCapitalLeaseObligationsCurrent",
            "DebtCurrent"]
PRETAX = ["IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest",
          "IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments",
          "IncomeLossFromContinuingOperationsBeforeIncomeTaxesDomestic"]
СВЕЖЕСТЬ_ДНЕЙ = 400
CASH = ["CashAndCashEquivalentsAtCarryingValue",
        "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents"]
MAT = {
    "y1": ["LongTermDebtMaturitiesRepaymentsOfPrincipalInNextTwelveMonths",
           "LongTermDebtMaturitiesRepaymentsOfPrincipalRemainderOfFiscalYear"],
    "y2": ["LongTermDebtMaturitiesRepaymentsOfPrincipalInYearTwo"],
    "y3": ["LongTermDebtMaturitiesRepaymentsOfPrincipalInYearThree"],
    "y4": ["LongTermDebtMaturitiesRepaymentsOfPrincipalInYearFour"],
    "y5": ["LongTermDebtMaturitiesRepaymentsOfPrincipalInYearFive"],
    "after": ["LongTermDebtMaturitiesRepaymentsOfPrincipalAfterYearFive"],
}


def xbrl(tk):
    p = os.path.join(DATA, "cf_%s.json" % tk)
    if not os.path.exists(p):
        return None
    return json.load(open(p, encoding="utf-8"))


def _units(j, tag):
    us = j.get("facts", {}).get("us-gaap", {}).get(tag)
    if not us:
        return []
    for u in ("USD",):
        if u in us.get("units", {}):
            return us["units"][u]
    return []


def flow_ttm(j, tags, asof=None):
    """Годовая величина потокового показателя: четыре квартала либо годовой факт."""
    for tag in tags:
        rows = []
        for r in _units(j, tag):
            if not r.get("start") or not r.get("end"):
                continue
            s = dt.date.fromisoformat(r["start"]); e = dt.date.fromisoformat(r["end"])
            rows.append((s, e, (e - s).days, float(r["val"]), r.get("form", "")))
        if not rows:
            continue
        q = sorted([r for r in rows if 80 <= r[2] <= 100], key=lambda r: r[1])
        # дедупликация: один период — одно значение (последняя подача)
        seen = {}
        for r in q:
            seen[(r[0], r[1])] = r
        q = sorted(seen.values(), key=lambda r: r[1])
        if len(q) >= 4:
            last4 = q[-4:]
            if (last4[-1][1] - last4[0][0]).days >= 330:
                return sum(r[3] for r in last4), last4[-1][1], tag, "четыре квартала"
        a = sorted([r for r in rows if 340 <= r[2] <= 380], key=lambda r: r[1])
        if a:
            return a[-1][3], a[-1][1], tag, "годовой факт"
    return None, None, None, None


def stock(j, tags, fresh_to=None):
    """Балансовая величина на последнюю доступную дату.
    fresh_to — срез: факт старше СВЕЖЕСТЬ_ДНЕЙ не годится (у части эмитентов
    тег заброшен и держит значение пятилетней давности)."""
    for tag in tags:
        rows = []
        for r in _units(j, tag):
            if r.get("start"):
                continue
            if not r.get("end"):
                continue
            rows.append((dt.date.fromisoformat(r["end"]), float(r["val"])))
        if rows:
            rows.sort()
            seen = {}
            for d, v in rows:
                seen[d] = v
            d = max(seen)
            if fresh_to is not None and (fresh_to - d).days > СВЕЖЕСТЬ_ДНЕЙ:
                continue
            return seen[d], d, tag
    return None, None, None


def debt_total(j, fresh_to):
    """Полный долг: берётся наибольшая закрытая мера — совокупный тег либо
    сумма долгосрочной и текущей части. Заброшенный тег отсекается свежестью."""
    cands = []
    v, d, t = stock(j, DEBT_TOTAL, fresh_to)
    if v is not None:
        cands.append((v, d, t))
    lt, ld, lt_t = stock(j, DEBT_LT, fresh_to)
    cur, cd, _ = stock(j, DEBT_CUR, fresh_to)
    if lt is not None:
        cands.append((lt + (cur or 0), ld, lt_t + " + текущая часть"))
    if not cands:
        return None, None, None
    return max(cands, key=lambda x: x[0])


def series_ttm(j, tags, n=8):
    """Ряд годовых величин по кварталам — для динамики прибыли."""
    for tag in tags:
        rows = {}
        for r in _units(j, tag):
            if not r.get("start") or not r.get("end"):
                continue
            s = dt.date.fromisoformat(r["start"]); e = dt.date.fromisoformat(r["end"])
            if 80 <= (e - s).days <= 100:
                rows[(s, e)] = float(r["val"])
        if len(rows) >= 8:
            q = sorted(rows.items(), key=lambda kv: kv[0][1])
            out = []
            for i in range(3, len(q)):
                w = q[i - 3:i + 1]
                if (w[-1][0][1] - w[0][0][0]).days >= 330:
                    out.append((w[-1][0][1], sum(x[1] for x in w)))
            if out:
                return out[-n:], tag
    return None, None


def issuer(tk):
    j = xbrl(tk)
    if j is None:
        return None
    d = {"тикер": tk}
    ebit, e_end, e_tag, e_how = flow_ttm(j, EBIT)
    da, _, da_tag, _ = flow_ttm(j, DA)
    itr0, _, _, _ = flow_ttm(j, INT)
    if ebit is None:
        pre, e_end, e_tag, e_how = flow_ttm(j, PRETAX)
        if pre is None:
            return {"тикер": tk, "отсев": "не закрыта операционная прибыль"}
        ebit = pre + (itr0 or 0)
        e_tag += " + процентные расходы"
    ebitda = ebit + (da or 0)
    d["ebitda"] = ebitda
    d["ebitda_дата"] = str(e_end)
    d["ebitda_как"] = e_how
    d["da_закрыт"] = da is not None
    itr, _, i_tag, _ = flow_ttm(j, INT)
    ocf, _, _, _ = flow_ttm(j, OCF)
    cap, _, _, _ = flow_ttm(j, CAPEX)
    asof = dt.date.fromisoformat(str(e_end)) if e_end else dt.date.today()
    debt, lt_d, dtag = debt_total(j, dt.date.today())
    cash, _, _ = stock(j, CASH, dt.date.today())
    if debt is None:
        return {"тикер": tk, "отсев": "не закрыт долг: тег заброшен или отсутствует"}
    d["тег_долга"] = dtag
    d["долг"] = debt
    d["долг_дата"] = str(lt_d)
    d["денежные_средства"] = cash
    d["чистый_долг"] = debt - (cash or 0)
    if ebitda and ebitda > 0:
        d["чистый_долг_к_ebitda"] = round((debt - (cash or 0)) / ebitda, 2)
        if itr and itr > 0:
            d["покрытие_процентов"] = round(ebitda / itr, 2)
    if ocf is not None and cap is not None:
        fcf = ocf - cap
        d["fcf"] = fcf
        if debt:
            d["fcf_к_долгу_проц"] = round(100.0 * fcf / debt, 1)
    if ebitda <= 0:
        d["ebitda_отрицательна"] = True
    ser, _ = series_ttm(j, EBIT)
    if ser and len(ser) >= 5:
        cur_v = ser[-1][1]; prev_v = ser[-5][1]
        d["op_прибыль_год_назад"] = prev_v
        d["op_прибыль_сейчас"] = cur_v
        d["прибыль_снизилась"] = bool(cur_v < prev_v)
    mat = {}
    for k, tags in MAT.items():
        v, vd, _ = stock(j, tags, dt.date.today())
        if v is not None:
            mat[k] = v
            mat[k + "_дата"] = str(vd)
    if mat:
        d["погашения"] = mat
    return d

# ── Приватный кредит: доход в форме наращивания долга ──
PIK = ["InterestIncomeOperatingPaidInKind", "InterestAndDividendIncomeOperatingPaidInKind",
       "PaidInKindInterest"]
PIKD = ["DividendIncomeOperatingPaidInKind"]
INC = ["GrossInvestmentIncomeOperating", "InvestmentIncomeInterest", "InterestIncomeOperating"]
NAV = ["NetAssetValuePerShare"]


def bdc_one(tk):
    j = xbrl(tk)
    if j is None:
        return {"тикер": tk, "отсев": "нет фактов"}
    d = {"тикер": tk}
    pik, pd_, _, how = flow_ttm(j, PIK)
    pikd, _, _, _ = flow_ttm(j, PIKD)
    inc, id_, _, _ = flow_ttm(j, INC)
    if pik is not None and inc:
        d["pik_доля_проц"] = round(100.0 * (pik + (pikd or 0)) / inc, 2)
        d["дата"] = str(id_)
        d["как"] = how
    nav, nd, _ = stock(j, NAV, dt.date.today())
    if nav:
        d["чистые_активы_на_акцию"] = nav
        d["дата_чистых_активов"] = str(nd)
    return d


def bdc_rows(data=DATA):
    """Медиана доли дохода в форме наращивания долга по корзине фондов.
    Фонд, не раскрывший тег, в медиану не идёт — число раскрывших печатается."""
    rows = [bdc_one(t) for t in BDC]
    v = [r["pik_доля_проц"] for r in rows if r.get("pik_доля_проц") is not None]
    out = {"корзина": BDC, "строки": rows}
    if v:
        out["pik_доля_медиана_проц"] = round(float(np.median(v)), 2)
        out["pik_максимум_проц"] = round(float(max(v)), 2)
        out["pik_n"] = len(v)
    return out


# ── Индексы обязательств под кредиты: снимаются кодом с витрины ──
PALMER = {
    "clo_старший": "https://www.palmersquarecap.com/clo-indices/palmer-square-clo-senior-debt-index",
    "clo_весь_долг": "https://www.palmersquarecap.com/clo-indices/palmer-square-clo-debt-index",
}
_PALMER_RX = re.compile(
    r"Price\s*\$?([\d.,]+)\s*as of\s*(\d{2})/(\d{2})/(\d{4})\s*Yield\s*([\d.,]+)\s*%")


def fetch_palmer():
    """Цена и доходность индексов CLOSE и CLODI с витрины Palmer Square.

    Витрина отдаёт только последнее значение, обновление месячное — длинного
    ряда у источника нет, история копится снимками прогона. Значения лежат
    прямо в тексте страницы, поэтому берутся разбором разметки, а не поиском:
    поиск на этом месте стоил лишнего обращения каждую неделю.
    """
    out = {}
    for key, url in PALMER.items():
        p = os.path.join(DATA, "palmer_%s.html" % key)
        try:
            if os.path.exists(p) and os.path.getsize(p) > 5000:
                txt = open(p, encoding="utf-8").read()
            else:
                txt = _http(url, {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
                            ).decode("utf-8", "replace")
                open(p, "w", encoding="utf-8").write(txt)
            plain = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", txt))
            m = _PALMER_RX.search(plain)
            if not m:
                continue
            цена = float(m.group(1).replace(",", ""))
            дата = "%s-%s-%s" % (m.group(4), m.group(2), m.group(3))
            дох = float(m.group(5).replace(",", ""))
            out[key + "_цена"] = {"значение": цена, "источник": "Palmer Square, витрина индекса",
                                  "дата": дата, "единица": "цена", "пометка": "обновление месячное"}
            out[key + "_доходность"] = {"значение": дох, "источник": "Palmer Square, витрина индекса",
                                        "дата": дата, "единица": "%", "пометка": "обновление месячное"}
        except Exception:
            continue
    return out


# ═════════════════ Фаза 1 · точечные значения ═════════════════
# Замороженный модуль не держит значений конкретного прогона: они меняются
# каждую неделю и приходят поиском. Модуль держит ПЕРЕЧЕНЬ того, что прогон
# обязан добрать, и умеет провести добранное через журнал источников.
#
# Прогон кладёт добранное в файл --spot вида
#   {"доля_проблемных_кредитов": {"значение": 6.89,
#                                 "источник": "PitchBook LCD",
#                                 "дата": "2026-07-31", "единица": "%",
#                                 "пометка": "доля кредитов ниже 80 центов"}, …}
# Ключа в файле нет → показатель объявляется пробелом, а не подставляется.

# Перечень точечных величин Фазы 1. Третье поле — как часто источник
# публикует новое значение: оно решает, нужен ли поиск на этом прогоне.
# «код» означает, что величина снимается модулем и поиска не требует вовсе.
SPOT_KEYS = {
    "clo_старший_цена":            ("индекс Palmer Square CLOSE, цена", "код"),
    "clo_старший_доходность":      ("индекс Palmer Square CLOSE, доходность, %", "код"),
    "clo_весь_долг_цена":          ("индекс Palmer Square CLODI, цена", "код"),
    "clo_весь_долг_доходность":    ("индекс Palmer Square CLODI, доходность, %", "код"),
    "доля_проблемных_кредитов":    ("доля кредитов ниже 80 центов, %", "месяц"),
    "дефолтность_кредитов_объём":  ("дефолтность синдицированных кредитов по объёму, %", "месяц"),
    "дефолтность_кредитов_число":  ("то же по числу эмитентов, %", "месяц"),
    "сделок_управления_обязательствами": ("сделок за 12 месяцев, штук", "месяц"),
    "сделок_год_назад":            ("их же число год назад, штук", "месяц"),
    "размещения_ig_ytd":           ("размещения инвестиционного качества, млрд", "месяц"),
    "рост_размещений_ig":          ("их рост год к году, %", "месяц"),
    "выпуск_clo_ytd":              ("выпуск обязательств под кредиты, млрд", "квартал"),
    "выпуск_clo_год_назад":        ("он же год назад на ту же дату, млрд", "квартал"),
    "доля_среднего_бизнеса_в_clo": ("доля бумаг под кредиты среднего бизнеса, %", "квартал"),
    "управляющих_clo":             ("управляющих, разместивших сделку", "квартал"),
    "управляющих_год_назад":       ("их же число год назад", "квартал"),
    "дефолтность_hy_за_12м":       ("дефолтность высокодоходных облигаций, %", "квартал"),
    "дефолтность_приватного_кредита": ("дефолтность приватного кредита, %", "квартал"),
    "цена_вторичного_рынка_кредита": ("цена сделок вторичного рынка, % справедливой стоимости", "полгода"),
    "сектора_сделок":              ("доли секторов в сделках управления обязательствами", "месяц"),
}

# Сколько дней значение считается ещё действующим: пока не вышла новая
# публикация, прогон берёт его из прошлого снимка вместе с ЕГО датой и
# источником, а не ищет заново. Дата в выпуске остаётся честной.
СРОК_ГОДНОСТИ = {"месяц": 45, "квартал": 130, "полгода": 220, "код": 0}

# Сравнительная величина «год назад» относится к дате годичной давности, но
# выходит в той же публикации, что и текущая. Свежесть у неё считается по
# текущей, иначе она устаревает в тот же день, когда её записали.
ПАРНЫЕ = {
    "выпуск_clo_год_назад": "выпуск_clo_ytd",
    "управляющих_год_назад": "управляющих_clo",
    "сделок_год_назад": "сделок_управления_обязательствами",
}


def spot_needed(cutoff, prev=None):
    """Что прогон обязан добрать поиском на этом срезе.

    Величина не ищется, если её снимает код либо если значение из прошлого
    снимка ещё не устарело по частоте публикации источника. Возвращает пару:
    список к поиску и словарь перенесённого со своими датами."""
    cut = _date(cutoff)
    carried, need = {}, []
    было = ((prev or {}).get("точечные") or {})
    for key, (что, частота) in SPOT_KEYS.items():
        if частота == "код":
            continue
        rec = было.get(key)
        срок = СРОК_ГОДНОСТИ.get(частота, 45)
        опора = было.get(ПАРНЫЕ.get(key, key)) or rec
        if rec and (опора or {}).get("дата"):
            try:
                возраст = (cut - _date(опора["дата"])).days
            except Exception:
                возраст = 10 ** 6
            if возраст <= срок:
                r = dict(rec)
                r["пометка"] = ((r.get("пометка") or "") +
                                " · перенесено из выпуска %s, источник не публиковал нового"
                                % (prev or {}).get("выпуск", "прошлого")).strip(" ·")
                carried[key] = r
                continue
        need.append((key, что, частота))
    return need, carried


def phase1(R, L, spot, data=DATA, prev=None):
    """Провести точечные значения через журнал и сложить в артефакт.

    Источники трёх видов: код (индексы обязательств снимает модуль), поиск
    этого прогона (файл spot) и прошлый снимок (величина, по которой источник
    ещё не публиковал нового). Величина без всех трёх объявляется пробелом —
    не подставляется."""
    _, carried = spot_needed(R.get("срез") or "1970-01-01", prev)
    источники = dict(carried)
    источники.update(fetch_palmer())
    источники.update({k: v for k, v in (spot or {}).items() if v})

    got, точечные, miss = {}, {}, []
    for key, (что, _частота) in SPOT_KEYS.items():
        rec = источники.get(key)
        if not rec or rec.get("значение") is None:
            miss.append(key)
            continue
        L.value(key, rec["значение"], rec.get("источник", ""), rec.get("дата", ""),
                rec.get("единица", ""), rec.get("пометка", ""))
        got[key] = rec["значение"]
        точечные[key] = rec
    for key in miss:
        L.gap(key, ["поиск Фазы 1"], "значение не добрано прогоном: %s" % SPOT_KEYS[key][0])
    R["точечные"] = точечные
    R["перенесено_из_снимка"] = sorted(carried)

    # доля дохода в форме наращивания долга считается кодом из EDGAR
    b = bdc_rows(data)
    pik = b.get("pik_доля_медиана_проц")
    if pik is not None:
        L.value("доля_pik_в_доходе", pik,
                "EDGAR XBRL, корзина фондов прямого кредитования", "", "%",
                "медиана по %d фондам из %d" % (b["pik_n"], len(BDC)))
    else:
        L.gap("доля_pik_в_доходе",
              ["EDGAR XBRL companyfacts (корзина фондов прямого кредитования)"],
              "тег дохода в форме наращивания долга не раскрыт ни одним фондом")
    L.gap("дисконт_к_чистым_активам_bdc",
          ["EDGAR XBRL companyfacts (тег NetAssetValuePerShare)", "котировки Yahoo"],
          "стоимость чистых активов на акцию не закрыта тегом ни у одного фонда")

    R["приватный"] = {"доля_pik_проц": pik, "n": b.get("pik_n"), "корзина": BDC,
                      "максимум_pik_проц": b.get("pik_максимум_проц"),
                      "дефолтность_приватного_кредита_проц": got.get("дефолтность_приватного_кредита"),
                      "цена_вторичного_рынка_проц": got.get("цена_вторичного_рынка_кредита")}
    R["первичный_рынок"] = {
        "размещения_ig_ytd_млрд": got.get("размещения_ig_ytd"),
        "рост_ig_проц": got.get("рост_размещений_ig"),
        "выпуск_clo_ytd_млрд": got.get("выпуск_clo_ytd"),
        "выпуск_clo_год_назад_млрд": got.get("выпуск_clo_год_назад"),
        "доля_среднего_бизнеса_проц": got.get("доля_среднего_бизнеса_в_clo"),
        "управляющих_clo": got.get("управляющих_clo"),
        "управляющих_год_назад": got.get("управляющих_год_назад"),
        "clo": {"старший_цена": got.get("clo_старший_цена"),
                "старший_доходность": got.get("clo_старший_доходность"),
                "весь_долг_цена": got.get("clo_весь_долг_цена"),
                "весь_долг_доходность": got.get("clo_весь_долг_доходность"),
                "мезонинная_премия": (round(got["clo_весь_долг_доходность"]
                                            - got["clo_старший_доходность"], 2)
                                      if got.get("clo_весь_долг_доходность")
                                      and got.get("clo_старший_доходность") else None),
                "дата": (точечные.get("clo_старший_цена") or {}).get("дата")}}
    R["дефолтность"].update({
        "доля_проблемных_кредитов_проц": got.get("доля_проблемных_кредитов"),
        "дефолтность_кредитов_объём_проц": got.get("дефолтность_кредитов_объём"),
        "дефолтность_hy_за_12м_проц": got.get("дефолтность_hy_за_12м"),
        "сделок_управления_обязательствами": got.get("сделок_управления_обязательствами"),
        "сделок_год_назад": got.get("сделок_год_назад"),
        "сектора_сделок": got.get("сектора_сделок")})

    # саб-скор приватного кредита закрывает Р.8: больше дохода записью — хуже
    parts = dict(R["score_вход"])
    parts["И_приватный"] = (float(np.clip(100.0 - 5.0 * pik, 0, 100))
                            if pik is not None else None)
    R["score_вход"] = parts
    R["score"] = score_block(parts)
    R["пробелы_фазы_1"] = miss
    return R


# ═════════════════ Загрузка в pandas и блок Р ═════════════════


# ─────────────────────────── загрузка ───────────────────────────
def load_fred(data, key):
    p = os.path.join(data, "fred_%s.csv" % key)
    df = pd.read_csv(p)
    df.columns = ["date", "value"]
    df["date"] = pd.to_datetime(df["date"])
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    s = df.dropna().set_index("date")["value"]
    return s[~s.index.duplicated(keep="last")].sort_index()


def load_nyfed(data, key):
    j = json.load(open(os.path.join(data, "nyfed_%s.json" % key), encoding="utf-8"))
    ts = j["pd"]["timeseries"]
    rows = [(pd.to_datetime(r["asofdate"]), pd.to_numeric(r["value"], errors="coerce"))
            for r in ts]
    s = pd.Series({d: v for d, v in rows}).dropna().sort_index()
    return s


def load_yahoo(data, sym):
    j = json.load(open(os.path.join(data, "yh_%s.json" % sym), encoding="utf-8"))
    r = j["chart"]["result"][0]
    idx = pd.to_datetime(pd.Series(r["timestamp"]), unit="s").dt.normalize()
    cl = r["indicators"]["quote"][0]["close"]
    s = pd.Series(cl, index=idx).dropna()
    s = s[~s.index.duplicated(keep="last")].sort_index()
    meta = r.get("meta", {})
    return s, meta


# ─────────────────────── Р.2 нормализация ───────────────────────
def causal_z(s, win=DAY):
    m = s.rolling(win, min_periods=max(60, win // 4)).mean()
    sd = s.rolling(win, min_periods=max(60, win // 4)).std()
    return (s - m) / sd


def causal_pct(s, win=None):
    """Каузальный перцентиль: доля прошлых наблюдений ниже текущего.
    win=None — вся доступная история ряда (расширяющееся окно)."""
    if win is None:
        return s.expanding(min_periods=60).apply(
            lambda x: 100.0 * (x[:-1] < x[-1]).mean() if len(x) > 1 else np.nan, raw=True)
    return s.rolling(win, min_periods=min(win, 250)).apply(
        lambda x: 100.0 * (x[:-1] < x[-1]).mean() if len(x) > 1 else np.nan, raw=True)


def speed(s, days=63):
    """Скорость движения: изменение за N календарных дней по календарю, не сдвигом."""
    out = {}
    idx = s.index
    for i, d in enumerate(idx):
        t = d - pd.Timedelta(days=days)
        j = idx.searchsorted(t)
        if j >= len(idx) or j == i:
            continue
        if abs((idx[j] - t).days) > 10:
            continue
        out[d] = s.iloc[i] - s.iloc[j]
    return pd.Series(out).sort_index()


def by_calendar(s, days):
    """Значение ряда N календарных дней назад с guard по датам."""
    if len(s) == 0:
        return None
    t = s.index[-1] - pd.Timedelta(days=days)
    j = s.index.searchsorted(t)
    if j >= len(s):
        j = len(s) - 1
    if abs((s.index[j] - t).days) > 12:
        return None
    return float(s.iloc[j])


def norm_block(s, name, long_win=None):
    """Уровень, Z, перцентиль, скорость и изменения — по одному ряду."""
    d = {}
    d["значение"] = round(float(s.iloc[-1]), 4)
    d["дата"] = s.index[-1].strftime("%Y-%m-%d")
    d["точек"] = int(len(s))
    d["начало"] = s.index[0].strftime("%Y-%m-%d")
    z = causal_z(s)
    if not math.isnan(z.iloc[-1]):
        d["z252"] = round(float(z.iloc[-1]), 2)
    p = causal_pct(s, long_win)
    if not math.isnan(p.iloc[-1]):
        d["перцентиль"] = round(float(p.iloc[-1]), 1)
        d["окно_перцентиля"] = ("вся доступная история" if long_win is None
                                else "%d торговых дней" % long_win)
    for lbl, days in (("d1н", 7), ("d4н", 28), ("d13н", 91), ("d52н", 364)):
        v = by_calendar(s, days)
        if v is not None:
            d[lbl] = round(float(s.iloc[-1]) - v, 4)
            if lbl == "d52н":
                d["год_назад"] = round(v, 4)
    sp = speed(s, 63)
    if len(sp):
        d["скорость63"] = round(float(sp.iloc[-1]), 4)
        pz = causal_z(sp)
        if len(pz) and not math.isnan(pz.iloc[-1]):
            d["скорость_z"] = round(float(pz.iloc[-1]), 2)
    return d


# ─────────────── Р.3 проверки на истории (event studies) ───────────────
def forward_ret(px, d0, days):
    """Форвардная доходность ряда цен от даты d0 на N календарных дней.
    Guard по датам: наблюдение вне окна ряда отбрасывается (иначе старые эпизоды
    получают фальшивую доходность от первой даты ряда)."""
    idx = px.index
    i = idx.searchsorted(d0)
    if i >= len(idx) or abs((idx[i] - d0).days) > 10:
        return None
    t = idx[i] + pd.Timedelta(days=int(days * 365 / 252))
    j = idx.searchsorted(t)
    if j >= len(idx) or abs((idx[j] - t).days) > 12:
        return None
    return 100.0 * (px.iloc[j] / px.iloc[i] - 1.0)


def episodes(mask, gap_days=126):
    """Непрерывные эпизоды: первая дата срабатывания, повторы внутри окна гасятся."""
    ds = [d for d, v in mask.items() if bool(v)]
    out = []
    for d in ds:
        if not out or (d - out[-1]).days > gap_days:
            out.append(d)
    return out


def event_study(name, dates, px, spread, horizons=(21, 63, 126, 252)):
    rows = []
    for d in dates:
        r = {"дата": d.strftime("%Y-%m-%d")}
        ok = False
        for h in horizons:
            v = forward_ret(px, d, h)
            if v is not None:
                r["r%d" % h] = round(v, 2)
                ok = True
        i = spread.index.searchsorted(d)
        if i < len(spread):
            r["спред"] = round(float(spread.iloc[i]), 2)
        if ok:
            rows.append(r)
    res = {"признак": name, "эпизодов": len(rows), "эпизоды": rows}
    if len(rows) >= 5:
        agg = {}
        for h in horizons:
            v = [r["r%d" % h] for r in rows if "r%d" % h in r]
            if len(v) >= 5:
                agg["r%d" % h] = {"медиана": round(float(np.median(v)), 2),
                                  "доля_плюс": round(100.0 * np.mean([x > 0 for x in v]), 1),
                                  "n": len(v)}
        res["агрегат"] = agg
    else:
        res["агрегат_не_публикуется"] = "эпизодов меньше пяти"
    return res


# ─────────────── Р.4 кредитный режим и переходы ───────────────
REGIMES = ["Здоровый", "Ухудшение", "Стресс", "Восстановление"]


def regime_series(spread, pct_win=2520, speed_days=63):
    """Классификатор 2×2: уровень (каузальный перцентиль) × направление (скорость)."""
    p = causal_pct(spread, pct_win)
    sp = speed(spread, speed_days)
    df = pd.DataFrame({"p": p, "sp": sp}).dropna()
    def cls(r):
        high = r["p"] >= 50.0
        up = r["sp"] > 0
        if not high and not up:
            return "Здоровый"
        if not high and up:
            return "Ухудшение"
        if high and up:
            return "Стресс"
        return "Восстановление"
    return df.apply(cls, axis=1)


def transitions(reg):
    """Матрица переходов на месячной сетке."""
    m = reg.resample("ME").last().dropna()
    cnt = {a: {b: 0 for b in REGIMES} for a in REGIMES}
    for a, b in zip(m.values[:-1], m.values[1:]):
        cnt[a][b] += 1
    prob = {}
    for a in REGIMES:
        tot = sum(cnt[a].values())
        prob[a] = ({b: round(100.0 * cnt[a][b] / tot, 1) for b in REGIMES}
                   if tot else None)
        if prob[a] is not None:
            prob[a]["n"] = tot
    return {"счёт": cnt, "вероятности_проц": prob, "месяцев": int(len(m))}


def conditional_returns(reg, px, horizons=(63, 252)):
    """Условные форвардные доходности рынка по режимам + безусловные."""
    out = {"по_режимам": {}, "безусловные": {}}
    m = reg.resample("ME").last().dropna()
    for h in horizons:
        allv = []
        for d in m.index:
            v = forward_ret(px, d, h)
            if v is not None:
                allv.append(v)
        if len(allv) >= 5:
            out["безусловные"]["r%d" % h] = {
                "медиана": round(float(np.median(allv)), 2),
                "p25": round(float(np.percentile(allv, 25)), 2),
                "p75": round(float(np.percentile(allv, 75)), 2),
                "доля_плюс": round(100.0 * np.mean([x > 0 for x in allv]), 1),
                "n": len(allv)}
    for rg in REGIMES:
        sub = m[m == rg]
        row = {"месяцев": int(len(sub))}
        for h in horizons:
            v = []
            for d in sub.index:
                x = forward_ret(px, d, h)
                if x is not None:
                    v.append(x)
            if len(v) >= 5:
                row["r%d" % h] = {"медиана": round(float(np.median(v)), 2),
                                  "p25": round(float(np.percentile(v, 25)), 2),
                                  "p75": round(float(np.percentile(v, 75)), 2),
                                  "доля_плюс": round(100.0 * np.mean([x > 0 for x in v]), 1),
                                  "n": len(v)}
            elif len(v):
                row["r%d_эпизодов" % h] = len(v)
        out["по_режимам"][rg] = row
    return out


# ─────────────── Р.5 кредит против рынка ───────────────
def lag_corr(spread, px, lags=(0, 5, 10, 21, 42, 63), win_years=(5, 10), horizon=63):
    """Корреляция уровня спреда с ФОРВАРДНОЙ доходностью рынка при лаге."""
    out = {}
    r = np.log(px).diff(horizon).shift(-horizon) * 100.0
    for wy in win_years:
        start = spread.index[-1] - pd.Timedelta(days=365 * wy)
        s = spread[spread.index >= start]
        rows = {}
        for L in lags:
            a, b = [], []
            for d, v in s.items():
                t = d + pd.Timedelta(days=L)
                j = r.index.searchsorted(t)
                if j >= len(r) or abs((r.index[j] - t).days) > 7:
                    continue
                y = r.iloc[j]
                if not np.isnan(y):
                    a.append(v); b.append(y)
            if len(a) >= 200:
                rows["lag%d" % L] = {"rho": round(float(np.corrcoef(a, b)[0, 1]), 3),
                                     "n": len(a)}
        out["окно_%dл" % wy] = rows
    return out


def logistic_widening(spread, horizon=63, thr_bp=0.50, split=0.7):
    """Логистическая регрессия расширения спреда. Порог публикации AUC 0.60
    и не менее 15 событий; ниже порога вероятность не публикуется."""
    z = causal_z(spread)
    p = causal_pct(spread, 2520)
    sp63 = speed(spread, 63)
    df = pd.DataFrame({"z": z, "p": p, "sp": sp63}).dropna()
    fwd = {}
    for d in df.index:
        t = d + pd.Timedelta(days=int(horizon * 365 / 252))
        j = spread.index.searchsorted(t)
        if j >= len(spread) or abs((spread.index[j] - t).days) > 12:
            continue
        fwd[d] = spread.iloc[j] - spread.loc[d]
    fwd = pd.Series(fwd)
    df = df.loc[df.index.intersection(fwd.index)]
    y = (fwd.loc[df.index] >= thr_bp).astype(int)
    n_ev = int(y.sum())
    res = {"событий": n_ev, "наблюдений": int(len(y)), "порог_расширения_пп": thr_bp,
           "горизонт_дней": horizon}
    if n_ev < 15 or len(y) < 200:
        res["исход"] = "порог не пройден: событий меньше пятнадцати"
        res["базовая_частота_проц"] = round(100.0 * float(y.mean()), 1) if len(y) else None
        return res
    X = df[["z", "p", "sp"]].values.astype(float)
    X = (X - X.mean(0)) / (X.std(0) + 1e-9)
    X = np.hstack([np.ones((len(X), 1)), X])
    yv = y.values.astype(float)
    k = int(len(X) * split)
    Xtr, ytr, Xte, yte = X[:k], yv[:k], X[k:], yv[k:]
    w = np.zeros(X.shape[1])
    for _ in range(400):
        pr = 1.0 / (1.0 + np.exp(-Xtr @ w))
        g = Xtr.T @ (pr - ytr) / len(ytr)
        H = Xtr.T @ (Xtr * (pr * (1 - pr))[:, None]) / len(ytr) + 1e-4 * np.eye(X.shape[1])
        try:
            w -= np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            break
    pte = 1.0 / (1.0 + np.exp(-Xte @ w))
    if len(np.unique(yte)) < 2:
        res["исход"] = "порог не пройден: во второй половине выборки нет событий"
        res["базовая_частота_проц"] = round(100.0 * float(y.mean()), 1)
        return res
    order = np.argsort(pte)
    rank = np.empty(len(pte)); rank[order] = np.arange(1, len(pte) + 1)
    n1 = yte.sum(); n0 = len(yte) - n1
    auc = (rank[yte == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
    res["auc"] = round(float(auc), 3)
    res["базовая_частота_проц"] = round(100.0 * float(y.mean()), 1)
    res["исход"] = ("модель принята" if auc >= 0.60 else
                    "порог не пройден: AUC ниже 0,60, откат на безусловную частоту")
    return res


def spread_vs_vol(spread, vix):
    """Кросс-чек цены риска: регрессия спреда на индекс волатильности."""
    df = pd.DataFrame({"s": spread, "v": vix}).dropna()
    if len(df) < 200:
        return {"исход": "наблюдений недостаточно"}
    x, y = df["v"].values, df["s"].values
    b = np.polyfit(x, y, 1)
    yh = np.polyval(b, x)
    ss = 1 - ((y - yh) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    return {"r2": round(float(ss), 3), "n": int(len(df)),
            "наклон": round(float(b[0]), 4),
            "исход": ("связь работает" if ss >= 0.30 else
                      "R² ниже 0,30 — только иллюстративно")}


# ─────────────── Р.6 кредитный импульс ───────────────
def credit_impulse(nfc_debt, hh_debt, gdp):
    """Импульс кредита: вторая производная долга к ВВП.
    Долг в млн, ВВП в млрд — приводится к одной размерности."""
    d = (nfc_debt + hh_debt) / 1000.0            # млн → млрд
    df = pd.DataFrame({"debt": d, "gdp": gdp}).dropna()
    flow = df["debt"].diff()                      # прирост долга за квартал
    imp = (flow.diff() / df["gdp"]) * 100.0       # изменение прироста к ВВП
    return imp.dropna()


def rolling_corr_growth(imp, gdp, lead_q=4, win=(20, 40)):
    """Скользящая корреляция импульса с форвардным ростом ВВП."""
    g = (gdp.pct_change(4) * 100.0).shift(-lead_q)
    df = pd.DataFrame({"i": imp, "g": g}).dropna()
    out = {}
    for w in win:
        if len(df) >= w:
            sub = df.tail(w)
            out["окно_%dкв" % w] = {"rho": round(float(np.corrcoef(sub["i"], sub["g"])[0, 1]), 3),
                                    "n": int(w)}
    if len(df) >= 20:
        out["вся_история"] = {"rho": round(float(np.corrcoef(df["i"], df["g"])[0, 1]), 3),
                              "n": int(len(df))}
    return out


# ─────────────── Р.7 фундаментальная матрица ───────────────
def quality_matrix(levels, basket_rows):
    """Сегмент качества: спред · перцентиль · фундаментал корзины · оценка премии.
    Правило детерминированное: премия избыточна, если спред в верхнем терциле
    своего диапазона при нейтральном или улучшающемся фундаментале; не обеспечена —
    если спред в нижнем терциле при ухудшающемся фундаментале."""
    fund = basket_summary(basket_rows)
    direction = "ухудшающийся" if fund["доля_прибыль_вниз_проц"] >= 50 else "нейтральный"
    rows = []
    for seg, d in levels.items():
        p = d.get("перцентиль")
        if p is None:
            continue
        if p >= 66.7:
            tercile = "верхний"
        elif p <= 33.3:
            tercile = "нижний"
        else:
            tercile = "средний"
        if tercile == "верхний" and direction != "ухудшающийся":
            verdict = "премия избыточна"
        elif tercile == "нижний" and direction == "ухудшающийся":
            verdict = "премия не обеспечена"
        else:
            verdict = "премия обеспечена"
        rows.append({"сегмент": seg, "спред": d["значение"], "перцентиль": p,
                     "терциль": tercile, "фундаментал": direction, "оценка": verdict})
    return {"строки": rows, "фундаментал_корзины": fund}


def basket_summary(rows):
    ok = [r for r in rows if not r.get("отсев")]
    lev = [r["чистый_долг_к_ebitda"] for r in ok if r.get("чистый_долг_к_ebitda") is not None]
    cov = [r["покрытие_процентов"] for r in ok if r.get("покрытие_процентов") is not None]
    fcf = [r["fcf_к_долгу_проц"] for r in ok if r.get("fcf_к_долгу_проц") is not None]
    dn = [r["прибыль_снизилась"] for r in ok if r.get("прибыль_снизилась") is not None]
    out = {"эмитентов_в_корзине": len(rows), "закрыто": len(ok),
           "отсев": [r["тикер"] for r in rows if r.get("отсев")],
           "отрицательная_ebitda": [r["тикер"] for r in ok if r.get("ebitda_отрицательна")]}
    if lev:
        out["чистый_долг_к_ebitda_медиана"] = round(float(np.median(lev)), 2)
        out["чистый_долг_к_ebitda_верх_квартиль"] = round(float(np.percentile(lev, 75)), 2)
        out["n_леверидж"] = len(lev)
    if cov:
        out["покрытие_процентов_медиана"] = round(float(np.median(cov)), 2)
        out["покрытие_нижний_квартиль"] = round(float(np.percentile(cov, 25)), 2)
        out["n_покрытие"] = len(cov)
    if fcf:
        out["fcf_к_долгу_медиана_проц"] = round(float(np.median(fcf)), 1)
        out["n_fcf"] = len(fcf)
    if dn:
        out["доля_прибыль_вниз_проц"] = round(100.0 * float(np.mean(dn)), 1)
        out["n_прибыль"] = len(dn)
    return out


def maturity_wall(rows):
    """Лестница погашений корзины: ближайшие двенадцать месяцев и второй год."""
    y1 = y2 = y3 = 0.0
    n = 0
    for r in rows:
        p = r.get("погашения")
        if not p or "y1" not in p or "y2" not in p:
            continue
        n += 1
        y1 += p.get("y1", 0) or 0
        y2 += p.get("y2", 0) or 0
        y3 += p.get("y3", 0) or 0
    if not n:
        return None
    return {"эмитентов": n, "год_1_млрд": round(y1 / 1e9, 1),
            "год_2_млрд": round(y2 / 1e9, 1), "год_3_млрд": round(y3 / 1e9, 1)}


# ─────────────── Р.8 Credit Score ───────────────
def score_block(parts):
    """Детерминированный Score 0–100 с фиксированными весами блоков.
    Больше значение — здоровее кредит. Нормировка на покрытие;
    ниже 70 % покрытия Score не публикуется."""
    W = {"А_цена": 0.26, "Б_международный": 0.08, "В_фундаментал": 0.22,
         "Г_количество": 0.10, "Д_фондирование": 0.14, "Ж_дефолты": 0.12,
         "И_приватный": 0.08}
    got = {k: v for k, v in parts.items() if v is not None}
    wsum = sum(W[k] for k in got)
    cover = 100.0 * wsum / sum(W.values())
    if cover < 70.0:
        return {"покрытие_проц": round(cover, 1), "публикуется": False,
                "саб_скоры": {k: round(v, 1) for k, v in got.items()}}
    sc = sum(W[k] * got[k] for k in got) / wsum
    sens = {}
    for k in got:
        rest = {x: y for x, y in got.items() if x != k}
        w2 = sum(W[x] for x in rest)
        sens[k] = round(sc - (sum(W[x] * rest[x] for x in rest) / w2), 1) if w2 else None
    return {"score": round(sc, 1), "покрытие_проц": round(cover, 1), "публикуется": True,
            "саб_скоры": {k: round(v, 1) for k, v in got.items()},
            "веса": W, "чувствительность": sens}


# ─────────────── Р.9 бэктест правила распределения ───────────────
def backtest(reg, px, tbill):
    """Правило: полная доля в акциях в «Здоровом» и «Восстановлении», половина в
    «Ухудшении», ноль в «Стрессе» с переходом в казначейские бумаги.
    Правило фиксировано заранее и под результат не подбирается."""
    m = reg.resample("ME").last().dropna()
    pxm = px.resample("ME").last().dropna()
    tb = tbill.resample("ME").last().dropna() / 100.0 / 12.0
    idx = m.index.intersection(pxm.index)
    idx = idx[idx >= max(m.index[0], pxm.index[0])]
    if len(idx) < 60:
        return {"исход": "истории недостаточно"}
    share = {"Здоровый": 1.0, "Восстановление": 1.0, "Ухудшение": 0.5, "Стресс": 0.0}
    eq = pxm.reindex(idx).pct_change()
    cash = tb.reindex(idx).ffill().fillna(0.0)
    w = m.reindex(idx).map(share).shift(1)          # каузально: вес по прошлому месяцу
    r = (w * eq + (1 - w) * cash).dropna()
    bh = eq.reindex(r.index)
    def stats(x):
        cum = (1 + x).cumprod()
        yrs = (x.index[-1] - x.index[0]).days / 365.25
        cagr = 100.0 * (cum.iloc[-1] ** (1 / yrs) - 1)
        dd = 100.0 * (cum / cum.cummax() - 1).min()
        return round(float(cagr), 2), round(float(dd), 1)
    c1, d1 = stats(r)
    c2, d2 = stats(bh)
    years = {}
    for y, g in r.groupby(r.index.year):
        years[int(y)] = round(100.0 * float((1 + g).prod() - 1), 1)
    trades = int((w.diff().abs() > 1e-9).sum())
    out_of_market = round(100.0 * float((w == 0).mean()), 1)
    return {"правило_годовых_проц": c1, "правило_просадка_проц": d1,
            "эталон_годовых_проц": c2, "эталон_просадка_проц": d2,
            "доля_вне_рынка_проц": out_of_market, "сделок": trades,
            "месяцев": int(len(r)), "период": "%s — %s" % (r.index[0].date(), r.index[-1].date()),
            "по_годам_проц": years,
            "оговорка": "правило проверено на истории того же ряда, из которого построен "
                        "Score; это не выведенная вне выборки проверка",
            "вывод": "Credit Score описывает состояние кредитного рынка, сигналом на "
                     "распределение капитала не работает"}


# ─────────────── Р.10 сценарии ───────────────
def scenarios(trans, reg_now, steps_q=3, steps_y=15):
    """Веса из матрицы переходов, приведённые к накопленной вероятности."""
    P = trans["вероятности_проц"]
    order = REGIMES
    M = np.array([[(P[a] or {}).get(b, 0.0) / 100.0 for b in order] for a in order])
    v = np.zeros(len(order)); v[order.index(reg_now)] = 1.0
    def walk(n):
        x = v.copy()
        for _ in range(n):
            x = x @ M
        return dict(zip(order, (100.0 * x).round(1)))
    q, y = walk(steps_q), walk(steps_y)
    def fold(d):
        calm = d["Здоровый"] + d["Восстановление"]
        worse = d["Ухудшение"]
        stress = d["Стресс"]
        t = calm + worse + stress
        return {"спокойный": round(100.0 * calm / t, 1),
                "ухудшение": round(100.0 * worse / t, 1),
                "стресс": round(100.0 * stress / t, 1)}
    return {"квартал": fold(q), "год": fold(y), "шагов_квартал": steps_q, "шагов_год": steps_y,
            "распределение_квартал": q, "распределение_год": y}


def total_return_range(spread_pp, yield_pp, loss_pp):
    """Диапазон совокупной доходности кредита на год: доходность минус потери
    плюс переоценка от движения спреда. Арифметика, не оценка на глаз."""
    dur = 3.8   # дюрация индекса высокодоходных облигаций, лет
    out = {}
    for name, dsp in (("спокойный", -0.30), ("ухудшение", 0.80), ("стресс", 3.00)):
        lo = yield_pp - loss_pp - dur * max(dsp, 0) - 0.5
        hi = yield_pp - loss_pp - dur * min(dsp, 0) + 0.5
        out[name] = [round(min(lo, hi), 1), round(max(lo, hi), 1)]
    out["дюрация_лет"] = dur
    return out


# ─────────────────────────── сборка ───────────────────────────
LADDER = [("AAA", "aaa"), ("AA", "aa"), ("A", "a"), ("BBB", "bbb"),
          ("BB", "bb"), ("B", "b"), ("CCC", "ccc")]
NYIG = ["PDPOSCSBND-L13", "PDPOSCSBND-G13", "PDPOSCSBND-G5L10", "PDPOSCSBND-G10"]
NYHY = ["PDPOSCSBND-BELL13", "PDPOSCSBND-BELG13", "PDPOSCSBND-BELG5L10", "PDPOSCSBND-BELG10"]
NYTI = ["PDTRCSIND-L13", "PDTRCSIND-G13", "PDTRCSIND-G5L10", "PDTRCSIND-G10"]
NYTH = ["PDTRCSIND-BELL13", "PDTRCSIND-BELG13", "PDTRCSIND-BELG5L10", "PDTRCSIND-BELG10"]
RECOVERY = 0.40


def nyagg(data, keys):
    ss = [load_nyfed(data, k) for k in keys]
    return pd.concat(ss, axis=1).dropna().sum(axis=1)


def main():
    ap = argparse.ArgumentParser(description="Расчёт выпуска «Кредитный цикл»")
    ap.add_argument("--cutoff", required=True, help="дата выпуска, ГГГГ-ММ-ДД")
    ap.add_argument("--data", default="data", help="каталог кэша рядов")
    ap.add_argument("--out", default="out", help="каталог артефактов прогона")
    ap.add_argument("--spot", default=None,
                    help="файл JSON с точечными значениями Фазы 1; без него "
                         "они уходят пробелами в журнал")
    ap.add_argument("--skip-fetch", action="store_true",
                    help="не ходить в сеть, считать по кэшу")
    ap.add_argument("--no-state", action="store_true",
                    help="не читать хранилище: считать без переноса значений")
    ap.add_argument("--что-искать", dest="ask", action="store_true",
                    help="напечатать, что добирать поиском на этом срезе, и выйти")
    a = ap.parse_args()
    global DATA
    DATA = a.data
    os.makedirs(a.data, exist_ok=True)
    os.makedirs(a.out, exist_ok=True)
    if a.ask:
        что_искать(a.cutoff, a.out)
        return 0
    prev = None
    if not a.no_state:
        try:
            prev = amin_run.state_get("credit")
        except Exception as e:
            print("состояние прошлого прогона не прочитано: %s" % e)
    if not a.skip_fetch:
        print("Фаза 0: каналы")
        fetch_fred()
        fetch_market()
        # Отчётность выходит раз в квартал. Разобранная корзина из прошлого
        # снимка годится, пока квартал не сменился, — это минус 90 МБ и
        # минус 20 секунд с каждого недельного прогона.
        готовая = (prev or {}).get("корзина_разбор")
        if свежий_квартал(готовая, a.cutoff):
            print("  EDGAR: разбор корзины взят из снимка %s, квартал не сменился"
                  % (prev or {}).get("выпуск", ""))
            fetch_edgar(only=BDC)
        else:
            fetch_edgar()
    L = Log(out=a.out, code="credit", cutoff=a.cutoff)
    R, CH = {}, {}
    R["срез"] = a.cutoff

    # ── Фаза 0: ряды
    F = {}
    for k in ("hy", "ig", "bbb", "bb", "b", "ccc", "aaa", "aa", "a", "hy_yield",
              "vix", "baa10y", "aaa10y", "eu_hy", "em_corp", "asia",
              "cp_fin", "cp_nonfin", "tbill3m", "sofr",
              "dgs1", "dgs2", "dgs3", "dgs5", "dgs7", "dgs10", "dgs20", "dgs30",
              "cp_out", "cp_nfin_out", "cp_fin_out", "cp_ab", "nasdaq"):
        F[k] = load_fred(a.data, k)
        L.series(k, "FRED через посредник сайта", F[k].index[-1], len(F[k]), layer="быстрый")
    # постоянный лаг канала — норма реестра, а не устаревший ряд
    for k in ("nfci", "anfci", "stlfsi", "bank_credit", "cp_nonfin", "cp_fin"):
        L.series(k, "FRED через посредник сайта", F[k].index[-1] if k in F else "",
                 len(F[k]) if k in F else 0, layer="быстрый",
                 note="замена: постоянный лаг канала, значение среза — котировка снимка")
    for k in ("nfci", "anfci", "stlfsi", "bank_credit",
              "cp_out", "cp_nfin_out", "cp_fin_out", "cp_ab"):
        F[k] = load_fred(a.data, k)
        L.series(k, "FRED через посредник сайта", F[k].index[-1], len(F[k]), layer="быстрый",
                 note="замена: постоянный лаг канала, ряд недельный")
    for k in ("ci", "consumer", "realln", "nfc_debt", "hh_debt", "gdp",
              "sloos_ci_large", "sloos_ci_small", "sloos_cc", "sloos_sub", "sloos_demand",
              "del_business", "del_consumer", "del_cc", "del_mortgage", "del_cre",
              "del_all", "co_business", "co_consumer", "co_cc"):
        F[k] = load_fred(a.data, k)
        L.series(k, "FRED через посредник сайта", F[k].index[-1], len(F[k]), layer="медленный")

    # ── А. лестница качества
    lad = {}
    for lbl, k in LADDER:
        lad[lbl] = norm_block(F[k], lbl)
    R["лестница"] = lad
    R["агрегаты"] = {"HY": norm_block(F["hy"], "HY"), "IG": norm_block(F["ig"], "IG"),
                     "доходность_HY": norm_block(F["hy_yield"], "доходность HY")}
    gap_cb = (F["ccc"] - F["bb"]).dropna()
    gap_bbbb = (F["bb"] - F["bbb"]).dropna()
    R["разрывы"] = {"CCC−BB": norm_block(gap_cb, "CCC−BB"),
                    "BB−BBB": norm_block(gap_bbbb, "BB−BBB")}
    R["длинная_база"] = {"BAA10Y": norm_block(F["baa10y"], "BAA10Y", 2520),
                         "AAA10Y": norm_block(F["aaa10y"], "AAA10Y", 2520)}

    # заложенная в спред дефолтность против фактической
    imp = float(F["hy"].iloc[-1]) / (1 - RECOVERY)
    R["дефолтность"] = {"заложенная_в_спред_проц": round(imp, 2),
                        "восстановление_допущение_проц": RECOVERY * 100,
                        "списания_по_бизнес_кредитам_проц": round(float(F["co_business"].iloc[-1]), 2),
                        "дата_списаний": F["co_business"].index[-1].strftime("%Y-%m-%d")}

    # ── Б. международный разрез
    intl = {}
    for lbl, k in (("Европа", "eu_hy"), ("EM", "em_corp"), ("Азия", "asia")):
        intl[lbl] = norm_block(F[k], lbl)
    d_eu = (F["hy"] - F["eu_hy"]).dropna()
    d_as = (F["hy"] - F["asia"]).dropna()
    intl["США_минус_Европа"] = norm_block(d_eu, "США−Европа")
    intl["США_минус_Азия"] = norm_block(d_as, "США−Азия")
    R["международный"] = intl

    # ── Д. фондирование и микроструктура
    cp_sp = (F["cp_fin"] - F["tbill3m"]).dropna()
    R["фондирование"] = {
        "cp_финансовые": norm_block(F["cp_fin"], "CP fin"),
        "cp_нефинансовые": norm_block(F["cp_nonfin"], "CP nonfin"),
        "cp_минус_вексель": norm_block(cp_sp, "CP−вексель"),
        "sofr": norm_block(F["sofr"], "SOFR"),
        "nfci": norm_block(F["nfci"], "NFCI", 2520),
        "anfci": norm_block(F["anfci"], "ANFCI", 2520),
        "объём_cp_млрд": norm_block(F["cp_out"], "CP outstanding"),
    }
    pos_ig = nyagg(a.data, NYIG); pos_hy = nyagg(a.data, NYHY)
    tr_ig = nyagg(a.data, NYTI); tr_hy = nyagg(a.data, NYTH)
    for nm, s in (("позиции_ig", pos_ig), ("позиции_hy", pos_hy),
                  ("оборот_ig", tr_ig), ("оборот_hy", tr_hy)):
        L.series(nm, "ФРБ Нью-Йорка, дилерская статистика", s.index[-1], len(s),
                 layer="медленный", note="недельный ряд с лагом публикации около двух недель")
    micro = {}
    for nm, s in (("позиции_ig", pos_ig), ("позиции_hy", pos_hy),
                  ("оборот_ig", tr_ig), ("оборот_hy", tr_hy)):
        micro[nm] = norm_block(s, nm)
    for seg, pos, tr in (("ig", pos_ig, tr_ig), ("hy", pos_hy, tr_hy)):
        if float(pos.iloc[-1]) > 0:
            micro["оборот_к_запасу_" + seg] = round(float(tr.iloc[-1] / pos.iloc[-1]), 2)
        else:
            micro["оборот_к_запасу_" + seg] = None
            micro["оборот_к_запасу_%s_почему" % seg] = (
                "чистая позиция дилеров отрицательна — отношение не определено")
    R["микроструктура"] = micro

    # ── Г. количество и поток
    R["количество"] = {
        "банковский_кредит": norm_block(F["bank_credit"], "банковский кредит"),
        "ci": norm_block(F["ci"], "C&I"),
        "потребительский": norm_block(F["consumer"], "потребительский"),
        "недвижимость": norm_block(F["realln"], "недвижимость"),
        "sloos_стандарты_крупные": float(F["sloos_ci_large"].iloc[-1]),
        "sloos_стандарты_малые": float(F["sloos_ci_small"].iloc[-1]),
        "sloos_карты": float(F["sloos_cc"].iloc[-1]),
        "sloos_субпрайм": float(F["sloos_sub"].iloc[-1]),
        "sloos_спрос": float(F["sloos_demand"].iloc[-1]),
        "sloos_дата": F["sloos_ci_large"].index[-1].strftime("%Y-%m-%d"),
    }
    imp_s = credit_impulse(F["nfc_debt"], F["hh_debt"], F["gdp"])
    R["импульс"] = {"значение": round(float(imp_s.iloc[-1]), 2),
                    "дата": imp_s.index[-1].strftime("%Y-%m-%d"),
                    "год_назад": round(float(imp_s.iloc[-5]), 2) if len(imp_s) > 5 else None,
                    "корреляция_с_ростом": rolling_corr_growth(imp_s, F["gdp"])}
    L.value("кредитный_импульс", R["импульс"]["значение"], "FRED BCNSDODNS+CMDEBT/GDP",
            R["импульс"]["дата"], "% ВВП")

    # ── Ж. дефолтный цикл
    R["дефолтный_цикл"] = {k: {"значение": round(float(F[k].iloc[-1]), 2),
                               "дата": F[k].index[-1].strftime("%Y-%m-%d"),
                               "год_назад": round(float(F[k].iloc[-5]), 2) if len(F[k]) > 5 else None}
                           for k in ("del_business", "del_cc", "del_cre", "del_all",
                                     "co_business", "co_cc")}

    # ── З. кривая и чувствительность к ставке
    curve = {k: round(float(F[k].iloc[-1]), 3) for k in
             ("tbill3m", "dgs1", "dgs2", "dgs3", "dgs5", "dgs7", "dgs10", "dgs20", "dgs30")}
    curve["наклон_10_2"] = round(curve["dgs10"] - curve["dgs2"], 3)
    fwd = {}
    for a1, a2, l1, l2 in ((1, 2, "1г", "2г"), (2, 3, "2г", "3г"), (5, 10, "5л", "10л")):
        y1 = curve["dgs%d" % a1] / 100.0; y2 = curve["dgs%d" % a2] / 100.0
        f = ((1 + y2) ** a2 / (1 + y1) ** a1) ** (1.0 / (a2 - a1)) - 1
        fwd["форвард_%s_через_%s" % (l2, l1)] = round(100.0 * f, 2)
    curve["форварды"] = fwd
    sens = {}
    for lbl, k in LADDER + [("HY", "hy"), ("IG", "ig")]:
        df = pd.DataFrame({"s": F[k].diff(), "y": F["dgs10"].diff()}).dropna()
        if len(df) > 200:
            b = np.polyfit(df["y"], df["s"], 1)
            sens[lbl] = {"бета_3г": round(float(b[0]), 3), "n": int(len(df))}
    dfl = pd.DataFrame({"s": F["baa10y"].diff(), "y": F["dgs10"].diff()}).dropna()
    dfl = dfl[dfl.index >= dfl.index[-1] - pd.Timedelta(days=3650)]
    b = np.polyfit(dfl["y"], dfl["s"], 1)
    sens["BAA10Y_10л"] = {"бета_10л": round(float(b[0]), 3), "n": int(len(dfl))}
    R["ставки"] = {"кривая": curve, "чувствительность": sens}

    # ── Р.3 проверки на истории
    baa = F["baa10y"]; nq = F["nasdaq"]
    sp63 = speed(baa, 63)
    ev = {}
    ev["расширение_50бп"] = event_study("расширение BAA10Y на 50 б.п. за 63 дня",
                                        episodes((sp63 >= 0.50)), nq, baa)
    ev["расширение_100бп"] = event_study("расширение BAA10Y на 100 б.п. за 63 дня",
                                         episodes((sp63 >= 1.00)), nq, baa)
    gp = causal_pct(gap_cb)
    ev["разрыв_ccc_bb_выше_p80"] = event_study("разрыв CCC−BB выше 80-го перцентиля",
                                               episodes((gp >= 80)), nq, gap_cb)
    sl = F["sloos_ci_large"]
    ev["разворот_sloos"] = event_study("разворот SLOOS в нетто-ужесточение",
                                       episodes(((sl > 0) & (sl.shift(1) <= 0)).dropna()), nq, baa)
    cpp = causal_pct(cp_sp)
    ev["всплеск_cp"] = event_study("всплеск спреда коммерческих бумаг к векселю",
                                   episodes((cpp >= 95)), nq, cp_sp)
    R["проверки_на_истории"] = ev

    # ── Р.4 режим
    reg = regime_series(baa)
    reg_now = str(reg.iloc[-1])
    m = reg.resample("ME").last().dropna()
    months = 1
    for i in range(len(m) - 2, -1, -1):
        if m.iloc[i] == reg_now:
            months += 1
        else:
            break
    R["режим"] = {"текущий": reg_now, "месяцев_в_режиме": months,
                  "дата": reg.index[-1].strftime("%Y-%m-%d"),
                  "перцентиль_уровня": round(float(causal_pct(baa, 2520).iloc[-1]), 1),
                  "скорость_63д": round(float(sp63.iloc[-1]), 3)}
    tr = transitions(reg)
    R["переходы"] = tr
    R["условные_доходности"] = conditional_returns(reg, nq)

    # ── Р.5
    R["кредит_против_рынка"] = {
        "лаговые_корреляции": lag_corr(baa, nq),
        "модель_расширения": logistic_widening(baa),
        "спред_против_волатильности": spread_vs_vol(F["hy"], F["vix"]),
    }

    # ── Р.7 фундаментал
    готовая = (prev or {}).get("корзина_разбор")
    if свежий_квартал(готовая, a.cutoff):
        basket = готовая
        R["корзина_из_снимка"] = (prev or {}).get("выпуск")
    else:
        basket = basket_rows(a.data)
    for r in basket:
        if not r.get("отсев"):
            L.series("корзина_" + r["тикер"], "EDGAR XBRL companyfacts",
                     r.get("ebitda_дата", ""), 1, layer="медленный")
    levels = {lbl: lad[lbl] for lbl, _ in LADDER}
    R["матрица"] = quality_matrix(levels, basket)
    R["корзина"] = basket_summary(basket)
    R["корзина"]["состав"] = [r["тикер"] for r in basket]
    R["корзина_разбор"] = basket        # вход следующего прогона: кладётся в снимок
    R["стена_погашений"] = maturity_wall(basket)

    # ── Р.8 Score
    def inv(p):     # перцентиль спреда → балл здоровья
        return 100.0 - p
    parts = {}
    parts["А_цена"] = float(np.mean([inv(lad[l]["перцентиль"]) for l, _ in LADDER
                                     if "перцентиль" in lad[l]]))
    parts["Б_международный"] = float(inv(intl["Европа"].get("перцентиль", 50)))
    fs = R["корзина"]
    lev_sc = max(0.0, min(100.0, 100.0 - 12.0 * fs.get("чистый_долг_к_ebitda_медиана", 4.0)))
    cov_sc = max(0.0, min(100.0, 10.0 * fs.get("покрытие_процентов_медиана", 4.0)))
    dn_sc = 100.0 - fs.get("доля_прибыль_вниз_проц", 50.0)
    parts["В_фундаментал"] = float(np.mean([lev_sc, cov_sc, dn_sc]))
    parts["Г_количество"] = float(np.clip(50.0 + 5.0 * R["импульс"]["значение"], 0, 100))
    fund_p = np.mean([R["фондирование"]["cp_минус_вексель"].get("перцентиль", 50),
                      R["фондирование"]["nfci"].get("перцентиль", 50)])
    parts["Д_фондирование"] = float(100.0 - fund_p)
    parts["Ж_дефолты"] = float(np.clip(100.0 - 30.0 * F["co_business"].iloc[-1], 0, 100))
    parts["И_приватный"] = None                      # заполняется Фазой 1
    R["score_вход"] = parts

    # ── Р.9 бэктест
    R["бэктест"] = backtest(reg, nq, F["tbill3m"])

    # ── Р.10 сценарии
    _sc = scenarios(tr, reg_now)
    # плоский словарь весов остаётся под ключом «сценарии»: проверка перед выдачей
    # сверяет сумму именно по нему, вложенные величины ей мешают
    R["сценарии"] = _sc["квартал"]
    R["сценарии_год"] = _sc["год"]
    R["сценарии_метод"] = {k: v for k, v in _sc.items() if k not in ("квартал", "год")}
    R["диапазон_год_проц"] = total_return_range(
        float(F["hy"].iloc[-1]), float(F["hy_yield"].iloc[-1]),
        imp * (1 - RECOVERY))

    # ── данные графиков
    def ser(s, n=None):
        x = s.tail(n) if n else s
        return {"даты": [d.strftime("%Y-%m-%d") for d in x.index],
                "значения": [round(float(v), 4) for v in x.values]}
    CH["лестница_история"] = {l: ser(F[k], 787) for l, k in LADDER}
    CH["разрыв_ccc_bb"] = ser(gap_cb)
    CH["разрыв_bb_bbb"] = ser(gap_bbbb)
    CH["hy_ig"] = {"HY": ser(F["hy"]), "IG": ser(F["ig"])}
    CH["международный"] = {"США": ser(F["hy"]), "Европа": ser(F["eu_hy"]), "Азия": ser(F["asia"])}
    CH["baa10y"] = ser(baa[baa.index >= baa.index[-1] - pd.Timedelta(days=3700)])
    CH["дилеры"] = {"позиции_ig": ser(pos_ig, 260), "позиции_hy": ser(pos_hy, 260),
                    "оборот_ig": ser(tr_ig, 260), "оборот_hy": ser(tr_hy, 260)}
    CH["cp_спред"] = ser(cp_sp[cp_sp.index >= cp_sp.index[-1] - pd.Timedelta(days=1900)])
    CH["импульс"] = ser(imp_s)

    # ── Фаза 1: точечные значения прогона через журнал
    spot = json.load(open(a.spot, encoding="utf-8")) if a.spot else None
    R = phase1(R, L, spot, a.data, prev)

    json.dump(R, open(os.path.join(a.out, "calc.json"), "w"), ensure_ascii=False,
              indent=1, default=str)
    json.dump(CH, open(os.path.join(a.out, "charts.json"), "w"), ensure_ascii=False,
              default=str)
    sc = R.get("score") or {}
    print("режим: %s, %d мес. · Score %s при покрытии %s %%"
          % (reg_now, months, sc.get("score"), sc.get("покрытие_проц")))
    if R.get("перенесено_из_снимка"):
        print("перенесено из прошлого снимка: %d — %s"
              % (len(R["перенесено_из_снимка"]), ", ".join(R["перенесено_из_снимка"])))
    if R.get("пробелы_фазы_1"):
        print("пробелов Фазы 1: %d — %s"
              % (len(R["пробелы_фазы_1"]), ", ".join(R["пробелы_фазы_1"])))
    print("calc.json и charts.json готовы")


def что_искать(cutoff, out="out"):
    """Печатает, что прогон обязан добрать поиском на этом срезе.
    Запускается ДО расчёта: список короче полного перечня ровно на то, что
    снимает код и что ещё живо в прошлом снимке."""
    try:
        prev = amin_run.state_get("credit")
    except Exception:
        prev = None
    need, carried = spot_needed(cutoff, prev)
    print("К ПОИСКУ на срез %s: %d из %d" % (cutoff, len(need), len(SPOT_KEYS)))
    for key, что, частота in need:
        print("  · %-36s %-9s %s" % (key, частота, что))
    if carried:
        print("Переносится из снимка %s: %d" % ((prev or {}).get("выпуск", ""), len(carried)))
        for key in sorted(carried):
            print("  · %-36s от %s" % (key, carried[key].get("дата", "")))
    print("Снимает код: индексы обязательств под кредиты, доля дохода записью.")
    return need

if __name__ == "__main__":
    sys.exit(main() or 0)
