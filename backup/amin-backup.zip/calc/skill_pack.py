#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сборка набора правил в файл установки — с объявлением редакции.

Прежде сборка и объявление редакции были двумя действиями. Собравший набор
отдавал файл и должен был помнить про вторую команду; забывал — и следующий
прогон вставал на расхождении, которого нет по существу. Здесь оба действия
слиты в одно: файл собран — редакция объявлена, разойтись им больше негде.
Расхождение теперь означает ровно то, ради чего сторож заведён: у издателя
стоит не тот набор, который собран.

    python3 skill_pack.py <каталог набора> [<куда положить>]
    python3 skill_pack.py <каталог> --без-объявления

Отпечаток берётся не с исходного каталога, а с содержимого собранного файла:
упаковщик выбрасывает часть каталогов, и считать надо ровно то, что издатель
поставит. Объявляется ОДИН набор — тот, что собран; записи о соседях остаются
прежними.
"""
import os
import shutil
import sys
import tempfile
import zipfile

УПАКОВЩИК = "/mnt/skills/examples/skill-creator"
ВЫДАЧА = "/mnt/user-data/outputs"


def _сторож():
    """Сторож редакций. Лежит рядом — приходит на машину той же командой
    `amin_run.py --calc-sync`, что и этот файл."""
    здесь = os.path.dirname(os.path.abspath(__file__))
    if здесь not in sys.path:
        sys.path.insert(0, здесь)
    try:
        import skills_print
    except ImportError:
        raise SystemExit(
            "нет skills_print.py — возьмите его командой "
            "`python3 amin_run.py --calc-get skills_print.py --dest .`")
    return skills_print


def собрать(каталог, куда=None):
    """Собирает файл установки. Возвращает путь к нему."""
    каталог = os.path.abspath(каталог.rstrip("/"))
    if not os.path.isfile(os.path.join(каталог, "SKILL.md")):
        raise SystemExit("в каталоге %s нет SKILL.md" % каталог)
    if УПАКОВЩИК not in sys.path:
        sys.path.insert(0, УПАКОВЩИК)
    from scripts.package_skill import package_skill
    итог = package_skill(каталог, куда or ВЫДАЧА)
    if not итог:
        raise SystemExit("упаковщик отказал — см. его сообщение выше")
    return str(итог)


def отпечаток_архива(архив, имя):
    """Отпечаток того каталога, который получит издатель после установки."""
    сторож = _сторож()
    временный = tempfile.mkdtemp(prefix="skill-pack-")
    try:
        with zipfile.ZipFile(архив) as z:
            z.extractall(временный)
        корень = os.path.join(временный, имя)
        if not os.path.isdir(корень):
            raise SystemExit("в собранном файле нет каталога %s" % имя)
        return сторож.отпечаток(корень)
    finally:
        shutil.rmtree(временный, ignore_errors=True)


def объявить(имя, отпечаток):
    """Объявляет ожидаемой редакцию одного набора. Соседи не трогаются."""
    сторож = _сторож()
    if имя not in сторож.СКИЛЛЫ:
        print("· %s сторож не сторожит — объявлять нечего" % имя)
        return None
    запись = dict(сторож.ожидаемые() or {})
    было = запись.get(имя)
    запись[имя] = отпечаток
    _, код = сторож._запрос({"state": {"скиллы": запись}})
    if код != 200:
        raise SystemExit("запись ожидаемой редакции не прошла: код %s" % код)
    return было


def main(аргументы):
    if not аргументы or аргументы[0].startswith("--"):
        print(__doc__)
        return 1
    каталог = аргументы[0]
    объявлять = "--без-объявления" not in аргументы
    прочие = [а for а in аргументы[1:] if not а.startswith("--")]
    куда = прочие[0] if прочие else None

    имя = os.path.basename(os.path.abspath(каталог.rstrip("/")))
    архив = собрать(каталог, куда)
    отпечаток = отпечаток_архива(архив, имя)
    размер = os.path.getsize(архив)

    print("")
    print("набор     · %s" % имя)
    print("файл      · %s (%d Б)" % (архив, размер))
    print("редакция  · %s" % отпечаток)
    if объявлять:
        было = объявить(имя, отпечаток)
        if было is not None:
            print("объявлено · ожидаемая редакция %s → %s"
                  % (было or "не объявлена", отпечаток))
    else:
        print("объявлено · нет, по ключу --без-объявления")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
