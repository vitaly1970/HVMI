#!/usr/bin/env bash
# run-credit.sh — прогон выпуска «Кредитный цикл» одной командой.
#
#   bash run-credit.sh <дата выпуска ГГГГ-ММ-ДД> [spot.json]
#
# Делает всю цепочку без остановок: расчёт → графики → сборка → номера страниц
# вторым проходом → проверка вёрстки и замок прозы → гейт прогона → пара файлов
# в каталоге выдачи. Печатает всё, что нужно для отчёта о расхождениях.
#
# Зачем скрипт: прежде цепочка шла девятью отдельными командами, а правка
# номеров страниц требовала ещё трёх проходов. Число обращений к инструментам,
# а не счёт, и было главной статьёй расхода прогона.
#
# Что скрипт НЕ делает: не ищет точечные значения Фазы 1 и не пишет состояние.
# Первое — работа исполнителя (список даёт `--что-искать`), второе идёт ПОСЛЕ
# выдачи отдельной командой, как требует правило серии.
set -euo pipefail

CUT="${1:?нужна дата выпуска ГГГГ-ММ-ДД}"
SPOT="${2:-}"
SKILLS="${SKILLS_DIR:-/mnt/skills/user}"
WORK="$(pwd)"
OUTDIR="${OUTDIR:-/mnt/user-data/outputs}"
SLUG="credit-${CUT}"

echo "── подготовка ──────────────────────────────────────────────"
cp -rn "$SKILLS/amin-data/assets/." "$WORK/" 2>/dev/null || true
mkdir -p "$WORK/assets"
cp -rn "$SKILLS/report-format/assets/." "$WORK/assets/" 2>/dev/null || true
cp -n "$SKILLS/report-format/assets/templates/weekly-credit-monitor.js" "$WORK/" 2>/dev/null || true
cp -n "$SKILLS/report-format/assets/templates/weekly-credit-monitor.charts.py" "$WORK/" 2>/dev/null || true
[ -d node_modules/docx ] || npm install --silent jszip docx >/dev/null 2>&1

echo "── расчёт ──────────────────────────────────────────────────"
if [ -n "$SPOT" ]; then
  python3 credit_calc.py --cutoff "$CUT" --data data --out out --spot "$SPOT"
else
  python3 credit_calc.py --cutoff "$CUT" --data data --out out
fi

python3 - "$CUT" <<'PY'
import json, os, sys
sys.path.insert(0, ".")
import amin_run
cut = sys.argv[1]
c = amin_run.cover("credit", cut)
json.dump({"title": c["title"], "subtitle": c["subtitle"], "date": c["date"],
           "author": c["author"], "slug": amin_run.slug("credit", cut)},
          open("out/meta.json", "w"), ensure_ascii=False)
PY

echo "── графики ─────────────────────────────────────────────────"
python3 weekly-credit-monitor.charts.py >/dev/null
echo "  PNG: $(ls png | wc -l)"

echo "── сборка, первый проход ───────────────────────────────────"
OUTDIR="$OUTDIR" node weekly-credit-monitor.js

echo "── номера страниц содержания ───────────────────────────────"
soffice --headless --convert-to pdf --outdir "$OUTDIR" "$OUTDIR/$SLUG.docx" >/dev/null 2>&1
python3 - "$OUTDIR/$SLUG.pdf" <<'PY'
import re, subprocess, sys
pdf = sys.argv[1]
txt = subprocess.run(["pdftotext", "-layout", pdf, "-"], capture_output=True).stdout.decode()
pages = txt.split("\f")
src = open("weekly-credit-monitor.js", encoding="utf-8").read()
titles = re.findall(r'\{ t: "([^"]+)", page: \d+ \}', src)
правок = 0
for t in titles:
    нашлось = None
    for i, p in enumerate(pages, 1):
        if i <= 2:
            continue
        if any(re.match(r"●\s+" + re.escape(t) + r"(\s{2,}\S|\s*$)", l.strip())
               for l in p.split("\n")):
            нашлось = i
            break
    if нашлось:
        новое = '{ t: "%s", page: %d }' % (t, нашлось)
        старое = re.search(r'\{ t: "%s", page: \d+ \}' % re.escape(t), src)
        if старое and старое.group(0) != новое:
            src = src[:старое.start()] + новое + src[старое.end():]
            правок += 1
open("weekly-credit-monitor.js", "w", encoding="utf-8").write(src)
print("  выставлено номеров: %d" % правок)
PY
OUTDIR="$OUTDIR" node weekly-credit-monitor.js

echo "── проверка вёрстки, замок прозы, полнота ──────────────────"
set +e
bash assets/qa.sh "$OUTDIR/$SLUG.docx"
QA=$?
set -e

echo "── каталог выдачи: ровно два файла ─────────────────────────"
rm -f "$OUTDIR"/*.png "$OUTDIR"/*.qa.txt "$OUTDIR/$SLUG.docx"
ls -la "$OUTDIR"

echo "── гейт прогона ────────────────────────────────────────────"
set +e
python3 amin_run.py --code credit --title "Кредитный цикл" --cutoff "$CUT" \
        --out out --calc out/calc.json
GATE=$?
set -e

echo "════════════════════════════════════════════════════════════"
[ "$QA" -eq 0 ]   && echo "проверка вёрстки: чисто" || echo "проверка вёрстки: ДЕФЕКТЫ, файлы не отдавать"
[ "$GATE" -eq 0 ] && echo "гейт прогона: чисто"     || echo "гейт прогона: ДЕФЕКТЫ, файлы не отдавать"
echo "Состояние пишется ПОСЛЕ выдачи:"
echo "  python3 amin_run.py --code credit --state-put out/state.json --issued $CUT"
exit $(( QA + GATE ))
