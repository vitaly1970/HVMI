#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""wsm_calc.py — расчёт продукта «Настроения рынка» (wsm), промпт v4.0.

Собран 18.08.2026 по расчётным разделам промпта: реестр рядов Р.1, конструкция
инсайдерского ряда Р.1б, нормализация Р.2, термометр Р.8, мера расхождения Р.11,
исходы Р.12.

Термометр считается только по делам участников. Ядро, база 11:
инсайдеры 3 · волатильность с формой кривой 2 · цена защиты 2 ·
кредитный аппетит 2 · участие 2. У показателей страха шкала инвертируется.

Запуск:
    python3 wsm_calc.py --cutoff 2026-08-17 --data data --out out
    python3 wsm_calc.py --cutoff 2026-08-17 --data data --out out --skip-fetch

Повторный запуск берёт кэш из --data и в сеть не ходит.
"""

import argparse, csv, gzip, io, json, os, re, sys, threading, time, zipfile
import datetime as dt
import urllib.request, urllib.error, urllib.parse
from concurrent.futures import ThreadPoolExecutor

SEC_UA = "American Investor research vitaly@americaninvestor.capital"
BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/126 Safari/537.36")
CBOE = "https://cdn.cboe.com/api/global/us_indices/daily_prices/%s_History.csv"
YAHOO = "https://query1.finance.yahoo.com/v8/finance/chart/%s?range=%s&interval=1d"
SEC_SETS = "https://www.sec.gov/data-research/sec-markets-data/insider-transactions-data-sets"
LOCK = threading.Lock()

# веса ядра (Р.8), суммарная база 11
WEIGHTS = {"инсайдеры": 3, "волатильность": 2, "цена_защиты": 2,
           "кредитный_аппетит": 2, "участие": 2}
# показатели страха: шкала инвертируется
INVERT = {"волатильность", "цена_защиты"}
ZONES = [(0, 20, "паника"), (20, 35, "страх"), (35, 55, "нейтрально"),
         (55, 80, "оптимизм"), (80, 100, "эйфория")]
WINDOW_DAYS = 3652          # десятилетнее окно перцентиля (Р.2)
PRICE_MIN, PRICE_MAX = 0.01, 10000.0   # Р.1б
TRADE_CAP = 1e9                         # Р.1б


# ------------------------------------------------------------------ сеть

# Журнал значений: число без строки в журнале дальше не передаётся.
# Класс берётся из набора amin-data, если он рядом; иначе — своя запись того же вида.
try:
    from amin_run import Log
except Exception:
    class Log(object):
        def __init__(self, out="out", code=None, cutoff=None):
            self.path = os.path.join(out, "channels.jsonl")
            self.code, self.cutoff = code, str(cutoff)[:10] if cutoff else None
            os.makedirs(out, exist_ok=True); open(self.path, "a").close()
        def _w(self, rec):
            rec["ts"] = dt.datetime.now().isoformat(timespec="seconds")
            if self.code: rec["продукт"] = self.code
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            return rec
        def get(self, channel, url="", ok=True, note=""):
            return self._w({"вид": "обращение", "канал": channel, "адрес": url,
                            "успех": bool(ok), "пометка": note})
        def series(self, key, channel, last_date="", points=0, note="", layer="быстрый"):
            return self._w({"вид": "ряд", "показатель": key, "канал": channel,
                            "последняя_дата": str(last_date)[:10], "слой": layer,
                            "точек": int(points), "пометка": note})
        def value(self, key, value, source, date, unit="", note=""):
            return self._w({"вид": "значение", "показатель": key, "значение": value,
                            "источник": source, "дата": str(date)[:10],
                            "единица": unit, "пометка": note})
        def gap(self, key, channels=(), reason=""):
            return self._w({"вид": "пробел", "показатель": key,
                            "опрошено": list(channels), "причина": reason})
        def note(self, text):
            return self._w({"вид": "пометка", "текст": text})


def http(url, ua=BROWSER_UA, tries=5, binary=False, timeout=60):
    delay = 1.0
    for _ in range(tries):
        req = urllib.request.Request(url, headers={"User-Agent": ua,
                                                   "Accept-Encoding": "gzip"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                raw = r.read()
                if r.headers.get("Content-Encoding") == "gzip":
                    raw = gzip.decompress(raw)
            return raw if binary else raw.decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            if e.code in (429, 403, 503):
                time.sleep(delay); delay = min(delay * 2, 20); continue
            if e.code == 404:
                return None
            return None
        except Exception:
            time.sleep(delay); delay = min(delay * 2, 20)
    return None


def cached(path, fn, binary=False):
    if os.path.exists(path):
        return open(path, "rb").read() if binary else open(path, encoding="utf-8").read()
    data = fn()
    if data is None:
        return None
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb" if binary else "w", encoding=None if binary else "utf-8") as f:
        f.write(data)
    return data


# ------------------------------------------------------------------ ряды

def cboe_series(name, data_dir, col=-1):
    """Дневной ряд биржи опционов: дата в формате ММ/ДД/ГГГГ."""
    txt = cached(os.path.join(data_dir, "cboe_%s.csv" % name),
                 lambda: http(CBOE % name))
    out = {}
    for r in csv.reader(io.StringIO(txt or "")):
        try:
            d = dt.datetime.strptime(r[0], "%m/%d/%Y").date()
            out[d] = float(r[col])
        except Exception:
            continue
    return out


def yahoo_series(ticker, data_dir, rng="15y"):
    """Дневные закрытия. Хвост длинного запроса обрывается — склейка с range."""
    safe = ticker.replace("^", "_")
    txt = cached(os.path.join(data_dir, "y_%s.json" % safe),
                 lambda: http(YAHOO % (urllib.parse.quote(ticker), rng)))
    if not txt:
        return {}
    try:
        res = json.loads(txt)["chart"]["result"][0]
    except Exception:
        return {}
    ts = res.get("timestamp") or []
    cl = res["indicators"]["quote"][0].get("close") or []
    out = {}
    for t, c in zip(ts, cl):
        if c is None:
            continue
        out[dt.datetime.utcfromtimestamp(t).date()] = float(c)
    return out


def sp500_tickers(data_dir):
    """Состав индекса из открытого справочника: первая колонка таблицы."""
    txt = cached(os.path.join(data_dir, "sp500.html"),
                 lambda: http("https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"))
    if not txt:
        return []
    i = txt.find('id="constituents"')
    body = txt[i:txt.find("</table>", i)] if i > 0 else txt
    tk = re.findall(r"<td[^>]*>\s*(?:<a[^>]*>)?([A-Z]{1,5}(?:\.[A-Z])?)(?:</a>)?\s*</td>", body)
    tk = [t for t in tk if len(t) <= 6]
    return sorted(set(t.replace(".", "-") for t in tk))


# --------------------------------------------------- инсайдеры (Р.1б)

def sec_zip_links(data_dir):
    txt = cached(os.path.join(data_dir, "sec_sets.html"),
                 lambda: http(SEC_SETS, ua=SEC_UA))
    out = {}
    for m in re.finditer(r'href="([^"]*?(\d{4}q\d)_form345\.zip)"', txt or ""):
        out[m.group(2)] = "https://www.sec.gov" + m.group(1)
    return out


def quarter_weeks(qtr, url, data_dir):
    """Недельный ряд по ДАТЕ ПОДАЧИ: суммы продаж и покупок должностных лиц."""
    cache = os.path.join(data_dir, "ins_%s.json" % qtr)
    if os.path.exists(cache):
        return json.load(open(cache, encoding="utf-8"))
    zpath = os.path.join(data_dir, "%s.zip" % qtr)
    if not os.path.exists(zpath):
        blob = http(url, ua=SEC_UA, binary=True, timeout=180)
        if blob is None:
            return {}
        open(zpath, "wb").write(blob)
    z = zipfile.ZipFile(zpath)
    names = {n.upper(): n for n in z.namelist()}

    def rows(fname):
        n = names.get(fname)
        if not n:
            return []
        with z.open(n) as f:
            return list(csv.DictReader(io.TextIOWrapper(f, "utf-8", "replace"),
                                       delimiter="\t"))

    filed, insider = {}, set()
    for r in rows("SUBMISSION.TSV"):
        if (r.get("DOCUMENT_TYPE") or "").strip() != "4":
            continue
        filed[r["ACCESSION_NUMBER"]] = _date_any(r.get("FILING_DATE"))
    for r in rows("REPORTINGOWNER.TSV"):
        off = (r.get("RPTOWNER_RELATIONSHIP") or "").upper()
        if (r.get("RPTOWNER_OFFICER") or "").strip() in ("1", "Y", "true") or \
           (r.get("RPTOWNER_DIRECTOR") or "").strip() in ("1", "Y", "true") or \
           "OFFICER" in off or "DIRECTOR" in off:
            insider.add(r["ACCESSION_NUMBER"])
    agg = {}
    for r in rows("NONDERIV_TRANS.TSV"):
        acc = r.get("ACCESSION_NUMBER")
        if acc not in filed or acc not in insider:
            continue
        code = (r.get("TRANS_CODE") or "").strip()
        if code not in ("P", "S"):
            continue
        try:
            sh = float(r.get("TRANS_SHARES") or 0)
            pr = float(r.get("TRANS_PRICEPERSHARE") or 0)
        except ValueError:
            continue
        if not (PRICE_MIN <= pr <= PRICE_MAX):
            continue
        v = sh * pr
        if v <= 0 or v > TRADE_CAP:
            continue
        d = filed[acc]
        if not d:
            continue
        wk = _week_end(d).isoformat()
        a = agg.setdefault(wk, {"продажи": 0.0, "покупки": 0.0})
        if code == "S":
            a["продажи"] += v
        else:
            a["покупки"] += v
    json.dump(agg, open(cache, "w", encoding="utf-8"), ensure_ascii=False)
    return agg


def _date_any(s):
    s = (s or "").strip()
    for f in ("%d-%b-%Y", "%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y"):
        try:
            return dt.datetime.strptime(s.split(" ")[0], f).date()
        except Exception:
            continue
    return None


def _week_end(d):
    return d + dt.timedelta(days=(4 - d.weekday()) % 7)


def insider_series(cutoff, data_dir, log=None):
    """Ряд натурального логарифма отношения продаж к покупкам, 2006 — срез."""
    links = sec_zip_links(data_dir)
    weeks = {}
    for qtr in sorted(links):
        y = int(qtr[:4])
        if y < 2006 or y > cutoff.year:
            continue
        for wk, a in quarter_weeks(qtr, links[qtr], data_dir).items():
            t = weeks.setdefault(wk, {"продажи": 0.0, "покупки": 0.0})
            t["продажи"] += a["продажи"]
            t["покупки"] += a["покупки"]
    import math
    ser = {}
    for wk, a in weeks.items():
        if a["покупки"] <= 0 or a["продажи"] <= 0:
            continue
        d = dt.date.fromisoformat(wk)
        if d <= cutoff:
            ser[d] = math.log(a["продажи"] / a["покупки"])
    return ser, weeks


# ------------------------------------------------------ нормализация Р.2

def percentile(series, value, cutoff, window=WINDOW_DAYS):
    """Каузальное место значения в собственной истории за окно, шкала 0–100."""
    lo = cutoff - dt.timedelta(days=window)
    xs = [v for d, v in series.items() if lo <= d <= cutoff]
    if len(xs) < 20:
        return None, len(xs)
    return 100.0 * sum(1 for x in xs if x < value) / len(xs), len(xs)


def last_on_or_before(series, d):
    ds = [x for x in series if x <= d]
    return max(ds) if ds else None


def zone(v):
    for lo, hi, name in ZONES:
        if lo <= v < hi:
            return name
    return ZONES[-1][2]


# ------------------------------------------------------------ термометр Р.8

def thermometer(parts):
    """Средневзвешенное частных оценок с нормировкой на фактическое покрытие."""
    num = den = 0.0
    for k, w in WEIGHTS.items():
        v = parts.get(k)
        if v is None:
            continue
        num += v * w
        den += w
    if den == 0:
        return None, 0.0
    return round(num / den, 1), round(100.0 * den / sum(WEIGHTS.values()), 1)


# ---------------------------------------------------------------- Р.12

def outcomes(therm_series, spx, cutoff, current=None, horizon_days=(21, 63)):
    """Что было после таких же настроений: та же зона и та же сторона 200-дневной."""
    dates = sorted(therm_series)
    if not dates:
        return {}
    cur = current if current is not None else therm_series[dates[-1]]
    cur_zone = zone(cur)
    sp = sorted(spx)
    def ma200(d):
        xs = [spx[x] for x in sp if x <= d][-200:]
        return sum(xs) / len(xs) if len(xs) == 200 else None
    cur_above = None
    d0 = last_on_or_before(spx, cutoff)
    if d0:
        m = ma200(d0)
        cur_above = spx[d0] > m if m else None
    picked, last = [], None
    for d in dates:
        if zone(therm_series[d]) != cur_zone or d >= cutoff:
            continue
        dd = last_on_or_before(spx, d)
        if not dd:
            continue
        m = ma200(dd)
        if m is None or (spx[dd] > m) != cur_above:
            continue
        if last and (d - last).days < 30:      # разнос эпизодов, 21 торговый день
            continue
        picked.append(dd)
        last = d
    res = {"зона": cur_zone, "случаев": len(picked), "горизонты": {}}
    for h in horizon_days:
        moves = []
        for d in picked:
            fut = [x for x in sp if x > d]
            if len(fut) <= h:
                continue
            moves.append(100.0 * (spx[fut[h - 1]] / spx[d] - 1))
        if len(moves) >= 5:
            moves.sort()
            res["горизонты"]["%dд" % h] = {
                "n": len(moves), "медиана": round(moves[len(moves) // 2], 2),
                "доля_роста": round(100.0 * sum(1 for m in moves if m > 0) / len(moves)),
                "худший": round(moves[0], 2)}
        else:
            res["горизонты"]["%dд" % h] = {"n": len(moves), "эпизоды":
                                           [d.isoformat() for d in picked]}
    # длительность серии в текущей зоне
    run = 0
    for d in reversed(dates):
        if zone(therm_series[d]) == cur_zone:
            run += 1
        else:
            break
    res["серия_недель"] = run
    return res


# ---------------------------------------------------------------- Р.11

def divergence(words_series, deeds_series, w_val, d_val, cutoff):
    """Расстояние между местами слов и дел в собственной истории за десять лет."""
    pw, _ = percentile(words_series, w_val, cutoff)
    pd_, _ = percentile(deeds_series, d_val, cutoff)
    if pw is None or pd_ is None:
        return None, None
    dist = abs(pw - pd_)
    word = "резко" if dist > 60 else ("заметно" if dist >= 30 else "нет")
    return round(dist, 1), word


# ---------------------------------------------------------------- прогон

def run(cutoff, data_dir, out_dir, skip_fetch=False):
    os.makedirs(out_dir, exist_ok=True)
    log = Log(out_dir, code="wsm", cutoff=cutoff)
    res = {"срез": cutoff.isoformat(), "компоненты": {}, "ряды": {}}
    gaps = []

    vix = cboe_series("VIX", data_dir)
    v3 = cboe_series("VIX3M", data_dir)
    v9 = cboe_series("VIX9D", data_dir)
    skew = cboe_series("SKEW", data_dir, col=1)
    spx = yahoo_series("^GSPC", data_dir)
    hyg = yahoo_series("HYG", data_dir)
    lqd = yahoo_series("LQD", data_dir)

    # 1. волатильность с формой кривой: уровень, приведённый к наклону кривой
    common = [d for d in vix if d in v3 and d in v9]
    volser = {d: vix[d] / (v3[d] / v9[d]) for d in common}
    d = last_on_or_before(volser, cutoff)
    p, n = percentile(volser, volser[d], cutoff)
    res["компоненты"]["волатильность"] = {"значение": round(volser[d], 2), "место": p,
                                          "оценка": round(100 - p, 1), "точек": n,
                                          "дата": d.isoformat(),
                                          "vix": vix[d], "кривая": round(v3[d] / v9[d], 3)}
    log.series("волатильность с формой кривой", "CBOE:VIX,VIX3M,VIX9D", d, len(volser))
    log.value("волатильность", round(volser[d], 2), "CBOE индексы волатильности", d,
              unit="пункт")

    # 2. цена защиты от резкого падения
    d = last_on_or_before(skew, cutoff)
    p, n = percentile(skew, skew[d], cutoff)
    res["компоненты"]["цена_защиты"] = {"значение": skew[d], "место": p,
                                        "оценка": round(100 - p, 1), "точек": n,
                                        "дата": d.isoformat()}
    log.series("цена защиты от резкого падения", "CBOE:SKEW", d, len(skew))
    log.value("цена_защиты", skew[d], "CBOE индекс перекоса", d, unit="пункт")

    # 3. кредитный аппетит: отношение цен фондов высокодоходных и надёжных бумаг
    ratio = {d0: hyg[d0] / lqd[d0] for d0 in hyg if d0 in lqd}
    d = last_on_or_before(ratio, cutoff)
    p, n = percentile(ratio, ratio[d], cutoff)
    res["компоненты"]["кредитный_аппетит"] = {"значение": round(ratio[d], 4), "место": p,
                                              "оценка": round(p, 1), "точек": n,
                                              "дата": d.isoformat()}
    log.series("кредитный аппетит", "Yahoo:HYG,LQD", d, len(ratio))
    log.value("кредитный_аппетит", round(ratio[d], 4), "Yahoo отношение цен фондов", d,
              unit="отношение")

    # 4. участие: доля бумаг индекса выше своей 200-дневной средней
    part = participation(cutoff, data_dir, skip_fetch)
    if part:
        d = last_on_or_before(part, cutoff)
        p, n = percentile(part, part[d], cutoff)
        res["компоненты"]["участие"] = {"значение": round(part[d], 1), "место": p,
                                        "оценка": round(p, 1), "точек": n,
                                        "дата": d.isoformat()}
        log.series("участие бумаг выше 200-дневной", "Yahoo:бумаги индекса", d, len(part))
        log.value("участие", round(part[d], 1), "расчёт по ценам бумаг индекса", d, unit="%")
    else:
        gaps.append("участие")
        log.gap("участие", ["Yahoo:бумаги индекса"], "панель цен бумаг индекса не собрана")

    # 5. инсайдеры: логарифм отношения продаж к покупкам по подавшим неделям
    ins, weeks = insider_series(cutoff, data_dir)
    if ins:
        d = max(ins)
        p, n = percentile(ins, ins[d], cutoff)
        import math
        res["компоненты"]["инсайдеры"] = {"значение": round(math.exp(ins[d]), 2),
                                          "логарифм": round(ins[d], 3), "место": p,
                                          "оценка": round(p, 1), "точек": n,
                                          "дата": d.isoformat()}
        # Квартальные наборы регулятора отстают примерно на полтора месяца,
        # поэтому ряд идёт медленным слоем; свежую неделю добирает wsm_insiders.
        log.series("сделки инсайдеров", "SEC:квартальные наборы", d, len(ins),
                   layer="медленный", note="лаг публикации около шести недель")
        log.value("инсайдеры", round(math.exp(ins[d]), 2), "SEC формы 4", d,
                  unit="отношение продаж к покупкам")
    else:
        gaps.append("сделки инсайдеров")
        log.gap("инсайдеры", ["SEC:квартальные наборы"], "ряд не собран")

    # история термометра: пересчитывается назад каждым прогоном (Р.8, с 2006)
    parts = {k: v.get("оценка") for k, v in res["компоненты"].items()}
    therm, cover = thermometer(parts)
    hist = history(volser, skew, ratio, part, ins, cutoff)
    res["история"] = {d.isoformat(): v for d, v in hist.items()}
    if hist:
        res["исходы"] = outcomes(hist, spx, cutoff, current=therm)
    res["термометр"] = therm
    res["покрытие"] = cover
    res["зона"] = zone(therm) if therm is not None else None

    res["чувствительность"] = {}
    for k in list(parts):
        sub = dict(parts); sub.pop(k)
        res["чувствительность"][k] = thermometer(sub)[0]

    log.value("термометр", therm, "расчёт по пяти компонентам", cutoff, unit="0–100",
              note="покрытие %.1f %%" % cover if cover is not None else "")
    # Известные пробелы промпта: платные опросы каждым прогоном не опрашиваются.
    for key, chans, why in (
            ("опрос частных инвесторов", ["AAII"], "выгрузка платная, ряд не берётся"),
            ("наблюдение активных менеджеров", ["NAAIM"], "доступ платный с августа 2026")):
        gaps.append(key)
        log.gap(key, chans, why)
    res["пробелы"] = gaps

    json.dump(res, open(os.path.join(out_dir, "calc.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    return res


def history(volser, skew, ratio, part, ins, cutoff, start=dt.date(2006, 1, 6)):
    """Недельный ряд термометра назад до 2006 года, все места считаются каузально."""
    out = {}
    weeks = sorted(d for d in ins if d >= start)
    for wk in weeks:
        parts = {}
        for key, ser, inv in (("волатильность", volser, True), ("цена_защиты", skew, True),
                              ("кредитный_аппетит", ratio, False), ("участие", part, False)):
            d = last_on_or_before(ser, wk)
            if not d:
                continue
            p, n = percentile(ser, ser[d], wk)
            if p is None:
                continue
            parts[key] = 100 - p if inv else p
        p, n = percentile(ins, ins[wk], wk)
        if p is not None:
            parts["инсайдеры"] = p
        v, cover = thermometer(parts)
        if v is not None and cover >= 70:
            out[wk] = v
    return out


def participation(cutoff, data_dir, skip_fetch=False):
    """Доля бумаг индекса выше своей 200-дневной средней, дневной ряд."""
    cache = os.path.join(data_dir, "participation.json")
    if os.path.exists(cache):
        return {dt.date.fromisoformat(k): v
                for k, v in json.load(open(cache, encoding="utf-8")).items()}
    if skip_fetch:
        return {}
    tick = sp500_tickers(data_dir)
    if not tick:
        return {}
    series = {}

    def one(t):
        s = yahoo_series(t, os.path.join(data_dir, "px"), rng="15y")
        if s:
            with LOCK:
                series[t] = s

    with ThreadPoolExecutor(max_workers=8) as ex:
        list(ex.map(one, tick))
    above, total = {}, {}
    for t, s in series.items():
        ds = sorted(s)
        vals = [s[d] for d in ds]
        run = 0.0
        for i, d in enumerate(ds):
            if i < 200:
                continue
            run = sum(vals[i - 200:i]) / 200.0
            total[d] = total.get(d, 0) + 1
            if vals[i] > run:
                above[d] = above.get(d, 0) + 1
    out = {d: 100.0 * above.get(d, 0) / total[d] for d in total if total[d] >= 400}
    json.dump({d.isoformat(): v for d, v in out.items()},
              open(cache, "w", encoding="utf-8"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutoff", required=True)
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="out")
    ap.add_argument("--skip-fetch", action="store_true")
    a = ap.parse_args()
    cut = dt.datetime.strptime(a.cutoff, "%Y-%m-%d").date()
    r = run(cut, a.data, a.out, a.skip_fetch)
    for k, v in r["компоненты"].items():
        print("%-18s значение %-10s место %-6s оценка %s" %
              (k, v.get("значение"), v.get("место") and round(v["место"], 1), v.get("оценка")))
    print("термометр %s, зона %s, покрытие %s %%" % (r["термометр"], r["зона"], r["покрытие"]))


if __name__ == "__main__":
    main()
