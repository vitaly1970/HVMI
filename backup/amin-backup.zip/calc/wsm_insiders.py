#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
wsm_insiders — недельный добор сделок инсайдеров с сайта регулятора (формы 4)
и сверка результата с квартальным набором раскрытий.

Зачем: квартальный набор отстаёт на семь недель, а компонент «инсайдеры» весит
3 из 11 в термометре настроений. Модуль считает ту же величину по свежим подачам.

Команды:
  --fetch  --from ГГГГ-ММ-ДД --to ГГГГ-ММ-ДД   разбор дневных указателей и форм
  --quarter 2026q2                              загрузка квартального набора
  --weekly --to ГГГГ-ММ-ДД --weeks N            недельные значения из подач
  --compare ГГГГ-ММ-ДД                          сверка недели обоими способами

Кэш дневного разбора лежит в --data/tx/ГГГГММДД.csv, повторный запуск сеть не
трогает.
"""
import argparse, csv, io, json, os, re, sys, threading, time, zipfile
import urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta

UA = "American Investor research vitaly@americaninvestor.capital"
BASE = "https://www.sec.gov"
LOCK = threading.Lock()
STAT = {"get": 0, "429": 0, "err": 0}


def http(url, tries=6, binary=False):
    """Запрос к регулятору со своим заголовком и повтором при 429."""
    delay = 1.0
    for n in range(tries):
        req = urllib.request.Request(url, headers={
            "User-Agent": UA, "Accept-Encoding": "gzip, deflate",
            "Host": url.split("/")[2]})
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                raw = r.read()
                if r.headers.get("Content-Encoding") == "gzip":
                    import gzip
                    raw = gzip.decompress(raw)
            with LOCK:
                STAT["get"] += 1
            return raw if binary else raw.decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            if e.code in (429, 403, 503):
                with LOCK:
                    STAT["429"] += 1
                time.sleep(delay)
                delay = min(delay * 2, 20)
                continue
            if e.code == 404:
                return None
            with LOCK:
                STAT["err"] += 1
            return None
        except Exception:
            time.sleep(delay)
            delay = min(delay * 2, 20)
    with LOCK:
        STAT["err"] += 1
    return None


# ---------------------------------------------------------------- разбор формы

def tag_value(block, tag):
    m = re.search(r"<%s>(.*?)</%s>" % (tag, tag), block, re.S)
    if not m:
        return None
    inner = m.group(1)
    v = re.search(r"<value>(.*?)</value>", inner, re.S)
    s = (v.group(1) if v else inner).strip()
    return s or None


TX_RE = re.compile(r"<nonDerivativeTransaction>(.*?)</nonDerivativeTransaction>", re.S)


def parse_form4(text):
    """Строки открытого рынка: покупка P и продажа S по недеривативной таблице."""
    sym = tag_value(text, "issuerTradingSymbol") or ""
    out = []
    for m in TX_RE.finditer(text):
        b = m.group(1)
        code = tag_value(b, "transactionCode")
        if code not in ("P", "S"):
            continue
        d = tag_value(b, "transactionDate")
        sh = tag_value(b, "transactionShares")
        pr = tag_value(b, "transactionPricePerShare")
        ad = tag_value(b, "transactionAcquiredDisposedCode")
        try:
            sh = float(sh)
        except (TypeError, ValueError):
            sh = 0.0
        try:
            pr = float(pr)
        except (TypeError, ValueError):
            pr = 0.0
        if not d:
            continue
        out.append((sym.upper(), d[:10], code, ad or "", sh, pr))
    return out


# ------------------------------------------------------------- дневной указатель

def day_index(d):
    """Пути форм 4, поданных в этот день."""
    q = (d.month - 1) // 3 + 1
    url = "%s/Archives/edgar/daily-index/%d/QTR%d/form.%s.idx" % (
        BASE, d.year, q, d.strftime("%Y%m%d"))
    txt = http(url)
    if txt is None:
        return None
    paths = []
    for line in txt.splitlines():
        if not line.startswith("4 "):
            continue
        parts = line.split()
        if parts[0] != "4":
            continue
        p = parts[-1]
        if p.startswith("edgar/data/"):
            paths.append(p)
    # одна подача идёт в указателе строкой на каждого подписанта — берём по разу
    seen, uniq = set(), []
    for p in paths:
        acc = p.rsplit("/", 1)[-1]
        if acc in seen:
            continue
        seen.add(acc)
        uniq.append(p)
    return uniq


def fetch_day(d, data_dir, workers):
    """Разбирает все формы 4 одного дня подачи; результат — CSV в кэше."""
    out = os.path.join(data_dir, "tx", d.strftime("%Y%m%d") + ".csv")
    if os.path.exists(out):
        return "кэш"
    paths = day_index(d)
    if paths is None:
        return "нет указателя"
    rows, miss = [], []

    def one(p):
        t = http(BASE + "/Archives/" + p)
        if not t:
            with LOCK:
                miss.append(p)
            return
        acc = p.rsplit("/", 1)[-1].replace(".txt", "")
        for r in parse_form4(t):
            with LOCK:
                rows.append((acc,) + r)

    with ThreadPoolExecutor(max_workers=workers) as ex:
        list(ex.map(one, paths))
    for _ in range(3):
        if not miss:
            break
        again, miss = list(miss), []
        time.sleep(5)
        with ThreadPoolExecutor(max_workers=4) as ex:
            list(ex.map(one, again))
    if miss:
        return "НЕПОЛНЫЙ ДЕНЬ: не взято %d подач из %d" % (len(miss), len(paths))
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out + ".part", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["accession", "symbol", "trans_date", "code", "ad", "shares", "price"])
        w.writerows(rows)
    os.replace(out + ".part", out)
    return "%d подач, %d строк" % (len(paths), len(rows))


def business_days(a, b):
    d, out = a, []
    while d <= b:
        if d.weekday() < 5:
            out.append(d)
        d += timedelta(days=1)
    return out


# ------------------------------------------------------------------ агрегация

def load_cached(data_dir, lo=None, hi=None):
    """Все разобранные строки из кэша, при желании с отбором по дате сделки."""
    rows = []
    tx = os.path.join(data_dir, "tx")
    if not os.path.isdir(tx):
        return rows
    for name in sorted(os.listdir(tx)):
        if not name.endswith(".csv"):
            continue
        with open(os.path.join(tx, name)) as f:
            for r in csv.DictReader(f):
                d = r["trans_date"]
                if lo and d < lo:
                    continue
                if hi and d > hi:
                    continue
                rows.append(r)
    return rows


MAX_TX = 2e9  # сделка дороже двух миллиардов — ошибка подавшего, а не сделка


def aggregate(rows):
    """Стоимость покупок и продаж открытого рынка плюс отношение.

    Регулятор не правит опечатки подающих: встречаются цены вроде 40 млн $ за
    пай. Строка дороже порога MAX_TX выбрасывается и считается отдельно."""
    buy = sell = 0.0
    nb = ns = drop = 0
    for r in rows:
        try:
            sh, pr = float(r["shares"]), float(r["price"])
        except (TypeError, ValueError):
            continue
        v = sh * pr
        if pr <= 0 or v > MAX_TX:
            drop += 1
            continue
        if r["code"] == "P" and r["ad"] == "A":
            buy += v
            nb += 1
        elif r["code"] == "S" and r["ad"] == "D":
            sell += v
            ns += 1
    return {"покупки_млн": round(buy / 1e6, 1), "продажи_млн": round(sell / 1e6, 1),
            "отношение": round(sell / buy, 2) if buy else None,
            "сделок_покупки": nb, "сделок_продажи": ns, "выброшено_строк": drop}


def week_bounds(friday):
    f = datetime.strptime(friday, "%Y-%m-%d").date()
    f = f - timedelta(days=(f.weekday() - 4) % 7) if f.weekday() != 4 else f
    return (f - timedelta(days=4)).isoformat(), f.isoformat()


# ----------------------------------------------------------- квартальный набор

def quarter_rows(qtr, data_dir):
    """Строки квартального набора раскрытий: только форма 4, коды P и S."""
    cache = os.path.join(data_dir, "%s_rows.csv" % qtr)
    if os.path.exists(cache):
        with open(cache) as f:
            return list(csv.DictReader(f))
    page = http(BASE + "/data-research/sec-markets-data/insider-transactions-data-sets")
    href = None
    for m in re.finditer(r'href="([^"]*%s_form345\.zip)"' % qtr, page or ""):
        href = m.group(1)
    if not href:
        raise SystemExit("набор %s не найден на странице раздела" % qtr)
    zpath = os.path.join(data_dir, "%s.zip" % qtr)
    if not os.path.exists(zpath):
        blob = http(BASE + href if href.startswith("/") else href, binary=True)
        open(zpath, "wb").write(blob)
    z = zipfile.ZipFile(zpath)
    subs = {}
    with z.open("SUBMISSION.tsv") as f:
        for r in csv.DictReader(io.TextIOWrapper(f, "utf-8", "replace"), delimiter="\t"):
            subs[r["ACCESSION_NUMBER"]] = r.get("DOCUMENT_TYPE", "")
    out = []
    with z.open("NONDERIV_TRANS.tsv") as f:
        for r in csv.DictReader(io.TextIOWrapper(f, "utf-8", "replace"), delimiter="\t"):
            if subs.get(r["ACCESSION_NUMBER"]) != "4":
                continue
            if r.get("TRANS_CODE") not in ("P", "S"):
                continue
            raw = (r.get("TRANS_DATE") or "").strip()
            d = ""
            for fmt in ("%d-%b-%Y", "%Y-%m-%d", "%d-%m-%Y", "%m/%d/%Y"):
                try:
                    d = datetime.strptime(raw.split(" ")[0], fmt).date().isoformat()
                    break
                except Exception:
                    continue
            if not d:
                continue
            out.append({"accession": r["ACCESSION_NUMBER"], "symbol": "",
                        "trans_date": d, "code": r["TRANS_CODE"],
                        "ad": r.get("TRANS_ACQUIRED_DISP_CD", ""),
                        "shares": r.get("TRANS_SHARES", "0"),
                        "price": r.get("TRANS_PRICEPERSHARE", "0")})
    os.makedirs(data_dir, exist_ok=True)
    with open(cache, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)
    return out


# ----------------------------------------------------------------------- CLI

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fetch", action="store_true")
    ap.add_argument("--from", dest="d_from")
    ap.add_argument("--to", dest="d_to")
    ap.add_argument("--weeks", type=int, default=8)
    ap.add_argument("--weekly", action="store_true")
    ap.add_argument("--quarter")
    ap.add_argument("--compare")
    ap.add_argument("--data", default="data")
    ap.add_argument("--out")
    ap.add_argument("--workers", type=int, default=12)
    a = ap.parse_args()
    os.makedirs(a.data, exist_ok=True)

    if a.fetch:
        lo = datetime.strptime(a.d_from, "%Y-%m-%d").date()
        hi = datetime.strptime(a.d_to, "%Y-%m-%d").date()
        for d in business_days(lo, hi):
            t0 = time.time()
            res = fetch_day(d, a.data, a.workers)
            print("%s %s %.0f c" % (d, res, time.time() - t0), flush=True)
        print("запросов %(get)d, отказов 429 %(429)d, ошибок %(err)d" % STAT)

    if a.quarter:
        rows = quarter_rows(a.quarter, a.data)
        print("%s: строк открытого рынка %d" % (a.quarter, len(rows)))

    if a.weekly:
        end = datetime.strptime(a.d_to, "%Y-%m-%d").date()
        res = []
        for i in range(a.weeks):
            fri = end - timedelta(days=7 * i)
            lo, hi = week_bounds(fri.isoformat())
            agg = aggregate(load_cached(a.data, lo, hi))
            agg.update({"неделя_с": lo, "неделя_по": hi})
            res.append(agg)
        res.reverse()
        for r in res:
            print("%s..%s  покупки %8.1f  продажи %9.1f  отношение %s" % (
                r["неделя_с"], r["неделя_по"], r["покупки_млн"], r["продажи_млн"],
                r["отношение"]), flush=True)
        if a.out:
            json.dump(res, open(a.out, "w"), ensure_ascii=False, indent=1)

    if a.compare:
        lo, hi = week_bounds(a.compare)
        q = a.quarter or "%dq%d" % (int(lo[:4]), (int(lo[5:7]) - 1) // 3 + 1)
        rows_q = [r for r in quarter_rows(q, a.data) if lo <= r["trans_date"] <= hi]
        one = aggregate(load_cached(a.data, lo, hi))
        two = aggregate(rows_q)
        print("неделя %s..%s" % (lo, hi))
        print("подачи регулятора:", json.dumps(one, ensure_ascii=False))
        print("квартальный набор:", json.dumps(two, ensure_ascii=False))
        if one["отношение"] and two["отношение"]:
            d = abs(one["отношение"] - two["отношение"]) / two["отношение"] * 100
            print("расхождение отношения %.1f %%" % d)


if __name__ == "__main__":
    main()
