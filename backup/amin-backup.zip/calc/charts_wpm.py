#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Графики выпуска «Позиционирование участников» (код wpm).

Три графика брендовой палитрой American Investor:
  1. positions.png — чистая позиция управляющих активами (S&P 500) и фондов
     с плечом (Nasdaq-100) в процентах открытого интереса, три года;
  2. trend.png     — загрузка фондов следования тренду и цена индекса, год;
  3. gamma.png     — накопленная позиция маркет-мейкеров по страйкам и точка
     смены знака, снимок дня среза.

Запуск: python3 charts_wpm.py --cutoff ГГГГ-ММ-ДД --data data --out out
"""
import argparse, datetime, json, os, math

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

import wpm_calc as W

NAVY = "#10253F"
RED = "#D90F14"
GREY = "#8A93A0"
GRID = "#DCE1E7"


def _frame(ax, title, ylab=None):
    ax.set_title(title, color=NAVY, fontsize=12, loc="left", pad=12)
    if ylab:
        ax.set_ylabel(ylab, color=NAVY, fontsize=9)
    ax.grid(True, color=GRID, linewidth=0.7)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(GRID)
    ax.tick_params(colors=NAVY, labelsize=8)


def positions(cutoff, data_dir, out_dir):
    es = W.cot_series(cutoff, data_dir, market="S&P 500 Consolidated")
    nq = W.cot_series(cutoff, data_dir, market="Nasdaq-100 Consolidated")
    start = cutoff - datetime.timedelta(days=365 * 3)
    de = [d for d in sorted(es) if d >= start]
    dn = [d for d in sorted(nq) if d >= start]
    fig, ax = plt.subplots(figsize=(9, 4.2))
    ax.plot(de, [es[d]["управляющие_нетто_доля"] for d in de], color=NAVY,
            linewidth=1.8, label="Управляющие активами, S&P 500")
    ax.plot(dn, [nq[d]["плечевые_нетто_доля"] for d in dn], color=RED,
            linewidth=1.8, label="Фонды с плечом, Nasdaq-100")
    ax.axhline(0, color=GREY, linewidth=1)
    _frame(ax, "Чистая позиция по фьючерсам, % открытого интереса")
    ax.legend(frameon=False, fontsize=8, labelcolor=NAVY)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, p: "%+d%%" % v))
    fig.tight_layout()
    p = os.path.join(out_dir, "positions.png")
    fig.savefig(p, dpi=160)
    plt.close(fig)
    return p


def trend(cutoff, data_dir, out_dir):
    px = W.yahoo("^GSPC", data_dir)
    ds = [d for d in sorted(px) if d <= cutoff][-252:]
    exp = []
    for d in ds:
        e, _ = W.trend_exposure(px, d)
        exp.append(e if e is not None else float("nan"))
    fig, ax = plt.subplots(figsize=(9, 4.2))
    ax.fill_between(ds, 0, exp, color=NAVY, alpha=0.18)
    ax.plot(ds, exp, color=NAVY, linewidth=1.8, label="Загрузка, шкала −1…+1")
    ax.axhline(0, color=GREY, linewidth=1)
    _frame(ax, "Загрузка фондов следования тренду и цена индекса")
    ax2 = ax.twinx()
    ax2.plot(ds, [px[d] for d in ds], color=RED, linewidth=1.4,
             label="S&P 500, правая шкала")
    ax2.tick_params(colors=NAVY, labelsize=8)
    for s in ("top", "left"):
        ax2.spines[s].set_visible(False)
    ax2.spines["right"].set_color(GRID)
    h1, l1 = ax.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, frameon=False, fontsize=8, labelcolor=NAVY,
              loc="upper center", bbox_to_anchor=(0.5, -0.08), ncol=2)
    fig.tight_layout()
    p = os.path.join(out_dir, "trend.png")
    fig.savefig(p, dpi=160)
    plt.close(fig)
    return p


def gamma(cutoff, data_dir, out_dir, spot):
    """Профиль по страйкам собирается по тому же правилу, что и в расчёте:
    только месячные сроки (третья пятница) в пределах 90 дней от среза."""
    txt = open(os.path.join(data_dir, "chain_SPX.json"), "rb").read()
    d = json.loads(txt)["data"]
    price = d.get("current_price") or spot
    by = {}
    for o in d["options"]:
        sym = o["option"]
        try:
            y = 2000 + int(sym[-15:-13]); m = int(sym[-13:-11]); day = int(sym[-11:-9])
            exp = datetime.date(y, m, day)
        except ValueError:
            continue
        if not W._monthly(exp) or not (0 <= (exp - cutoff).days <= 90):
            continue
        k = float(sym[-8:]) / 1000.0
        sign = 1.0 if sym[-9] == "C" else -1.0
        by[k] = by.get(k, 0.0) + sign * o.get("gamma", 0.0) * o.get("open_interest", 0) \
            * 100 * price * price * 0.01
    run, всё = 0.0, {}
    for k in sorted(by):
        run += by[k]
        всё[k] = run / 1e9
    ks = sorted(k for k in by if abs(k - price) / price < 0.12)
    cum = [всё[k] for k in ks]
    fig, ax = plt.subplots(figsize=(9, 4.2))
    ax.bar(ks, [by[k] / 1e9 for k in ks], width=8, color=GREY, alpha=0.55,
           label="Позиция на страйке, млрд $")
    ax.plot(ks, cum, color=NAVY, linewidth=2, label="Накопленная позиция, млрд $")
    ax.axhline(0, color=GREY, linewidth=1)
    ax.axvline(price, color=RED, linewidth=1.6, linestyle="--",
               label="Цена индекса %.0f" % price)
    flip = None
    for i in range(1, len(cum)):
        if (cum[i - 1] < 0 <= cum[i]) or (cum[i - 1] > 0 >= cum[i]):
            flip = ks[i]
    if flip:
        ax.axvline(flip, color=NAVY, linewidth=1.4, linestyle=":",
                   label="Смена знака %.0f" % flip)
    _frame(ax, "Позиция маркет-мейкеров по страйкам, снимок дня")
    ax.legend(frameon=False, fontsize=8, labelcolor=NAVY)
    fig.tight_layout()
    p = os.path.join(out_dir, "gamma.png")
    fig.savefig(p, dpi=160)
    plt.close(fig)
    return p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutoff", required=True)
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="out")
    a = ap.parse_args()
    cut = datetime.date.fromisoformat(a.cutoff)
    os.makedirs(a.out, exist_ok=True)
    calc = json.load(open(os.path.join(a.out, "calc.json"), encoding="utf-8"))
    spot = calc["показатели"]["гамма"]["цена"]
    for p in (positions(cut, a.data, a.out), trend(cut, a.data, a.out),
              gamma(cut, a.data, a.out, spot)):
        print("собран", p)


if __name__ == "__main__":
    main()
