#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""wsm_extra.py — то, что новая структура «Настроений рынка» требует сверх
базового расчёта: расстояние до края, последний заход в крайность с исходом,
слова против дел по доступным группам, портфель темы и условия разворота.

Запуск после wsm_calc.py:
    python3 wsm_extra.py --cutoff 2026-08-21 --data data --out out
"""
import argparse, io, json, os, sys, time, urllib.request
import datetime as dt
import numpy as np, pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import amin_run
from amin_run import Log

UA = "curl/8.5.0"
BUA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
КРАЙ_ВЕРХ, КРАЙ_НИЗ = 80.0, 20.0
L = None


def fetch(url, ua=UA, headers=None, tries=4, timeout=60):
    h = {"User-Agent": ua, "Accept": "*/*"}
    if headers:
        h.update(headers)
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=h)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:
            last = e
            time.sleep(1.2 * (i + 1))
    raise last


def yahoo(sym, data):
    os.makedirs(data, exist_ok=True)
    f = os.path.join(data, "yh_%s.csv" % sym.replace("^", "i_"))
    if os.path.exists(f):
        d = pd.read_csv(f, parse_dates=["date"])
        return d.set_index("date")["v"].dropna()
    url = ("https://query1.finance.yahoo.com/v8/finance/chart/%s"
           "?period1=1104537600&period2=%d&interval=1d" % (sym, int(time.time())))
    try:
        j = json.loads(fetch(url, ua=BUA))
        r = j["chart"]["result"][0]
        q = (r["indicators"].get("adjclose", [{}])[0].get("adjclose")
             or r["indicators"]["quote"][0]["close"])
        s = pd.Series(q, index=pd.to_datetime(r["timestamp"], unit="s").normalize()).dropna()
        s.rename_axis("date").rename("v").to_frame().to_csv(f)
        return s
    except Exception as e:
        L.get("Yahoo " + sym, url, ok=False, note=str(e)[:90])
        return None


def место(s, v, years=10):
    tail = s[s.index >= s.index.max() - pd.Timedelta(days=365 * years)]
    if len(tail) < 60:
        tail = s
    return round(float((tail < v).mean() * 100), 1)


def main():
    global L
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutoff", required=True)
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="out")
    a = ap.parse_args()
    cut = pd.Timestamp(a.cutoff)
    L = Log(a.out, code="wsm", cutoff=a.cutoff)
    C = json.load(open(os.path.join(a.out, "calc.json"), encoding="utf-8"))
    T = float(C["термометр"])
    hist = pd.Series({pd.Timestamp(k): float(v) for k, v in C["история"].items()}).sort_index()
    hist = hist[hist.index <= cut]
    E = {"срез": a.cutoff, "термометр": T, "зона": C["зона"]}

    # ── 1. расстояние до края и ближайший компонент
    вверх, вниз = round(КРАЙ_ВЕРХ - T, 1), round(T - КРАЙ_НИЗ, 1)
    E["край"] = {"до_эйфории": вверх, "до_паники": вниз,
                 "ближе": "эйфория" if вверх <= вниз else "паника"}
    comp = C["компоненты"]
    близко = sorted(((k, v["оценка"], min(100 - v["оценка"], v["оценка"] - 0))
                     for k, v in comp.items() if v.get("оценка") is not None),
                    key=lambda x: -x[1])
    E["край"]["самый_высокий_компонент"] = {"имя": близко[0][0], "оценка": близко[0][1]}
    E["край"]["самый_низкий_компонент"] = {"имя": близко[-1][0], "оценка": близко[-1][1]}
    L.value("расстояние_до_края", вверх, "расчёт wsm-extra", a.cutoff, "пунктов термометра")

    # ── 2. движение термометра
    def назад(n):
        s = hist[hist.index <= cut - pd.Timedelta(weeks=n)]
        return float(s.iloc[-1]) if len(s) else None
    E["движение"] = {"неделю_назад": назад(1), "месяц_назад": назад(4),
                     "за_неделю": None, "за_месяц": None}
    if E["движение"]["неделю_назад"] is not None:
        E["движение"]["за_неделю"] = round(T - E["движение"]["неделю_назад"], 1)
    if E["движение"]["месяц_назад"] is not None:
        E["движение"]["за_месяц"] = round(T - E["движение"]["месяц_назад"], 1)

    # серия недель в текущей зоне (по границам края)
    зона_now = "эйфория" if T >= КРАЙ_ВЕРХ else "паника" if T <= КРАЙ_НИЗ else "середина"
    серия = 0
    for v in hist.iloc[::-1]:
        z = "эйфория" if v >= КРАЙ_ВЕРХ else "паника" if v <= КРАЙ_НИЗ else "середина"
        if z != зона_now:
            break
        серия += 1
    E["серия_недель_в_зоне"] = серия
    E["зона_края"] = зона_now

    # ── 3. последний заход в крайность и что было дальше
    spx = yahoo("^GSPC", a.data)
    L.series("sp500", "Yahoo ^GSPC", spx.index.max(), len(spx))

    def вперёд(d, n):
        i = spx.index.searchsorted(d)
        return float(spx.iloc[i + n] / spx.iloc[i] - 1) * 100 if i + n < len(spx) else None

    заходы = []
    прошлое = "середина"
    for d, v in hist.items():
        z = "эйфория" if v >= КРАЙ_ВЕРХ else "паника" if v <= КРАЙ_НИЗ else "середина"
        if z != "середина" and прошлое == "середина":
            заходы.append({"дата": str(d)[:10], "зона": z, "значение": round(float(v), 1),
                           "через_месяц": вперёд(d, 21), "через_квартал": вперёд(d, 63)})
        прошлое = z
    for e in заходы:
        for k in ("через_месяц", "через_квартал"):
            if e[k] is not None:
                e[k] = round(e[k], 1)
    E["заходы_в_край"] = {"всего": len(заходы), "последние": заходы[-4:],
                          "эйфория": sum(1 for e in заходы if e["зона"] == "эйфория"),
                          "паника": sum(1 for e in заходы if e["зона"] == "паника")}
    if заходы:
        L.value("последний_заход_в_край", заходы[-1]["дата"], "расчёт wsm-extra", a.cutoff, "дата")

    # ── 4. слова против дел — только группы с живыми рядами
    группы = []
    # частные инвесторы: опрос AAII против спроса на высокую бету
    aaii = None
    try:
        b = fetch("https://www.aaii.com/files/surveys/sentiment.xls", ua=BUA)
        d = pd.read_excel(io.BytesIO(b), skiprows=3)
        d = d.rename(columns={d.columns[0]: "date"})
        d["date"] = pd.to_datetime(d["date"], errors="coerce")
        d = d.dropna(subset=["date"])
        bull = pd.to_numeric(d[d.columns[1]], errors="coerce")
        aaii = pd.Series(bull.values, index=d["date"]).dropna()
        aaii = aaii[aaii.index <= cut]
        if aaii.max() <= 1.5:
            aaii = aaii * 100
        L.series("опрос_частных", "AAII", aaii.index.max(), len(aaii), layer="медленный")
    except Exception as e:
        L.gap("опрос_частных", ["AAII"], str(e)[:90])

    sphb, splv = yahoo("SPHB", a.data), yahoo("SPLV", a.data)
    бета = None
    if sphb is not None and splv is not None:
        бета = (sphb / splv.reindex(sphb.index, method="ffill")).dropna()
        бета = бета[бета.index <= cut]
        L.series("высокая_бета_к_низкой_волатильности", "Yahoo SPHB/SPLV",
                 бета.index.max(), len(бета))
    if aaii is not None and бета is not None:
        м_слова, м_дела = место(aaii, float(aaii.iloc[-1])), место(бета, float(бета.iloc[-1]))
        группы.append({"кто": "Частные инвесторы",
                       "говорит": "доля ждущих роста %.1f %%" % float(aaii.iloc[-1]),
                       "делает": "спрос на рискованные бумаги",
                       "место_слов": м_слова, "место_дел": м_дела,
                       "расхождение": abs(м_слова - м_дела),
                       "дата_слов": str(aaii.index[-1])[:10]})

    ins = comp.get("инсайдеры", {})
    if ins.get("значение") is not None:
        группы.append({"кто": "Инсайдеры компаний", "говорит": "публично не высказываются",
                       "делает": "продают в %.1f раза больше, чем покупают" % float(ins["значение"]),
                       "место_слов": None, "место_дел": round(float(ins["место"]), 1),
                       "расхождение": None, "дата_слов": ins.get("дата")})

    защита, участие = comp.get("цена_защиты", {}), comp.get("участие", {})
    if защита.get("место") is not None and участие.get("место") is not None:
        м_слова, м_дела = round(float(защита["место"]), 1), round(float(участие["место"]), 1)
        группы.append({"кто": "Рынок целиком",
                       "говорит": "платит за страховку от обвала",
                       "делает": "%.1f %% бумаг растут" % float(участие["значение"]),
                       "место_слов": м_слова, "место_дел": м_дела,
                       "расхождение": abs(м_слова - м_дела), "дата_слов": защита.get("дата")})

    for g in группы:
        r = g["расхождение"]
        g["словом"] = None if r is None else ("резко" if r > 60 else "заметно" if r >= 30 else "нет")
    E["группы"] = группы
    L.value("групп_в_таблице", len(группы), "расчёт wsm-extra", a.cutoff, "строк")

    # ── 5. портфель темы: аппетит к риску внутри акций
    P = {}
    for имя, тикер in (("высокая_бета", "SPHB"), ("низкая_волатильность", "SPLV"),
                       ("деньги", "SGOV")):
        s = yahoo(тикер, a.data)
        if s is None:
            continue
        s = s[s.index <= cut]
        мес = s[s.index <= cut - pd.Timedelta(days=28)]
        год = s[s.index <= cut - pd.Timedelta(days=365)]
        P[имя] = {"тикер": тикер, "цена": round(float(s.iloc[-1]), 2),
                  "д4_проц": round(float(s.iloc[-1] / мес.iloc[-1] - 1) * 100, 1) if len(мес) else None,
                  "год_проц": round(float(s.iloc[-1] / год.iloc[-1] - 1) * 100, 1) if len(год) else None}
    if бета is not None:
        P["отношение_бета_к_защите"] = {"значение": round(float(бета.iloc[-1]), 3),
                                        "место": место(бета, float(бета.iloc[-1]))}
    E["портфель"] = P
    L.value("портфель", len(P), "Yahoo", a.cutoff, "позиций")

    # ── 6. ряды для графиков
    def ser(s, days, r=2):
        s = s[s.index >= cut - pd.Timedelta(days=days)]
        return {"даты": [str(d)[:10] for d in s.index],
                "значения": [round(float(v), r) for v in s]}
    E["chart_data"] = {
        "термометр_3г": ser(hist, 1095, 1),
        "бета_к_защите_3г": ser(бета, 1095, 3) if бета is not None else None,
        "исходы": C["исходы"]["горизонты"],
    }
    E["исходы"] = C["исходы"]
    E["компоненты"] = comp

    json.dump(E, open(os.path.join(a.out, "extra.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print("термометр %.1f (%s), до эйфории %.1f, до паники %.1f, серия %d нед" %
          (T, C["зона"], вверх, вниз, серия))
    print("заходов в край с 2011: %d (эйфория %d, паника %d); последний %s" %
          (len(заходы), E["заходы_в_край"]["эйфория"], E["заходы_в_край"]["паника"],
           заходы[-1]["дата"] if заходы else "нет"))
    print("групп в таблице:", len(группы), "| портфель:", list(P))


if __name__ == "__main__":
    main()
