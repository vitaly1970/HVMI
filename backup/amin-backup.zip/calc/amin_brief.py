#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Задание редактору — общий сборщик для всех продуктов серии (решение издателя 07.09.2026).

Код продукта — ключ --code (aicm, qeg, macro, …); имя файла и адреса даёт реестр amin_run.
Собирает файл задания из черновика выпуска: шапка редактору с числом слов N,
под ней черновик без изменений. По ключу --send отправляет задание и слепок
чисел на сайт приёмом /api/brief-import.

    python3 amin_brief.py draft.md --code qeg --cutoff ГГГГ-ММ-ДД --deliver /mnt/user-data/outputs
    python3 amin_brief.py draft.md --code qeg --cutoff ГГГГ-ММ-ДД --deliver /mnt/user-data/outputs --send --calc out/calc.json --note "..."

Секрет сайта берётся так же, как в amin_run: переменная AMIN_STATE_TOKEN,
запасная INDICATOR_TOKEN, файл state-token рядом."""
import argparse
import json
import os
import re
import sys
import urllib.request
import uuid

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import amin_run  # noqa: E402

IMPORT_URL = "https://www.americaninvestor.capital/api/brief-import"

MARK_A, MARK_B = "<!-- ШАПКА-РЕДАКТОРУ -->", "<!-- /ШАПКА-РЕДАКТОРУ -->"


def head_text():
    """Шапка редактору берётся из установленного скилла invest-reports между
    метками; копии здесь нет (решение издателя 07.09.2026).

    Каталог набора ищет сторож редакций: у него список корней, а не образец
    внутри /mnt/skills. В ночной задаче наборы лежат в другом корне, и свой
    поиск расходился со сторожем — один набор находил, другой нет."""
    try:
        import skills_print
    except ImportError:
        raise SystemExit(
            "нет skills_print.py рядом с amin_brief.py — взять его командой "
            "`python3 amin_run.py --calc-get skills_print.py --dest .`")
    каталог = skills_print.найти("invest-reports")
    if каталог:
        path = os.path.join(каталог, "SKILL.md")
        t = open(path, encoding="utf-8").read()
        if MARK_A in t and MARK_B in t:
            return t.split(MARK_A, 1)[1].split(MARK_B, 1)[0].strip() + "\n\n---\n\n"
    raise SystemExit("шапка редактору не найдена: нет установленного invest-reports с метками ШАПКА-РЕДАКТОРУ")


def strip_charts(text):
    """Строки графиков редактору не идут — их держит черновик для сборки."""
    return re.sub(r"^!\[[^\n]*\]\([^\n]*\)\n\n?", "", text, flags=re.M)



def word_count(text):
    return len(re.findall(r"[\w\u0400-\u04ff]+(?:[-’'][\w\u0400-\u04ff]+)*", text))


def build(draft_path, cutoff, deliver, code="aicm"):
    draft = strip_charts(open(draft_path, encoding="utf-8").read().strip() + "\n")
    n = word_count(draft)
    base = amin_run.slug(code, cutoff)
    os.makedirs(deliver, exist_ok=True)
    out = os.path.join(deliver, "Задание-" + base + ".md")
    open(out, "w", encoding="utf-8").write(head_text().replace(" N ", " %d " % n).replace("меньше N", "меньше %d" % n) + draft)
    return out, n, base


def _token():
    for name in ("AMIN_STATE_TOKEN", "INDICATOR_TOKEN"):
        v = os.environ.get(name)
        if v:
            return v.strip()
    p = os.path.join(HERE, "state-token")
    if os.path.exists(p):
        return open(p, encoding="utf-8").read().strip()
    raise SystemExit("секрет сайта не найден: AMIN_STATE_TOKEN, INDICATOR_TOKEN или файл state-token")


def send(brief_path, base, cutoff, calc_path=None, note=""):
    boundary = "----amin" + uuid.uuid4().hex
    parts = []

    def field(name, value):
        parts.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"\r\n\r\n%s\r\n"
                      % (boundary, name, value)).encode("utf-8"))

    def file_field(name, filename, data, ctype):
        parts.append(("--%s\r\nContent-Disposition: form-data; name=\"%s\"; filename=\"%s\"\r\n"
                      "Content-Type: %s\r\n\r\n" % (boundary, name, filename, ctype)).encode("utf-8"))
        parts.append(data)
        parts.append(b"\r\n")

    file_field("file", base + ".brief.md", open(brief_path, "rb").read(), "text/markdown; charset=utf-8")
    if calc_path and os.path.exists(calc_path):
        file_field("calc", base + ".calc.json", open(calc_path, "rb").read(), "application/json")
    field("cutoff", cutoff)
    field("note", note)
    parts.append(("--%s--\r\n" % boundary).encode("utf-8"))
    body = b"".join(parts)
    req = urllib.request.Request(IMPORT_URL, data=body, method="POST", headers={
        "Content-Type": "multipart/form-data; boundary=" + boundary,
        "Authorization": "Bearer " + _token(),
        "User-Agent": "American Investor research v.kurdyumov@americaninvestor.org",
    })
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode("utf-8", "replace")


def main():
    ap = argparse.ArgumentParser(description="Задание редактору — общий сборщик серии")
    ap.add_argument("draft")
    ap.add_argument("--code", default="aicm")
    ap.add_argument("--cutoff", required=True)
    ap.add_argument("--deliver", default="/mnt/user-data/outputs")
    ap.add_argument("--send", action="store_true")
    ap.add_argument("--calc", default="out/calc.json")
    ap.add_argument("--note", default="")
    ap.add_argument("--state", default="out/state.json",
                    help="снимок состояния прогона; пишется в хранилище датой среза сразу после передачи задания")
    a = ap.parse_args()
    out, n, base = build(a.draft, a.cutoff, a.deliver, a.code)
    print("задание собрано: %s · слов в черновике %d" % (out, n))
    if a.send:
        status, text = send(out, base, a.cutoff, a.calc, a.note)
        print("ответ сервера %s: %s" % (status, text[:300]))
        try:
            ok = json.loads(text).get("ok")
        except ValueError:
            ok = False
        if not ok:
            return 2
        return 0 if write_state(a.code, a.state, a.cutoff) else 2
    return 0


def write_state(code, state_path, cutoff):
    """Снимок состояния пишется прогоном сразу после передачи задания, а не
    после публикации (решение издателя 07.09.2026): ряды продукта живут только в
    снимках, и пока снимок ждал публикации, история не копилась. Нет файла —
    снимок не записан, и об этом сказано вслух; продукт без снимка так и
    работает."""
    if not os.path.exists(state_path):
        print("снимок не записан: файла %s нет" % state_path)
        return True
    state = json.load(open(state_path, encoding="utf-8"))
    if not isinstance(state, dict) or not state:
        print("СТОП: снимок %s пуст или не словарь" % state_path)
        return False
    try:
        ok = amin_run.state_put(amin_run.state_key(code), state, cutoff)
    except amin_run.StateError as e:
        print("СТОП: снимок не записан — %s" % e)
        return False
    print("снимок записан: %s@%s (%d ключей)" % (amin_run.state_key(code), cutoff, len(state)))
    return bool(ok)


if __name__ == "__main__":
    sys.exit(main())
