#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Графики выпуска «Отчётность и прогнозы» (код qeg).

Четыре графика брендовой палитрой American Investor — обязательный минимум
промпта:
  1. eps_forward.png — прибыль на год вперёд, окно тринадцать недель;
  2. revisions.png   — направление пересмотров: оценка роста прибыли на
     текущий квартал и число секторов с повышением;
  3. credit.png      — премия за кредитный риск, год;
  4. semis.png       — полупроводники относительно индекса, год.

Ряд прибыли на год вперёд провайдер печатает картинкой, поэтому он считается
из двух текстовых величин еженедельного выпуска: цена индекса на ту же дату,
делённая на цену к прибыли вперёд. Ряд короче трёх точек не рисуется вовсе —
дорисовывать запрещено (PD-2).

Запуск: python3 charts_qeg.py --cutoff ГГГГ-ММ-ДД --data data --out out
"""
import argparse
import csv
import datetime
import io
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

NAVY = "#10253F"
RED = "#D90F14"
GREY = "#8A93A0"
GRID = "#DCE1E7"

МИНИМУМ_ТОЧЕК = 3


def _рамка(ax, заголовок, подпись_оси=None):
    ax.set_title(заголовок, color=NAVY, fontsize=12, loc="left", pad=12)
    if подпись_оси:
        ax.set_ylabel(подпись_оси, color=NAVY, fontsize=9)
    ax.grid(True, color=GRID, linewidth=0.7)
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(GRID)
    ax.tick_params(colors=NAVY, labelsize=8)


def _сохранить(fig, out_dir, имя):
    fig.tight_layout()
    путь = os.path.join(out_dir, имя)
    fig.savefig(путь, dpi=160)
    plt.close(fig)
    return путь


def _цены(data_dir, файл):
    d = json.load(io.open(os.path.join(data_dir, файл), encoding="utf-8"))
    r = d["chart"]["result"][0]
    даты = [datetime.date.fromtimestamp(t) for t in r["timestamp"]]
    закр = r["indicators"]["quote"][0]["close"]
    return {д: c for д, c in zip(даты, закр) if c}


def _фред(data_dir, файл):
    ряд = {}
    for r in csv.reader(io.open(os.path.join(data_dir, файл), encoding="utf-8")):
        if r and r[0][:2] == "20":
            try:
                ряд[datetime.date.fromisoformat(r[0])] = float(r[1])
            except ValueError:
                pass
    return ряд


def прибыль_вперёд(data_dir, out_dir):
    """Прибыль на год вперёд: цена индекса, делённая на цену к прибыли."""
    выпуски = json.load(io.open(os.path.join(data_dir, "ei_series.json"),
                                encoding="utf-8"))
    цены = _цены(data_dir, "y_%5EGSPC.json")
    точки = []
    for д, з in sorted(выпуски.items()):
        pe = з.get("fwd_pe")
        if not pe:
            continue
        дата = datetime.date.fromisoformat(д)
        близкие = [x for x in цены if x <= дата]
        if not близкие:
            continue
        точки.append((дата, цены[max(близкие)] / pe))
    if len(точки) < МИНИМУМ_ТОЧЕК:
        return None
    даты = [t[0] for t in точки]
    знач = [t[1] for t in точки]
    fig, ax = plt.subplots(figsize=(9, 4.2))
    ax.plot(даты, знач, color=NAVY, linewidth=2, marker="o", markersize=4)
    ax.fill_between(даты, min(знач) * 0.98, знач, color=NAVY, alpha=0.12)
    _рамка(ax, "Прибыль на год вперёд, долларов на акцию индекса")
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, p: "%.0f" % v))
    ax.annotate("%.0f" % знач[-1], (даты[-1], знач[-1]), color=RED,
                fontsize=9, xytext=(-28, 8), textcoords="offset points")
    return _сохранить(fig, out_dir, "eps_forward.png")


def пересмотры(data_dir, out_dir):
    """Направление пересмотров: оценка роста прибыли на текущий квартал и
    число секторов, у которых оценку подняли."""
    выпуски = json.load(io.open(os.path.join(data_dir, "ei_series.json"),
                                encoding="utf-8"))
    точки = [(datetime.date.fromisoformat(д), з)
             for д, з in sorted(выпуски.items()) if з.get("рост_вперёд")]
    if len(точки) < МИНИМУМ_ТОЧЕК:
        return None
    даты = [t[0] for t in точки]
    рост = [t[1]["рост_вперёд"] for t in точки]
    fig, ax = plt.subplots(figsize=(9, 4.2))
    ax.plot(даты, рост, color=NAVY, linewidth=2, marker="o", markersize=4,
            label="Оценка роста прибыли, % год к году")
    _рамка(ax, "Направление пересмотров по ходу квартала")
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, p: "%.0f%%" % v))
    ax2 = ax.twinx()
    сект = [(д, з["секторов_вверх"]) for д, з in точки if з.get("секторов_вверх")]
    if сект:
        ax2.bar([s[0] for s in сект], [s[1] for s in сект], width=6,
                color=RED, alpha=0.35, label="Секторов с повышением, из 11")
        ax2.set_ylim(0, 11)
    ax2.tick_params(colors=NAVY, labelsize=8)
    for s in ("top", "left"):
        ax2.spines[s].set_visible(False)
    ax2.spines["right"].set_color(GRID)
    h1, l1 = ax.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, frameon=False, fontsize=8, labelcolor=NAVY,
              loc="upper center", bbox_to_anchor=(0.5, -0.08), ncol=2)
    return _сохранить(fig, out_dir, "revisions.png")


def кредит(data_dir, out_dir, cutoff):
    ряд = _фред(data_dir, "BAMLH0A0HYM2.csv")
    даты = [д for д in sorted(ряд) if д <= cutoff]
    if len(даты) < МИНИМУМ_ТОЧЕК:
        return None
    знач = [ряд[д] * 100 for д in даты]
    fig, ax = plt.subplots(figsize=(9, 4.2))
    ax.plot(даты, знач, color=NAVY, linewidth=1.8)
    ax.fill_between(даты, min(знач) * 0.9, знач, color=NAVY, alpha=0.12)
    _рамка(ax, "Премия за кредитный риск, базисных пунктов")
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, p: "%.0f" % v))
    ax.annotate("%.0f" % знач[-1], (даты[-1], знач[-1]), color=RED,
                fontsize=9, xytext=(-30, 8), textcoords="offset points")
    return _сохранить(fig, out_dir, "credit.png")


def полупроводники(data_dir, out_dir):
    sox = _цены(data_dir, "y_%5ESOX.json")
    spx = _цены(data_dir, "y_%5EGSPC.json")
    общие = sorted(set(sox) & set(spx))
    if len(общие) < МИНИМУМ_ТОЧЕК:
        return None
    b_sox, b_spx = sox[общие[0]], spx[общие[0]]
    fig, ax = plt.subplots(figsize=(9, 4.2))
    ax.plot(общие, [sox[д] / b_sox * 100 for д in общие], color=RED,
            linewidth=1.8, label="Полупроводники")
    ax.plot(общие, [spx[д] / b_spx * 100 for д in общие], color=NAVY,
            linewidth=1.8, label="Индекс широкого рынка")
    ax.axhline(100, color=GREY, linewidth=1)
    _рамка(ax, "Полупроводники против индекса, год назад = 100")
    ax.legend(frameon=False, fontsize=8, labelcolor=NAVY)
    return _сохранить(fig, out_dir, "semis.png")


def main():
    ap = argparse.ArgumentParser(description="Графики выпуска «Отчётность и прогнозы»")
    ap.add_argument("--cutoff", required=True)
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="out")
    a = ap.parse_args()
    срез = datetime.date.fromisoformat(a.cutoff)
    os.makedirs(a.out, exist_ok=True)
    for имя, путь in [("прибыль на год вперёд", прибыль_вперёд(a.data, a.out)),
                      ("направление пересмотров", пересмотры(a.data, a.out)),
                      ("премия за кредитный риск", кредит(a.data, a.out, срез)),
                      ("полупроводники против индекса", полупроводники(a.data, a.out))]:
        print("собран %s: %s" % (имя, путь) if путь
              else "НЕ ПЕЧАТАЕТСЯ (%s): ряд короче трёх точек" % имя)


if __name__ == "__main__":
    main()
