#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""r_charts.py — три графика выпуска «Ротация секторов».

Состав задан разделом F промпта: отклонение секторов к рынку, отклонение
факторных фондов, разрыв лидер — аутсайдер за год с отметками смены лидера.
Тепловая карта силы движения и кривые стратегий сняты решениями издателя
15.08 и 23.08.2026 и здесь не строятся.

Вход — выгрузки прогона, своей арифметики нет:
  /home/claude/devdata.json   отклонения секторов на дату среза (lead_run.py)
  /home/claude/rdata.json     факторные фонды (r_calc.py)
  /home/claude/histdata.json  ряд разрыва за год и смены лидера (lead_hist.py)
Выход в текущую директорию: chart_dev.png, chart_factors.png, chart_gap.png.
Палитра берётся из charts.py скилла report-format, сам скилл не правится.
"""
import json, os, sys
sys.path.insert(0, "assets/templates")
sys.path.insert(0, "assets")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from charts import INK, NAVY as BLUE, GREEN, DANGER, MUTED, LINE, FS_NOTE, FS_LABEL, FS_TITLE


def читать(путь):
    if not os.path.exists(путь):
        sys.exit("ОСТАНОВКА: нет выгрузки %s — график строить не из чего." % путь)
    return json.load(open(путь, encoding="utf-8"))


DEV = читать("/home/claude/devdata.json")
D = читать("/home/claude/rdata.json")
H = читать("/home/claude/histdata.json")
RU = DEV.get("RU") or D.get("RU") or {}
готово = []

# --- 1. отклонение секторов к рынку ------------------------------------------
rank = DEV["rank"]
имена = [RU.get(t, t) for t, _ in rank]
знач = [v * 100 for _, v in rank]
fig, ax = plt.subplots(figsize=(8.6, 0.42 * len(rank) + 1.2))
# Поле под названия секторов задаётся явно: у самых длинных имён подпись
# иначе наезжает на числа отрицательных столбцов.
fig.subplots_adjust(left=0.30)
ax.barh(range(len(rank)), знач,
        color=[GREEN if v >= 0 else DANGER for v in знач], height=0.6)
ax.set_yticks(range(len(rank)))
ax.set_yticklabels(имена, fontsize=FS_LABEL, color=INK)
ax.invert_yaxis()
ax.axvline(0, color=LINE, lw=0.9)
# Подпись отрицательного столбца ставится справа от нуля, а не у его конца:
# у левого края она наезжает на название сектора.
for i, v in enumerate(знач):
    x = v + 0.25 if v >= 0 else 0.25
    ax.text(x, i, "%+.1f%%" % v, va="center", ha="left",
            fontsize=FS_NOTE, color=INK)
ax.set_title("Отклонение секторов к S&P 500 за квартал, %",
             fontsize=FS_TITLE, color=INK, loc="left", pad=10)
ax.tick_params(length=0, labelsize=FS_NOTE, colors=MUTED)
for s in ("top", "right", "left"):
    ax.spines[s].set_visible(False)
fig.savefig("chart_dev.png", dpi=150, facecolor="white")
plt.close(fig)
готово.append("chart_dev.png")

# --- 2. факторные фонды ------------------------------------------------------
F = D.get("factors") or {}
RUF = {"MTUM": "импульс", "QUAL": "качество", "USMV": "низкая волатильность",
       "VLUE": "стоимость"}
if F:
    keys = sorted(F, key=lambda k: -F[k]["отклонение"])
    vals = [F[k]["отклонение"] * 100 for k in keys]
    fig, ax = plt.subplots(figsize=(6.8, 0.42 * len(keys) + 1.2))
    ax.barh(range(len(keys)), vals,
            color=[GREEN if v >= 0 else DANGER for v in vals], height=0.55)
    ax.set_yticks(range(len(keys)))
    ax.set_yticklabels([RUF.get(k, k) for k in keys], fontsize=FS_LABEL, color=INK)
    ax.invert_yaxis()
    ax.axvline(0, color=LINE, lw=0.9)
    for i, v in enumerate(vals):
        ax.text(v + (0.15 if v >= 0 else -0.15), i, "%+.1f" % v, va="center",
                ha="left" if v >= 0 else "right", fontsize=FS_NOTE, color=INK)
    ax.set_title("Отклонение факторных фондов к S&P 500 за три месяца, п.п.",
                 fontsize=FS_TITLE, color=INK, loc="left", pad=10)
    ax.tick_params(length=0, labelsize=FS_NOTE, colors=MUTED)
    for s in ("top", "right", "left"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig("chart_factors.png", dpi=150, facecolor="white")
    plt.close(fig)
    готово.append("chart_factors.png")

# --- 3. разрыв лидер — аутсайдер за год --------------------------------------
ряд = H.get("ряд") or []
if ряд:
    даты = [т["дата"] for т in ряд]
    разрыв = [т["разрыв"] for т in ряд]
    fig, ax = plt.subplots(figsize=(7.2, 3.0))
    ax.plot(range(len(ряд)), разрыв, color=BLUE, lw=1.6)
    место = {т["дата"]: i for i, т in enumerate(ряд)}
    точки = [(место[с["дата"]], с["разрыв"]) for с in H.get("смены", [])
             if с["дата"] in место]
    if точки:
        ax.scatter([x for x, _ in точки], [y for _, y in точки],
                   s=22, color=DANGER, zorder=3, label="смена лидера")
        ax.legend(fontsize=FS_NOTE, frameon=False)
    шаг = max(1, len(ряд) // 8)
    ax.set_xticks(range(0, len(ряд), шаг))
    ax.set_xticklabels([даты[i][:7] for i in range(0, len(ряд), шаг)],
                       fontsize=FS_NOTE, color=MUTED, rotation=45, ha="right")
    ax.tick_params(length=0, labelsize=FS_NOTE, colors=MUTED)
    ax.set_title("Разрыв между первым и последним сектором за год, п.п.",
                 fontsize=FS_TITLE, color=INK, loc="left", pad=10)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    fig.tight_layout()
    fig.savefig("chart_gap.png", dpi=150, facecolor="white")
    plt.close(fig)
    готово.append("chart_gap.png")

print("PNG:", ", ".join(готово))
if len(готово) < 3:
    sys.exit("ОСТАНОВКА: собрано %d графика из трёх — выпуск неполный." % len(готово))
