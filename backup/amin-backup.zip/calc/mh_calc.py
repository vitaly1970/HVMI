#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""mh_calc.py — замороженный расчёт выпуска «Здоровье рынка» (код продукта mh).

Один запуск: качает ряды реестра Р.1 → считает блоки Р.2–Р.17 → пишет
out/calc.json, out/series.pkl (вход графиков) и журнал out/channels.jsonl.
Синтез выпуска читает ТОЛЬКО calc.json: пересчёт в сборке запрещён.

    python3 mh_calc.py --cutoff 2026-08-10 --data data --out out [--cache]

--cache берёт уже скачанное с диска и не ходит в сеть (повторный прогон дня).
"""

import argparse, json, os, pickle, sys, time
import datetime as dt
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote

import numpy as np
import pandas as pd
import requests

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import amin_run
from amin_run import Log

CALC_VERSION = "mh-calc 1.2 (15.08.2026)"
CODE = "mh"

# Ключ платного канала живёт в одном месте — amin_secrets из хранилища
# расчётных модулей. Прежнее значение остаётся запасным на случай прогона
# без набора рядом.
from amin_secrets import tiingo_key as _tiingo_key

TIINGO_KEY = _tiingo_key()
FUNDS = ["SPY", "RSP", "IWM", "IWF", "IWD", "MTUM", "QUAL", "USMV", "SPLV",
         "VLUE", "SPHB"]
PROXIES = ["TLT", "IEF", "GLD", "UUP", "IBIT", "ASHR"]
RATES = {"доходность_10л": "DGS10", "доходность_2л": "DGS2",
         "индекс_доллара": "DTWEXBGS"}
CBOE = {"dspx": "DSPX_History.csv", "cor3m": "COR3M_History.csv",
        "vix": "VIX_History.csv", "vvix": "VVIX_History.csv",
        "vix9d": "VIX9D_History.csv", "vix3m": "VIX3M_History.csv"}
NEIGHBOURS = {"credit": "Кредитный цикл", "wlm": "Системная ликвидность",
              "lead": "Ротация секторов", "flows": "Потоки в фонды",
              "wpm": "Позиционирование участников"}

UA_BROWSER = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")
SESS = requests.Session()
SESS.headers.update({"User-Agent": UA_BROWSER})


def _get(url, tries=4, pause=3.0, **kw):
    """Обращение с повтором: посредник песочницы периодически отвечает 503
    «DNS resolution failure» на живом канале. Один отказ каналом не считается."""
    last = None
    timeout = kw.pop("timeout", 90)
    for i in range(tries):
        try:
            if i:
                SESS.close()          # сброс соединения: залипший DNS даёт 503
            r = SESS.get(url, timeout=timeout, **kw)
            if r.status_code == 200:
                return r
            last = r
            if r.status_code == 429:
                time.sleep(60)
                continue
        except Exception as e:
            last = e
        time.sleep(pause * (i + 1))
    return last

np.seterr(all="ignore")


# ----------------------------------------------------------------- утилиты

def causal_pct(s, win=2520, minp=504):
    """Каузальный перцентиль: доля прошлого окна ниже текущего значения."""
    v = s.to_numpy(dtype="float64")
    out = np.full(len(v), np.nan)
    for i in range(len(v)):
        x = v[i]
        if not np.isfinite(x):
            continue
        w = v[max(0, i - win):i]
        w = w[np.isfinite(w)]
        if len(w) < minp:
            continue
        out[i] = (w < x).mean() * 100.0
    return pd.Series(out, index=s.index)


def causal_z(s, win=252):
    m = s.rolling(win, min_periods=win).mean().shift(1)
    sd = s.rolling(win, min_periods=win).std(ddof=0).shift(1)
    return (s - m) / sd


def r1(x, n=1):
    return None if x is None or not np.isfinite(x) else round(float(x), n)


def stats(v):
    v = np.asarray(pd.Series(v).dropna(), dtype=float)
    if len(v) == 0:
        return None
    return {"n": int(len(v)), "медиана": round(float(np.median(v)), 2),
            "p25": round(float(np.percentile(v, 25)), 2),
            "p75": round(float(np.percentile(v, 75)), 2),
            "доля_положительных": round(float((v > 0).mean() * 100), 1)}


# ----------------------------------------------------------------- загрузка

def fetch_cboe(data, log, cache):
    out = {}
    for key, fname in CBOE.items():
        path = os.path.join(data, "cboe_%s.csv" % key)
        if not (cache and os.path.exists(path)):
            url = "https://cdn.cboe.com/api/global/us_indices/daily_prices/" + fname
            r = _get(url)
            ok = getattr(r, "status_code", 0) == 200
            log.get("CBOE", url, ok)
            if not ok:
                raise RuntimeError("CBOE не ответил: %s" % r)
            open(path, "w", encoding="utf-8").write(r.text)
            time.sleep(0.3)
        df = pd.read_csv(path)
        df["DATE"] = pd.to_datetime(df["DATE"], format="mixed")
        col = "CLOSE" if "CLOSE" in df.columns else df.columns[-1]
        if key == "dspx" and "DSPX" in df.columns:
            col = "DSPX"
        if key == "vvix" and "VVIX" in df.columns:
            col = "VVIX"
        out[key] = df.set_index("DATE")[col].astype(float).sort_index()
    return out


def fetch_constituents(data, log, cache):
    path = os.path.join(data, "constituents.csv")
    url = ("https://raw.githubusercontent.com/datasets/s-and-p-500-companies/"
           "main/data/constituents.csv")
    if not (cache and os.path.exists(path)):
        r = _get(url)
        ok = getattr(r, "status_code", 0) == 200
        log.get("состав индекса", url, ok)
        if not ok:
            raise RuntimeError("состав индекса не получен: %s" % r)
        open(path, "w", encoding="utf-8").write(r.text)
    df = pd.read_csv(path)
    df["Symbol"] = df["Symbol"].astype(str).str.strip()
    if "Date added" in df.columns:
        df["Date added"] = pd.to_datetime(df["Date added"], errors="coerce")
    return df


def fetch_tiingo(data, log, cache):
    os.makedirs(os.path.join(data, "tiingo"), exist_ok=True)
    px = {}
    for t in FUNDS:
        path = os.path.join(data, "tiingo", t + ".csv")
        if not (cache and os.path.exists(path)):
            url = ("https://api.tiingo.com/tiingo/daily/%s/prices"
                   "?startDate=1990-01-01&token=%s" % (t, TIINGO_KEY))
            r = _get(url, timeout=120)
            ok = getattr(r, "status_code", 0) == 200
            log.get("Tiingo", url.split("?")[0], ok)
            if not ok:
                raise RuntimeError("Tiingo не ответил по %s: %s" % (t, r))
            df = pd.DataFrame(r.json())
            df["date"] = pd.to_datetime(df["date"]).dt.tz_localize(None).dt.normalize()
            df[["date", "adjClose"]].sort_values("date").to_csv(path, index=False)
            time.sleep(1.1)
        d = pd.read_csv(path, parse_dates=["date"]).set_index("date")["adjClose"]
        px[t] = d.astype(float)
    return pd.DataFrame(px).sort_index()


def _sa_history(t):
    url = ("https://stockanalysis.com/api/symbol/s/%s/history"
           "?range=10Y&period=Daily" % t)
    r = _get(url, tries=3, pause=1.5)
    if getattr(r, "status_code", 0) == 200:
        try:
            d = r.json().get("data")
        except Exception:
            d = None
        if d:
            df = pd.DataFrame(d)[["t", "a"]].rename(columns={"t": "date", "a": t})
            return t, df, None
        return t, None, "пусто"
    return t, None, "канал не ответил"


def fetch_wide(tickers, path, log, cache, channel):
    if cache and os.path.exists(path):
        return pd.read_pickle(path), []
    res, fails = {}, []
    with ThreadPoolExecutor(max_workers=8) as ex:
        for t, df, err in ex.map(_sa_history, tickers):
            if df is None:
                fails.append(t)
            else:
                res[t] = df
    log.get(channel, "stockanalysis.com/api/symbol/s/<тикер>/history",
            len(res) > 0, "получено %d из %d" % (len(res), len(tickers)))
    wide = None
    for t, df in res.items():
        df = df.drop_duplicates("date").set_index("date")
        wide = df if wide is None else wide.join(df, how="outer")
    wide.index = pd.to_datetime(wide.index)
    wide = wide.sort_index().astype("float64")
    wide.to_pickle(path)
    return wide, fails


def fetch_rates(data, log, cache):
    out = {}
    for key, sid in RATES.items():
        path = os.path.join(data, "fred_%s.csv" % sid)
        if not (cache and os.path.exists(path)):
            target = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=" + sid
            url = ("https://www.americaninvestor.capital/app/api/proxy?url="
                   + quote(target, safe=""))
            r = _get(url, headers={"User-Agent": "curl/8.5.0",
                                   "Accept": "text/csv"})
            ok = getattr(r, "status_code", 0) == 200 and r.text.startswith("DATE")
            log.get("посредник сайта → FRED %s" % sid, url, ok)
            if not ok:
                log.gap(key, ["посредник сайта → FRED"], "канал не ответил")
                continue
            open(path, "w", encoding="utf-8").write(r.text)
            time.sleep(1.2)
        df = pd.read_csv(path)
        df.columns = ["DATE", "VALUE"]
        df["DATE"] = pd.to_datetime(df["DATE"])
        s = pd.to_numeric(df["VALUE"], errors="coerce")
        out[key] = pd.Series(s.to_numpy(), index=df["DATE"]).dropna()
    return out


# ----------------------------------------------------------------- расчёт

def breadth(basket, valid):
    sma200 = basket.rolling(200, min_periods=200).mean()
    sma50 = basket.rolling(50, min_periods=50).mean()
    ok200 = basket.notna() & sma200.notna() & valid
    ok50 = basket.notna() & sma50.notna() & valid
    a200 = ((basket > sma200) & ok200).sum(axis=1) / ok200.sum(axis=1) * 100
    a50 = ((basket > sma50) & ok50).sum(axis=1) / ok50.sum(axis=1) * 100
    mx = basket.rolling(252, min_periods=252).max()
    mn = basket.rolling(252, min_periods=252).min()
    okh = basket.notna() & mx.notna() & valid
    nh = ((basket >= mx) & okh).sum(axis=1)
    nl = ((basket <= mn) & okh).sum(axis=1)
    nhnl = (nh - nl) / okh.sum(axis=1).replace(0, np.nan) * 100
    n = ok200.sum(axis=1)
    return (a200.where(n > 50), a50.where(n > 50), nhnl.where(okh.sum(axis=1) > 50),
            n, ok200, sma200)


def sector_xray(basket, valid, ok200, sma200, sectors, cal):
    """Р.3 — разложение собственной ширины по секторам GICS."""
    above = (basket > sma200) & ok200
    groups = {}
    for sec in sorted(set(sectors.values())):
        cols = [c for c in basket.columns if sectors.get(c) == sec]
        if not cols:
            continue
        groups[sec] = cols
    tot_ok = ok200.sum(axis=1)
    tot_above = above.sum(axis=1)
    rows, shift_hist = [], {}
    offs = {"сейчас": -1, "неделю_назад": -6, "месяц_назад": -22,
            "квартал_назад": -64}
    for sec, cols in groups.items():
        ok_s = ok200[cols].sum(axis=1)
        ab_s = above[cols].sum(axis=1)
        share200 = (ab_s / ok_s.replace(0, np.nan) * 100)
        sma50 = basket[cols].rolling(50, min_periods=50).mean()
        ok50 = basket[cols].notna() & sma50.notna() & valid[cols]
        share50 = (((basket[cols] > sma50) & ok50).sum(axis=1)
                   / ok50.sum(axis=1).replace(0, np.nan) * 100)
        contrib = (ab_s / tot_ok.replace(0, np.nan) * 100)
        row = {"сектор": sec, "бумаг": int(ok_s.iloc[-1]),
               "вклад_в_ширину_пп": r1(contrib.iloc[-1]),
               "выше_200дн": {}, "выше_50дн": {}}
        for name, off in offs.items():
            row["выше_200дн"][name] = r1(share200.iloc[off])
            row["выше_50дн"][name] = r1(share50.iloc[off])
        rows.append(row)
        # ширина без этого сектора — история сдвига
        rest_ok = tot_ok - ok_s
        rest_ab = tot_above - ab_s
        without = rest_ab / rest_ok.replace(0, np.nan) * 100
        shift_hist[sec] = (tot_above / tot_ok.replace(0, np.nan) * 100) - without
    rows.sort(key=lambda r: (r["вклад_в_ширину_пп"] or 0), reverse=True)
    # проверка на маскировку: снятие сильнейшего и двух сильнейших
    strength = {sec: (above[cols].sum(axis=1).iloc[-1] / max(1, ok200[cols].sum(axis=1).iloc[-1]))
                for sec, cols in groups.items()}
    order = sorted(strength, key=strength.get, reverse=True)
    overall = float(tot_above.iloc[-1] / tot_ok.iloc[-1] * 100)
    drop = {}
    for k in (1, 2):
        cut = set()
        for sec in order[:k]:
            cut.update(groups[sec])
        cols = [c for c in basket.columns if c not in cut]
        w = above[cols].sum(axis=1).iloc[-1] / max(1, ok200[cols].sum(axis=1).iloc[-1]) * 100
        drop["без_%d_сильнейших" % k] = {"сектора": order[:k],
                                         "ширина": r1(w),
                                         "сдвиг_пп": r1(overall - w)}
    # замер порога: распределение дневного сдвига при снятии сильнейшего сектора
    allshift = pd.concat(shift_hist.values(), axis=1).abs().max(axis=1).dropna()
    allshift = allshift[allshift.index >= allshift.index[-1] - pd.Timedelta(days=3650)]
    thr = {"наблюдений": int(len(allshift)),
           "p50": r1(np.percentile(allshift, 50)),
           "p80": r1(np.percentile(allshift, 80)),
           "p90": r1(np.percentile(allshift, 90)),
           "p95": r1(np.percentile(allshift, 95)),
           "доля_выше_5пп": r1((allshift > 5).mean() * 100)}
    return {"сектора": rows, "ширина_всего": r1(overall),
            "маскировка": drop, "замер_порога": thr,
            "порог_концентрации_пп": 5.0,
            "концентрировано": bool((drop["без_1_сильнейших"]["сдвиг_пп"] or 0) > 5)}


def event_studies(raw, Z, spy, cal, m21, mx252):
    near = spy >= 0.99 * mx252
    fw = {h: (spy.shift(-h) / spy - 1) * 100 for h in (5, 21, 63)}
    above200dma = spy > spy.rolling(200, min_periods=200).mean()
    trig = {
        "T1": ("капитуляция ширины: доля выше 200-дневной ниже 20 %",
               raw["above200"] < 20, [raw["above200"]]),
        "T2": ("дивергенция у максимума", near & (raw["above200"] < 60),
               [raw["above200"], mx252]),
        "T3": ("спайк имплайд-корреляции", Z["COR3M"] > 2, [Z["COR3M"]]),
        "T4": ("обвал импульса", m21 < -4, [m21]),
        "T5": ("факторный уход от риска", Z["HBLV"] < -2, [Z["HBLV"]]),
        "T6": ("экстремальная узость у максимума", (Z["EQW"] < -2) & near,
               [Z["EQW"], mx252]),
        "T7": ("минимум имплайд-корреляции", Z["COR3M"] < -2, [Z["COR3M"]]),
        "T8": ("всплеск имплайд-дисперсии", Z["DSPX"] > 2, [Z["DSPX"]]),
    }
    ev, active = {}, []
    for k, (desc, cond, inputs) in trig.items():
        okv = pd.Series(True, index=cal)
        for s in inputs:
            okv &= s.reindex(cal).notna()
        if not okv.any():
            continue
        base_idx = okv[okv].index
        c = cond.reindex(cal).fillna(False) & okv
        dates, last = [], None
        for d in cal[c.to_numpy()]:
            if last is None or (cal.get_loc(d) - cal.get_loc(last)) >= 21:
                dates.append(d)
                last = d
        e = {"описание": desc, "эпизодов": len(dates),
             "база_с": str(base_idx[0].date()),
             "последний": str(dates[-1].date()) if dates else None,
             "доля_дней": r1(float(c.loc[base_idx].mean() * 100)),
             "активен_сейчас": bool(c.iloc[-1]),
             "форварды": {}, "база": {}}
        for h in (5, 21, 63):
            e["форварды"][h] = stats(fw[h].loc[dates]) if len(dates) >= 5 else None
            e["база"][h] = stats(fw[h].loc[base_idx])
        ev[k] = e
        if e["активен_сейчас"]:
            active.append(k)
    first_trig = pd.Series(index=cal, dtype=object)
    fired = {k: (v[1].reindex(cal).fillna(False)) for k, v in trig.items()}
    return ev, active, fired


def risk_regime(spy, score, q, cal):
    fw63 = (spy.shift(-63) / spy - 1) * 100
    arr = spy.to_numpy(float)
    n = len(arr)
    mdd = np.full(n, np.nan)
    for i in range(n - 63):
        w = arr[i:i + 64]
        run = np.maximum.accumulate(w)
        mdd[i] = float((w / run - 1).min() * 100)
    MDD = pd.Series(mdd, index=cal)
    fvol = (spy.pct_change().shift(-63).rolling(63).std() * np.sqrt(252) * 100)
    fvol = (spy.pct_change().rolling(63).std().shift(-63) * np.sqrt(252) * 100)
    df = pd.DataFrame({"q": q, "f63": fw63, "mdd": MDD, "fvol": fvol}).dropna(
        subset=["q", "f63"])
    rows = []
    for qq in [1, 2, 3, 4, 5]:
        s = df[df["q"] == qq]
        if not len(s):
            continue
        rows.append({"пятая_часть": int(qq), "наблюдений": int(len(s)),
                     "медиана_квартала": r1(s["f63"].median(), 2),
                     "p10_квартала": r1(np.percentile(s["f63"], 10), 2),
                     "медиана_просадки": r1(s["mdd"].median(), 2),
                     "частота_просадки_хуже_10": r1((s["mdd"] < -10).mean() * 100),
                     "медиана_будущей_волатильности": r1(s["fvol"].median(), 1)})
    base = {"медиана_квартала": r1(df["f63"].median(), 2),
            "частота_просадки_хуже_10": r1((df["mdd"] < -10).mean() * 100),
            "медиана_будущей_волатильности": r1(df["fvol"].median(), 1)}
    return {"строки": rows, "безусловная_база": base,
            "формула_просадки": "максимум внутри окна (не цена входа)"}


WARN = ("T1", "T4", "T5", "T6")


def scenario_forks(q, fired, spy, cal, qtile=None):
    """Развилки следующего квартала из дней той же пятой части истории."""
    cur = q.iloc[-1]
    if pd.isna(cur):
        return {"опубликовано": False, "причина": "Score не публикуется"}
    idx = [i for i in range(len(cal) - 63) if q.iloc[i] == cur]
    if len(idx) < 20:
        return {"опубликовано": False,
                "причина": "в текущей пятой части меньше двадцати дней с "
                           "завершённым кварталом (%d)" % len(idx)}
    held, broke = 0, {}
    f63 = (spy.shift(-63) / spy - 1) * 100
    held_ret, broke_ret = [], []
    # просадка внутри квартала от максимума окна и резкие дни по закрытиям
    arr = spy.to_numpy(float)
    ret = spy.pct_change().to_numpy(float) * 100
    dd_by, sharp_by, dd_hold, sharp_hold = {}, {}, [], []
    for i in idx:
        win = {k: v.iloc[i + 1:i + 64] for k, v in fired.items()}
        first, pos = None, 10 ** 9
        for k, v in win.items():
            w = np.where(v.to_numpy())[0]
            if len(w) and w[0] < pos:
                pos, first = w[0], k
        w = arr[i:i + 64]
        run = np.maximum.accumulate(w)
        dd = float((w / run - 1).min() * 100)
        sharp = int((ret[i + 1:i + 64] < -2).sum())
        if first is None:
            held += 1
            held_ret.append(f63.iloc[i])
            dd_hold.append(dd)
            sharp_hold.append(sharp)
        else:
            broke[first] = broke.get(first, 0) + 1
            broke_ret.append(f63.iloc[i])
            dd_by.setdefault(first, []).append(dd)
            sharp_by.setdefault(first, []).append(sharp)
    n = len(idx)
    order = sorted(broke.items(), key=lambda kv: kv[1], reverse=True)
    # второй срез: только предупреждающие триггеры плюс уход Score в нижнюю пятую
    held_w, broke_w = 0, {}
    down = 0
    for i in idx:
        first, pos = None, 10 ** 9
        for k in WARN:
            w = np.where(fired[k].iloc[i + 1:i + 64].to_numpy())[0]
            if len(w) and w[0] < pos:
                pos, first = w[0], k
        if first is None:
            held_w += 1
        else:
            broke_w[first] = broke_w.get(first, 0) + 1
        if qtile is not None:
            nxt = qtile.iloc[i + 1:i + 64].dropna()
            if len(nxt) and float(nxt.min()) < 20:
                down += 1
    order_w = sorted(broke_w.items(), key=lambda kv: kv[1], reverse=True)

    def _sharp(v):
        return {"средних_дней": r1(float(np.mean(v)), 1),
                "доля_кварталов_хотя_бы_один": r1(float(np.mean(
                    [x > 0 for x in v]) * 100))}

    rows = [{"исход": "режим удержался", "триггер": None,
             "частота": r1(held_w / n * 100),
             "медиана_квартала": r1(float(np.nanmedian(held_ret)), 2)
             if held_ret else None,
             "медиана_просадки": r1(float(np.median(dd_hold)), 2)
             if dd_hold else None,
             "резкие_дни": _sharp(sharp_hold) if sharp_hold else None}]
    for k, v in order_w:
        rows.append({"исход": "первым сработал %s" % k, "триггер": k,
                     "частота": r1(v / n * 100),
                     "медиана_просадки": r1(float(np.median(dd_by[k])), 2),
                     "резкие_дни": _sharp(sharp_by[k])})
    # второй предупреждающий триггер внутри того же квартала
    second = 0
    for i in idx:
        hits = set()
        for k in WARN:
            if fired[k].iloc[i + 1:i + 64].to_numpy().any():
                hits.add(k)
        if len(hits) >= 2:
            second += 1
    warn_cut = {"описание": "срез только по предупреждающим триггерам "
                            "T1, T4, T5, T6",
                "режим_удержался": r1(held_w / n * 100),
                "строки": rows,
                "второй_триггер_в_том_же_квартале": r1(second / n * 100),
                "ушёл_в_нижнюю_пятую_часть": r1(down / n * 100),
                "определение_просадки": "от максимума внутри квартала",
                "определение_резкого_дня": "закрытие ниже предыдущего более "
                                           "чем на 2 %; цен открытия в рядах "
                                           "нет, разрывы не считаются"}
    return {"опубликовано": True, "пятая_часть": int(cur), "наблюдений": n,
            "срез_предупреждающих": warn_cut,
            "режим_удержался": {"частота": r1(held / n * 100),
                                "медиана_квартала": r1(np.nanmedian(held_ret), 2)
                                if held_ret else None},
            "режим_сломался": {"частота": r1((n - held) / n * 100),
                               "медиана_квартала": r1(np.nanmedian(broke_ret), 2)
                               if broke_ret else None,
                               "первым_срабатывал": [
                                   {"триггер": k, "частота": r1(v / n * 100)}
                                   for k, v in order[:3]]},
            "источник_частоты": "дни истории в той же пятой части Score, "
                                "следующий квартал"}


def similar_states(C, score, SUB, spy, cal, minimum=20):
    """Р.17 — распределение исходов по СХОЖИМ состояниям панели.

    Три ближайших дня прежней редакции статистикой не были и сами это
    признавали. Здесь берётся ближайшая по расстоянию группа дней размером
    не меньше `minimum`, эпизоды разносятся на квартал, и печатается
    распределение, а не отдельные случаи."""
    cur = C.iloc[-1]
    use = C.dropna(how="any")
    if len(use) < 400:
        return {"опубликовано": False, "причина": "недостаточно истории"}
    lim = cal[-1] - pd.Timedelta(days=int(126 * 1.45))
    cand = use[use.index <= lim]
    d = np.sqrt(((cand - cur) ** 2).sum(axis=1)).sort_values()
    idx, taken = [], []
    for dtx in d.index:
        i = cal.get_loc(dtx)
        if any(abs(i - j) < 21 for j in taken):
            continue          # соседние дни одного эпизода — одно наблюдение;
        taken.append(i)       # разделение месяцем, как в проверках на истории
        idx.append(i)
        if len(idx) >= minimum and d.loc[dtx] > 3.0 * d.iloc[0]:
            break             # минимум набирается всегда; дальше — пока
        if len(idx) >= 40:    # состояния остаются похожими, но не более сорока
            break
    if len(idx) < minimum:
        return {"опубликовано": False,
                "причина": "схожих состояний меньше %d (%d)" % (minimum, len(idx))}
    span = float(d.iloc[0]), float(d.loc[cal[idx[-1]]])
    out = {"опубликовано": True, "наблюдений": len(idx),
           "разброс_расстояния": [r1(span[0], 1), r1(span[1], 1)],
           "период": [str(cal[min(idx)].date()), str(cal[max(idx)].date())],
           "горизонты": {}, "база": {}}
    for name, h in (("квартал", 63), ("полгода", 126), ("год", 252)):
        got = [float(spy.iloc[i + h] / spy.iloc[i] - 1) * 100
               for i in idx if i + h < len(cal)]
        # база считается по тому же периоду, что и выборка: у оценки своя
        # история, сравнение с 1993 годом было бы сравнением разных рынков
        base = ((spy.shift(-h) / spy - 1) * 100).reindex(use.index).dropna()
        out["горизонты"][name] = stats(got)
        out["база"][name] = stats(base)
        if out["горизонты"][name]:
            out["горизонты"][name]["минимум"] = r1(min(got), 2)
            out["горизонты"][name]["максимум"] = r1(max(got), 2)
    out["годы"] = sorted({cal[i].year for i in idx})

    # перечень эпизодов: раздел 3 выпуска печатает примеры строками —
    # дата, одно отличие от сегодняшнего дня числом, исход квартала
    eps = []
    for i in idx[:7]:
        dtx = cal[i]
        row = C.loc[dtx]
        diff = (row - cur).dropna()
        if diff.empty:
            continue
        key = diff.abs().idxmax()
        h = 63
        if i + h >= len(cal):
            continue
        path = spy.iloc[i:i + h + 1]
        peak = path.cummax()
        dd = float(((path / peak - 1) * 100).min())
        eps.append({
            "дата": str(dtx.date()),
            "отличие_показатель": key,
            "отличие_тогда": r1(float(row[key]), 1),
            "отличие_сейчас": r1(float(cur[key]), 1),
            "квартал_%": r1(float(spy.iloc[i + h] / spy.iloc[i] - 1) * 100, 1),
            "просадка_квартала_%": r1(dd, 1),
            "просадка_хуже_10": bool(dd <= -10.0)})
    out["эпизоды"] = eps
    return out


# ----------------------------------------------------------------- прогон

def main():
    ap = argparse.ArgumentParser(description="Расчёт выпуска «Здоровье рынка»")
    ap.add_argument("--cutoff", required=True)
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="out")
    ap.add_argument("--cache", action="store_true")
    a = ap.parse_args()
    os.makedirs(a.data, exist_ok=True)
    os.makedirs(a.out, exist_ok=True)
    cutoff = pd.Timestamp(a.cutoff)
    log = Log(out=a.out, code=CODE, cutoff=a.cutoff)
    log.note("%s, срез %s" % (CALC_VERSION, a.cutoff))

    # --- Фаза 0: ряды
    cb = fetch_cboe(a.data, log, a.cache)
    cons = fetch_constituents(a.data, log, a.cache)
    ETF = fetch_tiingo(a.data, log, a.cache)
    tick = [t for t in cons["Symbol"].tolist()]
    basket, fails = fetch_wide(tick, os.path.join(a.data, "basket.pkl"), log,
                               a.cache, "корзина S&P 500")
    prox, pfails = fetch_wide(PROXIES, os.path.join(a.data, "proxies.pkl"), log,
                              a.cache, "межрыночные прокси")
    rates = fetch_rates(a.data, log, a.cache)

    ETF = ETF[ETF.index <= cutoff]
    basket = basket[basket.index <= cutoff]
    prox = prox[prox.index <= cutoff]
    cal = ETF.index
    for t in FUNDS:
        s = ETF[t].dropna()
        log.series(t.lower(), "Tiingo", s.index[-1].date(), len(s))
    log.series("корзина_sp500", "stockanalysis", basket.index[-1].date(),
               len(basket), "бумаг %d, не получено %d"
               % (basket.shape[1], len(fails)))
    log.series("состав_индекса", "открытый CSV datasets", cutoff.date(),
               len(cons), layer="медленный")
    for k, s in cb.items():
        s = s[s.index <= cutoff]
        cb[k] = s
        log.series(k, "CBOE", s.index[-1].date(), len(s))
    for t in PROXIES:
        s = prox[t].dropna()
        log.series(t.lower(), "stockanalysis", s.index[-1].date(), len(s))
    for key, s in rates.items():
        s = s[s.index <= cutoff]
        rates[key] = s
        log.series(key, "посредник сайта → FRED", s.index[-1].date(), len(s),
                   layer="медленный")

    # --- Р.2 ширина
    sectors = dict(zip(cons["Symbol"], cons.get("GICS Sector", pd.Series(dtype=str))))
    added = dict(zip(cons["Symbol"], cons.get("Date added", pd.Series(dtype="datetime64[ns]"))))
    idx = basket.index
    mask = pd.DataFrame(True, index=idx, columns=basket.columns)
    for c in basket.columns:
        da = added.get(c)
        if pd.notna(da):
            mask[c] = idx >= da
    valid = basket.notna() & mask
    a200, a50, nhnl, ncount, ok200, sma200 = breadth(basket, valid)
    a200f, _, _, _, _, _ = breadth(basket, basket.notna())
    off = (a200f - a200).dropna()
    mask_offset = {"среднее_пп": r1(off.mean(), 3),
                   "среднее_по_модулю_пп": r1(off.abs().mean(), 3),
                   "корреляция": r1(pd.concat([a200, a200f], axis=1).dropna()
                                    .corr().iloc[0, 1], 4)}
    disp21 = (basket.pct_change(21).where(valid)).std(axis=1, ddof=0) * 100
    disp21 = disp21.where(valid.sum(axis=1) > 50)

    def al(s):
        return s.reindex(cal).ffill(limit=3)

    R = pd.DataFrame({
        "GV": ETF["IWF"] / ETF["IWD"], "SML": ETF["IWM"] / ETF["SPY"],
        "EQW": ETF["RSP"] / ETF["SPY"], "MTUMr": ETF["MTUM"] / ETF["SPY"],
        "QUALr": ETF["QUAL"] / ETF["SPY"], "USMVr": ETF["USMV"] / ETF["SPY"],
        "VLUEr": ETF["VLUE"] / ETF["SPY"], "HBLV": ETF["SPHB"] / ETF["SPLV"]})

    raw = pd.DataFrame(index=cal)
    raw["above200"] = al(a200); raw["above50"] = al(a50)
    raw["nhnl"] = al(nhnl); raw["disp21"] = al(disp21)
    for k in R.columns:
        raw[k] = R[k]
    raw["COR3M"] = al(cb["cor3m"]); raw["DSPX"] = al(cb["dspx"])
    raw["VIX"] = al(cb["vix"]); raw["VVIX"] = al(cb["vvix"])
    raw["VIX9D"] = al(cb["vix9d"]); raw["VIX3M"] = al(cb["vix3m"])
    raw["КРИВАЯ"] = raw["VIX9D"] / raw["VIX3M"]
    raw["SPY"] = ETF["SPY"]
    raw["VVIX_VIX"] = raw["VVIX"] / raw["VIX"]

    Z = pd.DataFrame({k: causal_z(raw[k]) for k in
                      ["EQW", "HBLV", "USMVr", "COR3M", "DSPX", "GV", "SML",
                       "MTUMr", "above200", "above50", "nhnl", "disp21",
                       "QUALr", "VLUEr", "VVIX_VIX", "КРИВАЯ"]})
    mt63 = raw["MTUMr"].pct_change(63) * 100
    m21 = raw["MTUMr"].pct_change(21) * 100
    mx252 = raw["SPY"].rolling(252, min_periods=252).max()

    # --- Р.5 компоненты
    comp = {
        "above200": causal_pct(raw["above200"]),
        "above50": causal_pct(raw["above50"]),
        "nhnl": causal_pct(raw["nhnl"]),
        "EQW": causal_pct(Z["EQW"]),
        "COR3M": 100 - causal_pct(raw["COR3M"]),
        "disp21": 100 - causal_pct(raw["disp21"]),
        "DSPX": 100 - causal_pct(raw["DSPX"]),
        "HBLV": causal_pct(Z["HBLV"]),
        "USMVr": 100 - causal_pct(Z["USMVr"]),
        "MTUMr": causal_pct(mt63)}
    C = pd.DataFrame(comp)
    W = {"above200": 0.75, "above50": 0.75, "nhnl": 0.75, "EQW": 0.75,
         "COR3M": 2 / 3, "disp21": 2 / 3, "DSPX": 2 / 3,
         "HBLV": 0.5, "USMVr": 0.5, "MTUMr": 1.0}
    BLOCK = {"Ширина": ["above200", "above50", "nhnl", "EQW"],
             "Разброс": ["COR3M", "disp21", "DSPX"],
             "Факторы": ["HBLV", "USMVr", "MTUMr"]}
    wv = pd.Series(W)
    av = C.notna()
    cov = (av * wv).sum(axis=1) / wv.sum() * 100
    score = (C.mul(wv).sum(axis=1, min_count=1)) / (av * wv).sum(axis=1).replace(0, np.nan)
    score = score.where(cov >= 70)
    SUB = pd.DataFrame({b: (C[ks].mul(wv[ks]).sum(axis=1, min_count=1))
                        / (C[ks].notna() * wv[ks]).sum(axis=1).replace(0, np.nan)
                        for b, ks in BLOCK.items()})
    qtile = causal_pct(score)
    q = pd.cut(qtile, [0, 20, 40, 60, 80, 100.001], labels=[1, 2, 3, 4, 5],
               right=False)

    # --- Р.6 контроль дедупликации
    ch63 = C.pct_change(63).replace([np.inf, -np.inf], np.nan)
    win = ch63[ch63.index >= cal[-1] - pd.Timedelta(days=1095)]
    cm = win.corr()
    pairs = []
    for i, k1 in enumerate(C.columns):
        for k2 in list(C.columns)[i + 1:]:
            v = cm.loc[k1, k2]
            if np.isfinite(v) and abs(v) > 0.7:
                pairs.append({"пара": [k1, k2], "ро": r1(v, 2)})

    # --- Р.8 динамика компонентов
    dyn = {}
    for k in list(C.columns) + ["GV", "SML"]:
        s = C[k] if k in C.columns else causal_pct(Z[k])
        dyn[k] = {"сейчас": r1(s.iloc[-1]), "неделю_назад": r1(s.iloc[-6]),
                  "месяц_назад": r1(s.iloc[-22]), "квартал_назад": r1(s.iloc[-64]),
                  "значение": r1(raw[k].iloc[-1], 3) if k in raw else None,
                  "Z252": r1(Z[k].iloc[-1], 2) if k in Z else None,
                  "вес": W.get(k)}

    # --- Р.9 рыночный фон
    fon = {}
    if len(rates) == len(RATES):
        spread = (rates["доходность_10л"] - rates["доходность_2л"]).dropna()
        series_fon = {"доходность_10л": rates["доходность_10л"],
                      "доходность_2л": rates["доходность_2л"],
                      "спред_2_10": spread,
                      "индекс_доллара": rates["индекс_доллара"],
                      "VIX": raw["VIX"].dropna()}
        source = "посредник сайта → FRED"
    else:
        series_fon = {"длинные_облигации_TLT": prox["TLT"].dropna(),
                      "среднесрочные_IEF": prox["IEF"].dropna(),
                      "доллар_UUP": prox["UUP"].dropna(),
                      "VIX": raw["VIX"].dropna()}
        source = "прокси-фонды (посредник не ответил): направление вместо уровня"
    hrupko = []
    for k, s in series_fon.items():
        z = causal_z(s)
        p = causal_pct(s)
        уровень = ("доходность" in k) or ("спред" in k) or (k == "VIX")
        d21 = (s - s.shift(21)) if уровень else (s / s.shift(21) - 1) * 100
        fon[k] = {"значение": r1(s.iloc[-1], 3), "перцентиль": r1(p.iloc[-1]),
                  "Z252": r1(z.iloc[-1], 2), "изменение_за_месяц": r1(d21.iloc[-1], 2)}
        if np.isfinite(z.iloc[-1]) and abs(z.iloc[-1]) > 2:
            hrupko.append({"показатель": k, "Z252": r1(z.iloc[-1], 2)})
        log.value(k if k in RATES or k == "VIX" else k, fon[k]["значение"],
                  source, s.index[-1].date())
    fon_out = {"источник": source, "показатели": fon,
               "расхождения_контура": hrupko,
               "правило_хрупкости": bool(hrupko and (qtile.iloc[-1] or 0) >= 50)}

    # --- Р.10 межрыночные связи
    spyret = raw["SPY"].pct_change()
    inter = {}
    for t in PROXIES:
        r = prox[t].reindex(cal).ffill(limit=3).pct_change()
        c63 = spyret.rolling(63, min_periods=40).corr(r)
        inter[t] = {"корреляция_квартал": r1(c63.iloc[-1], 2),
                    "Z252": r1(causal_z(c63).iloc[-1], 2)}

    # --- Р.11 вердикты соседей
    sosedi = {}
    for code, name in NEIGHBOURS.items():
        try:
            st = amin_run.state_get(code)
        except Exception as e:
            st = None
            log.note("состояние соседа %s не прочитано: %s" % (code, str(e)[:80]))
        row = {"продукт": name, "вердикт": None, "дата": None,
               "строка": "свежего выпуска нет"}
        d = st.get("состояние") if isinstance(st, dict) and "состояние" in st else st
        if isinstance(d, dict) and not d.get("пусто"):
            verd = (d.get("вердикт") or d.get("сводный_режим") or d.get("режим")
                    or d.get("верхний_вывод"))
            if isinstance(verd, dict):
                verd = verd.get("название") or verd.get("вердикт")
            date = (d.get("срез") or d.get("дата_среза") or d.get("дата")
                    or d.get("cutoff"))
            if date:
                age = (cutoff - pd.Timestamp(str(date)[:10])).days
                row["дата"] = str(date)[:10]
                row["возраст_дней"] = age
                if not verd:
                    row["строка"] = "вердикт в состоянии продукта не записан"
                elif age <= 10:
                    row["вердикт"] = str(verd)
                    row["строка"] = str(verd)
                else:
                    row["строка"] = "свежего выпуска нет"
        if code == "credit" and isinstance(d, dict):
            sp = d.get("спреды") or {}
            pc = d.get("перцентили") or {}
            if sp.get("hy") is not None:
                row["величина"] = {
                    "название": "премия за риск высокодоходных облигаций",
                    "значение": sp["hy"], "единица": "п.п.",
                    "место_в_истории": pc.get("hy"),
                    "источник": "выпуск «Кредитный цикл» %s, срез %s"
                                % (d.get("выпуск", "—"), row.get("дата", "—"))}
        sosedi[code] = row

    # --- Р.3 секторальный рентген
    xray = sector_xray(basket, valid, ok200, sma200, sectors, cal)

    # --- Р.12 проверки на истории
    ev, active, fired = event_studies(raw, Z, raw["SPY"], cal, m21, mx252)

    # --- Р.13 факторное лидерство
    lead = []
    for t in [x for x in FUNDS if x != "SPY"]:
        rel = ETF[t] / ETF["SPY"]
        r5 = (rel.iloc[-1] / rel.iloc[-6] - 1) * 100
        r21 = (rel.iloc[-1] / rel.iloc[-22] - 1) * 100
        r63 = (rel.iloc[-1] / rel.iloc[-64] - 1) * 100
        p63 = causal_pct(rel.pct_change(63) * 100).iloc[-1]
        # место УРОВНЯ отношения за десять лет: во что рынок уже оценил отрыв
        p_lvl = causal_pct(rel).iloc[-1]
        if p_lvl is None or not np.isfinite(p_lvl):
            цена = None
        elif p_lvl > 90:
            цена = "дорого"
        elif p_lvl < 10:
            цена = "дёшево"
        else:
            цена = "обычно"
        lead.append({"фонд": t, "неделя": r1(r5, 2), "месяц": r1(r21, 2),
                     "квартал": r1(r63, 2), "перцентиль_квартала": r1(p63),
                     "перцентиль_уровня": r1(p_lvl),
                     "цена_лидерства": цена,
                     "Z252_отношения": r1(causal_z(rel).iloc[-1], 2),
                     "ротация_устойчива": bool(np.sign(r21) == np.sign(r63))})
    lead.sort(key=lambda x: x["квартал"] or -99, reverse=True)

    # --- Р.15, Р.16, Р.17
    regime = risk_regime(raw["SPY"], score, q, cal)
    forks = scenario_forks(q, fired, raw["SPY"], cal, qtile)
    ana = similar_states(C, score, SUB, raw["SPY"], cal)

    spy200 = raw["SPY"].rolling(200, min_periods=200).mean()
    near_pct = float(raw["SPY"].iloc[-1] / mx252.iloc[-1] * 100)
    thresholds = {
        "T1": {"порог": "доля выше 200-дневной ниже 20 %",
               "текущее": r1(raw["above200"].iloc[-1])},
        "T2": {"порог": "индекс не ниже 99 % годового максимума и доля выше "
                        "200-дневной ниже 60 %",
               "текущее": "%s %% от максимума, доля %s %%"
                          % (r1(near_pct), r1(raw["above200"].iloc[-1]))},
        "T3": {"порог": "Z252 связи между бумагами выше +2",
               "текущее": r1(Z["COR3M"].iloc[-1], 2)},
        "T4": {"порог": "месячное изменение импульса к индексу ниже −4 %",
               "текущее": r1(m21.iloc[-1], 2)},
        "T5": {"порог": "Z252 высокой беты к низкой волатильности ниже −2",
               "текущее": r1(Z["HBLV"].iloc[-1], 2)},
        "T6": {"порог": "Z252 равного веса к капвзвешенному ниже −2 у максимума",
               "текущее": "%s при %s %% от максимума"
                          % (r1(Z["EQW"].iloc[-1], 2), r1(near_pct))},
        "T7": {"порог": "Z252 связи между бумагами ниже −2",
               "текущее": r1(Z["COR3M"].iloc[-1], 2)},
        "T8": {"порог": "Z252 разброса, заложенного в опционах, выше +2",
               "текущее": r1(Z["DSPX"].iloc[-1], 2)},
    }
    calc = {
        "версия_расчёта": CALC_VERSION,
        "срез": a.cutoff,
        "продукт": CODE,
        "покрытие": r1(cov.iloc[-1]),
        "score": r1(score.iloc[-1]),
        "место_score_в_истории": r1(qtile.iloc[-1]),
        "пятая_часть": None if pd.isna(q.iloc[-1]) else int(q.iloc[-1]),
        "score_срезы": {"неделю_назад": r1(score.iloc[-6]),
                        "месяц_назад": r1(score.iloc[-22]),
                        "квартал_назад": r1(score.iloc[-64])},
        "блоки": {k: r1(SUB[k].iloc[-1]) for k in SUB.columns},
        "компоненты": dyn,
        "индекс": {"SPY": r1(raw["SPY"].iloc[-1], 2),
                   "к_200дн_средней_%": r1((raw["SPY"].iloc[-1] / spy200.iloc[-1] - 1) * 100, 2),
                   "за_неделю_%": r1((raw["SPY"].iloc[-1] / raw["SPY"].iloc[-6] - 1) * 100, 2)},
        "ширина_корзина": {"бумаг_в_расчёте": int(ncount.iloc[-1]),
                           "смещение_маски": mask_offset,
                           "последняя_дата_корзины": str(basket.index[-1].date()),
                           "не_получено_тикеров": len(fails)},
        "кривая_волатильности": {
            "vix9d": r1(raw["VIX9D"].iloc[-1], 2),
            "vix3m": r1(raw["VIX3M"].iloc[-1], 2),
            "отношение": r1(raw["КРИВАЯ"].iloc[-1], 3),
            "перцентиль": r1(causal_pct(raw["КРИВАЯ"]).iloc[-1]),
            "Z252": r1(Z["КРИВАЯ"].iloc[-1], 2),
            "форма": ("ближний срок дороже дальнего"
                      if raw["КРИВАЯ"].iloc[-1] > 1
                      else "ближний срок дешевле дальнего"),
            "неделю_назад": r1(raw["КРИВАЯ"].iloc[-6], 3)},
        "цена_страховки_VVIX_VIX": {"значение": r1(raw["VVIX_VIX"].iloc[-1], 2),
                                    "Z252": r1(Z["VVIX_VIX"].iloc[-1], 2),
                                    "перцентиль": r1(causal_pct(raw["VVIX_VIX"]).iloc[-1])},
        "секторальный_рентген": xray,
        "рыночный_фон": fon_out,
        "межрыночные_связи": inter,
        "соседние_продукты": sosedi,
        "проверки_на_истории": ev,
        "активные_триггеры": active,
        "пороги_триггеров": thresholds,
        "индекс_к_годовому_максимуму_%": r1(near_pct, 1),
        "факторное_лидерство": lead,
        "режим_риска": regime,
        "сценарные_развилки": forks,
        "схожие_состояния": ana,
        "флаги_дедупликации": pairs,
        "веса": W,
    }
    json.dump(calc, open(os.path.join(a.out, "calc.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1, default=str)

    # ряды для графиков
    ser = {"score": score.dropna(), "above200": raw["above200"].dropna(),
           "EQW": raw["EQW"].dropna(), "HBLV": raw["HBLV"].dropna(),
           "COR3M": raw["COR3M"].dropna(), "DSPX": raw["DSPX"].dropna(),
           "q": q}
    for k in ("EQW", "HBLV"):
        s = raw[k]
        m = s.rolling(252, min_periods=252).mean().shift(1)
        sd = s.rolling(252, min_periods=252).std(ddof=0).shift(1)
        ser["band_" + k] = {"lo": (m - 2 * sd), "hi": (m + 2 * sd)}
    pickle.dump(ser, open(os.path.join(a.out, "series.pkl"), "wb"))

    # журнал расчётных величин
    log.value("ширина_выше_200", calc["компоненты"]["above200"]["значение"],
              "расчёт корзины", cal[-1].date(), "%")
    log.value("ширина_выше_50", calc["компоненты"]["above50"]["значение"],
              "расчёт корзины", cal[-1].date(), "%")
    log.value("новые_максимумы_минимумы", calc["компоненты"]["nhnl"]["значение"],
              "расчёт корзины", cal[-1].date(), "%")
    log.value("разброс_21", calc["компоненты"]["disp21"]["значение"],
              "расчёт корзины", cal[-1].date(), "%")
    log.value("отношения_фондов", calc["компоненты"]["EQW"]["значение"],
              "расчёт по фондам", cal[-1].date())
    log.value("vvix_к_vix", calc["цена_страховки_VVIX_VIX"]["значение"],
              "расчёт CBOE", cal[-1].date())
    log.value("кривая_волатильности", calc["кривая_волатильности"]["отношение"],
              "расчёт CBOE", cal[-1].date())
    log.value("score", calc["score"], "расчёт", cal[-1].date())
    log.value("покрытие", calc["покрытие"], "расчёт", cal[-1].date(), "%")
    log.value("сценарные_развилки", forks.get("режим_удержался", {}).get("частота")
              if forks.get("опубликовано") else "не публикуются",
              "расчёт", cal[-1].date())
    log.value("схожие_состояния",
              ana.get("наблюдений") if ana.get("опубликовано") else "нет",
              "расчёт", cal[-1].date())

    print("Расчёт готов: %s" % CALC_VERSION)
    print("срез %s · Score %s · покрытие %s %% · пятая часть %s"
          % (a.cutoff, calc["score"], calc["покрытие"], calc["пятая_часть"]))
    print("ширина выше 200-дн: %s %% · активные триггеры: %s"
          % (calc["компоненты"]["above200"]["значение"], active or "нет"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
