#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""wsm_charts.py — три графика выпуска «Настроения рынка» из out/extra.json.

  01-thermo    термометр настроений за три года с границами краёв
  02-outcomes  что рынок делал после таких же настроений
  03-appetite  спрос на рискованные бумаги против защитных
"""
import datetime as dt, json, os, sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets"))
import charts as C

E = json.load(open("out/extra.json", encoding="utf-8"))
os.makedirs("png", exist_ok=True)
дата = lambda s: dt.date(int(s[:4]), int(s[5:7]), int(s[8:10]))

t = E["chart_data"]["термометр_3г"]
C.band_series("png/01-thermo.png", [дата(d) for d in t["даты"]], t["значения"],
              "Термометр настроений, из 100", ylabel="из 100", recent=13,
              zones=[(0, 20, "green"), (80, 100, "red")],
              threshold=(80, "край эйфории"))

o = E["исходы"]["горизонты"]
C.distribution_bars("png/02-outcomes.png",
                    ["Через месяц", "Через квартал"],
                    [o["21д"]["медиана"], o["63д"]["медиана"]],
                    "Что рынок делал после таких же настроений, %",
                    horizontal=True)

b = E["chart_data"]["бета_к_защите_3г"]
if b:
    C.band_series("png/03-appetite.png", [дата(d) for d in b["даты"]], b["значения"],
                  "Цена рискованных бумаг к цене защитных", ylabel="отношение", recent=13)

print("PNG:", sorted(os.listdir("png")))
