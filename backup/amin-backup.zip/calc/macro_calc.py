#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""macro_calc.py — расчётный блок Р промпта «Макрорежим США» (v4.23).

Ловушки, зашитые в код (не удалять):
  * FRED отдаёт 503 на браузерный UA — ходить как curl/8.5.0.
  * Yahoo: длинная история только через period1=-1893456000; хвост длинного
    запроса обрывается — склеивать со вторым запросом range=6mo.
  * Секторный индекс энергетики — ^SP500-1010 (^SP500-10 = 404).
  * Состав S&P 500 с Wikipedia: искать id="constituents", резать <tr[^>]*>.
  * TGA из DTS: фильтровать 'Closing Balance' в account_type.
  * HY/IG OAS у FRED только 3 года → вся история по BAA10Y.
  * IORB начинается 29.07.2021 — сшивать с IOER.
  * Проверки на истории и условные доходности: guard по датам, иначе
    старые эпизоды получают фальшивую доходность от первой даты ряда.
  * Базовая частота коррекции — только со стартом не глубже −5 % от максимума.
"""

import argparse, io, json, os, re, sys, time
import datetime as dt
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pandas as pd
import urllib.request, urllib.error, urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import amin_run

UA = "curl/8.5.0"
BUA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36")
DATA = "data"; OUT = "out"
L = None


def fetch(url, ua=UA, headers=None, tries=3, pause=1.0, timeout=60):
    h = {"User-Agent": ua, "Accept": "*/*"}
    if headers:
        h.update(headers)
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=h)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:
            last = e
            time.sleep(pause * (i + 1))
    raise last


def cache_path(name):
    os.makedirs(DATA, exist_ok=True)
    return os.path.join(DATA, name)


# ─────────────────────────── FRED ───────────────────────────
FRED = {
    "SP500": "SP500", "NDX": "NASDAQ100", "RUT": "RU2000PR",
    "VIX": "VIXCLS", "VIX3M": "VXVCLS", "VXN": "VXNCLS",
    "UST3M": "DGS3MO", "UST2Y": "DGS2", "UST10Y": "DGS10", "UST30Y": "DGS30",
    "S2s10s": "T10Y2Y", "S3m10y": "T10Y3M", "REAL10Y": "DFII10",
    "BE5Y": "T5YIE", "BE10Y": "T10YIE",
    "HYOAS": "BAMLH0A0HYM2", "IGOAS": "BAMLC0A0CM", "BAA10Y": "BAA10Y",
    "DXYB": "DTWEXBGS", "EURUSD": "DEXUSEU", "USDJPY": "DEXJPUS", "USDCNY": "DEXCHUS",
    "WTI": "DCOILWTICO", "BRENT": "DCOILBRENTEU",
    "CPI": "CPIAUCSL", "CORECPI": "CPILFESL", "COREPCE": "PCEPILFE", "PPI": "PPIFIS",
    "NFP": "PAYEMS", "UNRATE": "UNRATE", "CIVPART": "CIVPART", "CLAIMS": "ICSA",
    "AHE": "CES0500000003", "JOLTS": "JTSJOL", "SAHM": "SAHMREALTIME",
    "GDP": "GDPC1", "INDPRO": "INDPRO", "RETAIL": "RSAFS",
    "HOUST": "HOUST", "PERMIT": "PERMIT", "MORT30": "MORTGAGE30US",
    "UMCSENT": "UMCSENT", "MICH": "MICH",
    "FFR": "DFF", "IORB": "IORB", "IOER": "IOER",
    "WALCL": "WALCL", "WRESBAL": "WRESBAL", "RRP": "RRPONTSYD",
    "NFCI": "NFCI", "TGA_FRED": "WDTGAL",
    "CCDELINQ": "DRCCLACBS", "AUTODELINQ": "DRSFRMACBS",
    "NONRES": "TLNRESCONS", "NEWORDERS": "AMTMNO",
    # ряды задания издателя 04.09.2026 (промпт v6.2)
    "GDPNOW": "GDPNOW", "CFNAI": "CFNAI", "CFNAI3": "CFNAIMA3", "ANFCI": "ANFCI",
    "REALINC": "W875RX1", "REALSALES": "CMRMTSPL",
    "SLOOS_L": "DRTSCILM", "SLOOS_S": "DRTSCIS",
    "WGT": "FRBATLWGT12MMUMHGO", "WGT_SW": "FRBATLWGT12MMUMHWGJSW",
    "WGT_ST": "FRBATLWGT12MMUMHWGJST",
    "QUITS": "JTSQUR", "CCLAIMS": "CCSA", "TEMPHELP": "TEMPHELPS",
    "TRIMPCE": "PCETRIM1M158SFRBDAL", "INVENT": "AMTMTI", "TRUCK": "TRUCKD11",
    "ALLDELINQ": "DRALACBN",
}


def fred(series):
    f = cache_path("fred_%s.csv" % series)
    if not os.path.exists(f):
        url = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=%s" % series
        try:
            b = fetch(url, headers={"Accept": "text/plain"})
        except Exception as e:
            L.get("FRED", url, ok=False, note=str(e)[:120]); return None
        open(f, "wb").write(b)
        time.sleep(1.2)
    try:
        d = pd.read_csv(f)
    except Exception:
        return None
    d.columns = ["date", "v"]
    d["date"] = pd.to_datetime(d["date"])
    d["v"] = pd.to_numeric(d["v"], errors="coerce")
    s = d.dropna().set_index("date")["v"]
    return s if len(s) else None


# ─────────────────────────── Yahoo ───────────────────────────
def yahoo(symbol, long_hist=True):
    key = symbol.replace("^", "i_").replace("=", "_")
    f = cache_path("yh_%s.csv" % key)
    if os.path.exists(f):
        d = pd.read_csv(f, parse_dates=["date"])
        return d.set_index("date")["v"].dropna()
    sym = urllib.parse.quote(symbol, safe="^")
    base = "https://query1.finance.yahoo.com/v8/finance/chart/%s?" % sym
    parts = []
    urls = []
    if long_hist:
        urls.append(base + "period1=-1893456000&period2=%d&interval=1d" % int(time.time()))
    urls.append(base + "range=6mo&interval=1d")
    meta_px = None
    for u in urls:
        try:
            j = json.loads(fetch(u, ua=BUA))
            r = j["chart"]["result"][0]
            meta_px = r.get("meta", {}).get("regularMarketPrice", meta_px)
            ts = r["timestamp"]; cl = r["indicators"]["quote"][0]["close"]
            s = pd.Series(cl, index=pd.to_datetime(ts, unit="s").normalize())
            parts.append(s.dropna())
        except Exception as e:
            L.get("Yahoo", u, ok=False, note=str(e)[:100])
    if not parts:
        return None
    s = pd.concat(parts)
    s = s[~s.index.duplicated(keep="last")].sort_index()
    s.attrs["meta"] = meta_px
    # Обрезанный ответ в кэш не пишется. Yahoo под нагрузкой отдаёт вместо длинной
    # истории шестимесячный хвост или одну точку; сохранённый под именем длинного
    # ряда, он молча ломает следующий прогон — секторный мост 12.08.2026 считался
    # по пяти секторам из одиннадцати, потому что шесть рядов лежали обрезанными.
    if long_hist and len(s) < 500:
        L.get("Yahoo", symbol, ok=True,
              note="ряд короче 500 точек (%d) — в кэш не записан, следующий "
                   "прогон повторит запрос" % len(s))
        return s
    pd.DataFrame({"date": s.index, "v": s.values}).to_csv(f, index=False)
    return s


# ─────────────────────────── CBOE ───────────────────────────
def cboe(sym, col):
    f = cache_path("cboe_%s.csv" % sym)
    if not os.path.exists(f):
        url = ("https://cdn.cboe.com/api/global/us_indices/daily_prices/%s_History.csv" % sym)
        try:
            b = fetch(url, ua=BUA)
        except Exception as e:
            L.get("CBOE", url, ok=False, note=str(e)[:100]); return None
        open(f, "wb").write(b)
    try:
        d = pd.read_csv(f)
    except Exception:
        return None
    dcol = d.columns[0]
    d[dcol] = pd.to_datetime(d[dcol], errors="coerce")
    if col >= len(d.columns):
        return None
    s = pd.Series(pd.to_numeric(d.iloc[:, col], errors="coerce").values, index=d[dcol])
    return s.dropna().sort_index()


def put_call(cut):
    d = cut
    for _ in range(6):
        url = ("https://cdn.cboe.com/data/us/options/market_statistics/daily/"
               "%s_daily_options" % d.strftime("%Y-%m-%d"))
        try:
            j = json.loads(fetch(url, ua=BUA, tries=1))
            r = j.get("data", j)
            L.get("CBOE put/call", url, ok=True)
            return r, d
        except Exception:
            d -= dt.timedelta(days=1)
    L.get("CBOE put/call", "cdn.cboe.com daily_options", ok=False)
    return None, None


# ─────────────────────────── Treasury / NY Fed / CNN ───────────────────────────
def tga_dts():
    url = ("https://api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/"
           "accounting/dts/operating_cash_balance?fields=record_date,account_type,"
           "open_today_bal&filter=record_date:gte:2015-01-01&sort=-record_date"
           "&page%5Bsize%5D=10000")
    try:
        j = json.loads(fetch(url))
    except Exception as e:
        L.get("Treasury DTS", url, ok=False, note=str(e)[:100]); return None
    rows = [r for r in j.get("data", []) if "Closing Balance" in (r.get("account_type") or "")]
    if not rows:
        rows = [r for r in j.get("data", []) if "TGA" in (r.get("account_type") or "")]
    if not rows:
        return None
    s = pd.Series({pd.Timestamp(r["record_date"]): float(r["open_today_bal"]) / 1000.0
                   for r in rows}).sort_index()
    L.get("Treasury DTS", url, ok=True)
    return s


def cnn_fg():
    url = "https://production.dataviz.cnn.io/index/fearandgreed/graphdata"
    try:
        j = json.loads(fetch(url, ua=BUA, headers={
            "Accept": "application/json", "Accept-Language": "en-US,en;q=0.9",
            "Origin": "https://edition.cnn.com", "Referer": "https://edition.cnn.com/"}))
        L.get("CNN Fear&Greed", url, ok=True)
        return j
    except Exception as e:
        L.get("CNN Fear&Greed", url, ok=False, note=str(e)[:100])
        return None


def nowcast():
    url = ("https://www.newyorkfed.org/medialibrary/Research/Interactives/Data/"
           "NowCast/Downloads/New-York-Fed-Staff-Nowcast_download_data.xlsx")
    try:
        b = fetch(url, ua=BUA)
        open(cache_path("nowcast.xlsx"), "wb").write(b)
        x = pd.read_excel(io.BytesIO(b), sheet_name="Forecasts By Quarter", header=5)
        L.get("NY Fed Nowcast", url, ok=True)
        return x
    except Exception as e:
        L.get("NY Fed Nowcast", url, ok=False, note=str(e)[:120])
        return None


# ─────────────────────────── состав индекса и широта ───────────────────────────
def constituents():
    f = cache_path("spx.json")
    if os.path.exists(f):
        return json.load(open(f, encoding="utf-8"))
    url = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
    try:
        html = fetch(url, ua=BUA).decode("utf-8", "ignore")
    except Exception as e:
        L.get("Wikipedia S&P 500", url, ok=False, note=str(e)[:100]); return []
    i = html.find('id="constituents"')
    body = html[i:] if i > 0 else html
    rows = re.split(r"<tr[^>]*>", body)[1:600]
    out = []
    for r in rows:
        cells = re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", r, re.S)
        if len(cells) < 4:
            continue
        m = re.search(r">([A-Z\.\-]{1,6})<", cells[0])
        if not m:
            continue
        sec = re.sub(r"<[^>]+>", "", cells[2]).strip()
        out.append({"t": m.group(1).replace(".", "-"), "sector": sec})
        if len(out) >= 505:
            break
    json.dump(out, open(f, "w", encoding="utf-8"), ensure_ascii=False)
    L.get("Wikipedia S&P 500", url, ok=True, note="бумаг: %d" % len(out))
    return out


def px_one(t):
    try:
        u = ("https://query1.finance.yahoo.com/v8/finance/chart/%s?"
             "period1=1262304000&period2=%d&interval=1d" % (t, int(time.time())))
        j = json.loads(fetch(u, ua=BUA, tries=2, pause=0.4, timeout=40))
        r = j["chart"]["result"][0]
        s = pd.Series(r["indicators"]["quote"][0]["close"],
                      index=pd.to_datetime(r["timestamp"], unit="s").normalize()).dropna()
        return t, s
    except Exception:
        return t, None


def breadth(names):
    f = cache_path("breadth.csv")
    if os.path.exists(f):
        return pd.read_csv(f, parse_dates=["date"]).set_index("date")
    with ThreadPoolExecutor(16) as ex:
        res = list(ex.map(px_one, [n["t"] for n in names]))
    px = {t: s for t, s in res if s is not None and len(s) > 250}
    L.get("Yahoo цены бумаг индекса", "query1 chart API", ok=True,
          note="получено %d из %d" % (len(px), len(names)))
    P = pd.DataFrame(px).sort_index()
    P = P[P.index >= "2010-01-01"]
    # Торговый календарь панели: строка с котировками меньше чем у 80 % бумаг —
    # чужой календарь (иностранные листинги, внеплановые сессии), а не торговый
    # день индекса. Такая строка ставит пропуски почти всей панели, окно rolling
    # ловит пропуск, скользящая средняя обращается в NaN — и бумага молча
    # уходит в «ниже средней». Прогон 12.08.2026: широта 44,7 % при реальных 70,8 %.
    cover = P.notna().sum(axis=1)
    P = P[cover >= 0.8 * P.shape[1]]
    P = P.ffill(limit=3)          # разрыв в 1–3 дня закрывается последней ценой
    ma200 = P.rolling(200, min_periods=200).mean()
    # маска годных наблюдений: бумага участвует и в числителе, и в знаменателе
    # только там, где есть и цена, и средняя. Без маски бумага без средней
    # попадает в знаменатель, но никогда — в числитель.
    ok200 = P.notna() & ma200.notna()
    above = ((P > ma200) & ok200).sum(axis=1) / ok200.sum(axis=1) * 100.0
    up = (P.diff() > 0).sum(axis=1); dn = (P.diff() < 0).sum(axis=1)
    ad = (up - dn).cumsum()
    hi = P.rolling(252, min_periods=252).max(); lo = P.rolling(252, min_periods=252).min()
    ok252 = P.notna() & hi.notna()
    nh = ((P >= hi) & ok252).sum(axis=1); nl = ((P <= lo) & ok252).sum(axis=1)
    net = (up - dn).astype(float)
    # осциллятор Макклеллана: разность экспоненциальных средних чистого прироста
    # растущих над падающими (19 и 39 дней) по составу индекса
    mcc = net.ewm(span=19, adjust=False).mean() - net.ewm(span=39, adjust=False).mean()
    d = pd.DataFrame({"above200": above, "adline": ad, "nh_nl": nh - nl,
                      "nh": nh, "nl": nl, "mcclellan": mcc}).dropna()
    d.index.name = "date"
    # неполная панель в кэш не пишется: следующий прогон возьмёт её как готовую
    # и повторит заниженную широту, не сходив за недостающими бумагами
    if len(px) >= 0.9 * len(names):
        d.to_csv(f)
    else:
        L.get("Yahoo цены бумаг индекса", "кэш панели широты", ok=False,
              note="панель неполная (%d из %d), в кэш не записана" % (len(px), len(names)))
    return d


# ─────────────────────────── Р.2 нормализация ───────────────────────────
def zscore(s, win):
    s = s.dropna()
    if len(s) < max(30, win // 3):
        return None
    m = s.rolling(win, min_periods=max(20, win // 4)).mean()
    sd = s.rolling(win, min_periods=max(20, win // 4)).std()
    z = (s - m) / sd
    return z.dropna()


def pctile(s, years=10):
    s = s.dropna()
    if len(s) < 30:
        return None, None
    last = s.index[-1]
    win = s[s.index >= last - pd.Timedelta(days=365 * years)]
    if len(win) < 30:
        win = s
    v = float(s.iloc[-1])
    p = float((win.values <= v).mean() * 100)
    yrs = round((win.index[-1] - win.index[0]).days / 365.25, 1)
    return p, yrs


def norm_row(key, s, win, unit="", freq="д"):
    if s is None or not len(s.dropna()):
        return None
    s = s.dropna()
    z = zscore(s, win)
    p, yrs = pctile(s)
    z12 = None
    if z is not None and len(z):
        cut12 = z.index[-1] - pd.Timedelta(days=365)
        w = z[z.index >= cut12]
        z12 = [round(float(w.min()), 2), round(float(w.max()), 2)] if len(w) else None
    return {"показатель": key, "значение": round(float(s.iloc[-1]), 4),
            "дата": str(s.index[-1].date()),
            "z": round(float(z.iloc[-1]), 2) if z is not None and len(z) else None,
            "z12": z12, "перцентиль": round(p, 1) if p is not None else None,
            "окно_лет": yrs, "частота": freq, "единица": unit, "точек": int(len(s))}


# ─────────────────────────── Р.4 классификатор ───────────────────────────
def classifier(m):
    """m — словарь месячных рядов. Возвращает ленту режимов (месячный индекс)."""
    idx = pd.period_range("1990-01", pd.Timestamp.today().to_period("M"), freq="M")
    nfp = m["NFP"].resample("ME").last()
    nfp3 = nfp.diff().rolling(3).mean() * 1000
    un = m["UNRATE"].resample("ME").last()
    un12min = un.rolling(12, min_periods=6).min()
    indpro = m["INDPRO"].resample("ME").last()
    ip3 = (indpro / indpro.shift(3)) ** 4 - 1
    cpe = m["COREPCE"].resample("ME").last()
    cpe_yoy = cpe.pct_change(12) * 100
    cc = m["CORECPI"].resample("ME").last()
    cc3 = ((cc / cc.shift(3)) ** 4 - 1) * 100
    cc12 = cc.pct_change(12) * 100
    rows = []
    for p in idx:
        ts = p.to_timestamp("M")
        def at(s):
            w = s[s.index <= ts]
            return float(w.iloc[-1]) if len(w) else np.nan
        g = 0
        ip = at(ip3)
        if not np.isnan(ip) and ip >= 0:
            g += 1
        n3 = at(nfp3)
        if not np.isnan(n3) and n3 >= 100000:
            g += 1
        u, um = at(un), at(un12min)
        if not np.isnan(u) and not np.isnan(um) and u <= um + 0.3:
            g += 1
        strong = g >= 2
        i = 0
        cy = at(cpe_yoy)
        if not np.isnan(cy) and cy > 2.5:
            i += 1
        a, b = at(cc3), at(cc12)
        if not np.isnan(a) and not np.isnan(b) and a > b:
            i += 1
        press = i >= 1
        if strong and not press:
            r = "Goldilocks"
        elif strong and press:
            r = "Рефляция"
        elif (not strong) and press:
            r = "Стагфляционный риск"
        else:
            r = "Дефляционное замедление"
        if np.isnan(cy) and np.isnan(a):
            r = None
        rows.append((ts, r))
    lent = pd.Series({t: r for t, r in rows if r}).sort_index()
    return lent


def transitions(lent, h=1):
    regs = sorted(set(lent.values))
    cnt = {a: {b: 0 for b in regs} for a in regs}
    v = list(lent.values)
    for i in range(len(v) - h):
        cnt[v[i]][v[i + h]] += 1
    out = {}
    for a in regs:
        tot = sum(cnt[a].values())
        out[a] = {b: (round(cnt[a][b] / tot * 100, 1) if tot else None) for b in regs}
        out[a]["n"] = tot
    return out


def fwd_by_regime(lent, series, wins=(21, 63)):
    """Условные доходности вперёд по режимам. Guard по датам обязателен."""
    out = {}
    for name, s in series.items():
        s = s.dropna()
        if len(s) < 300:
            continue
        out[name] = {}
        for reg in sorted(set(lent.values)):
            dates = [t for t, r in lent.items() if r == reg]
            for w in wins:
                res = []
                for d in dates:
                    i = s.index.searchsorted(d)
                    if i >= len(s) or i + w >= len(s):
                        continue
                    if abs((s.index[i] - d).days) > 10:
                        continue
                    a, b = float(s.iloc[i]), float(s.iloc[i + w])
                    if a == 0 or np.isnan(a) or np.isnan(b):
                        continue
                    res.append((b / a - 1) * 100 if name not in ("UST10Y", "BAA10Y")
                               else (b - a) * 100)
                k = "%s_%dд" % (reg, w)
                if len(res) >= 5:
                    out[name][k] = {"n": len(res), "p25": round(float(np.percentile(res, 25)), 2),
                                    "p50": round(float(np.median(res)), 2),
                                    "p75": round(float(np.percentile(res, 75)), 2)}
                elif res:
                    out[name][k] = {"n": len(res), "эпизоды": [round(x, 2) for x in res]}
    return out


# ─────────────────────────── Р.3 проверки на истории ───────────────────────────
def episodes(s, thr, above=True, gap_days=21):
    s = s.dropna()
    hit = (s > thr) if above else (s < thr)
    eps, last = [], None
    for d, h in hit.items():
        if not h:
            continue
        if last is None or (d - last).days > gap_days * 1.45:
            eps.append(d)
        last = d
    return eps


def event_study(eps, series, wins=(5, 21, 63), skip_tail=63):
    out = {}
    for name, s in series.items():
        s = s.dropna()
        if len(s) < 300:
            continue
        cutoff_i = len(s) - skip_tail
        for w in wins:
            res = []
            for d in eps:
                i = s.index.searchsorted(d)
                if i >= cutoff_i or i + w >= len(s):
                    continue
                if abs((s.index[i] - d).days) > 10:
                    continue
                a, b = float(s.iloc[i]), float(s.iloc[i + w])
                if a == 0 or np.isnan(a) or np.isnan(b):
                    continue
                res.append((b / a - 1) * 100 if name not in ("UST10Y", "BAA10Y")
                           else (b - a) * 100)
            k = "%s_%dд" % (name, w)
            if len(res) >= 5:
                out[k] = {"n": len(res), "p25": round(float(np.percentile(res, 25)), 2),
                          "p50": round(float(np.median(res)), 2),
                          "p75": round(float(np.percentile(res, 75)), 2),
                          "доля_вниз": round(float(np.mean([x < 0 for x in res]) * 100), 1)}
            elif res:
                out[k] = {"n": len(res), "эпизоды": [round(x, 2) for x in res]}
            else:
                out[k] = {"n": 0}
    return out


# ─────────────────────────── Р.5 модели ───────────────────────────
def logit_models(D):
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import roc_auc_score
    out = {}
    for name, y in (("коррекция", D["y_corr"]), ("кредитная_премия", D["y_credit"])):
        X = D["X"].copy()
        d = pd.concat([X, y.rename("y")], axis=1).dropna()
        if len(d) < 60:
            out[name] = {"статус": "мало наблюдений", "n": len(d)}
            continue
        Xv, yv = d[X.columns].values, d["y"].values.astype(int)
        n_ev = int(yv.sum())
        k = int(len(d) * 0.7)
        base = float(yv.mean() * 100)
        try:
            mdl = LogisticRegression(max_iter=3000, C=1.0)
            mu, sd = Xv[:k].mean(0), Xv[:k].std(0) + 1e-9
            mdl.fit((Xv[:k] - mu) / sd, yv[:k])
            if len(set(yv[k:])) > 1:
                auc = float(roc_auc_score(yv[k:], mdl.predict_proba((Xv[k:] - mu) / sd)[:, 1]))
            else:
                auc = float("nan")
            full = LogisticRegression(max_iter=3000, C=1.0)
            mu2, sd2 = Xv.mean(0), Xv.std(0) + 1e-9
            full.fit((Xv - mu2) / sd2, yv)
            p_now = float(full.predict_proba(((Xv[-1:] - mu2) / sd2))[0, 1] * 100)
            coefs = {c: round(float(v), 3) for c, v in zip(X.columns, full.coef_[0])}
        except Exception as e:
            out[name] = {"статус": "ошибка расчёта: %s" % str(e)[:80]}
            continue
        passed = (not np.isnan(auc)) and auc >= 0.60 and n_ev >= 15
        out[name] = {"n": int(len(d)), "событий": n_ev, "базовая_частота": round(base, 1),
                     "auc": None if np.isnan(auc) else round(auc, 3),
                     "вероятность": round(p_now, 1), "коэффициенты": coefs,
                     "порог_пройден": bool(passed)}
    return out


# ─────────────────────────── Р.6 Monte-Carlo ───────────────────────────
def bootstrap(ret, n=10000, block=21, horizon=63, seed=7):
    ret = np.asarray(pd.Series(ret).dropna().values, dtype=float)
    if len(ret) < block * 3:
        return None
    rng = np.random.default_rng(seed)
    nb = int(np.ceil(horizon / block))
    starts = rng.integers(0, len(ret) - block, size=(n, nb))
    idx = (starts[:, :, None] + np.arange(block)[None, None, :]).reshape(n, -1)[:, :horizon]
    paths = np.prod(1 + ret[idx], axis=1) - 1
    q = np.percentile(paths * 100, [5, 25, 50, 75, 95])
    return {"p5": round(float(q[0]), 2), "p25": round(float(q[1]), 2),
            "p50": round(float(q[2]), 2), "p75": round(float(q[3]), 2),
            "p95": round(float(q[4]), 2), "прогонов": n, "блок": block,
            "выборка_дней": int(len(ret)), "горизонт": horizon}


# ─────────────────────────── main ───────────────────────────
def main():
    global L, DATA, OUT
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutoff", required=True)
    ap.add_argument("--data", default="data"); ap.add_argument("--out", default="out")
    a = ap.parse_args()
    DATA, OUT = a.data, a.out
    os.makedirs(OUT, exist_ok=True)
    cut = dt.datetime.strptime(a.cutoff, "%Y-%m-%d").date()
    L = amin_run.Log(OUT, code="macro", cutoff=a.cutoff)
    globals()["L"] = L

    R = {}          # ряды
    C = {"срез": a.cutoff}
    ch = {}

    # ── Фаза 0: FRED
    МЕДЛЕННЫЕ = {"CPI", "CORECPI", "COREPCE", "PPI", "NFP", "UNRATE", "CIVPART",
                 "AHE", "JOLTS", "SAHM", "GDP", "INDPRO", "RETAIL", "HOUST",
                 "PERMIT", "UMCSENT", "MICH", "CCDELINQ", "AUTODELINQ", "NONRES",
                 "NEWORDERS", "CLAIMS", "NFCI", "MORT30", "WALCL", "WRESBAL",
                 "RRP", "IOER",
                 "GDPNOW", "CFNAI", "CFNAI3", "REALINC", "REALSALES",
                 "SLOOS_L", "SLOOS_S", "WGT", "WGT_SW", "WGT_ST", "QUITS",
                 "TEMPHELP", "TRIMPCE", "INVENT", "TRUCK", "ALLDELINQ"}
    for k, sid in FRED.items():
        s = fred(sid)
        if s is None:
            continue
        R[k] = s
        слой = "медленный" if k in МЕДЛЕННЫЕ else "быстрый"
        L.series(k, "FRED:%s" % sid, s.index[-1].date(), len(s),
                 note="медленный слой, лаг раскрыт по месту" if слой == "медленный" else "",
                 layer=слой)
    # Yahoo
    ymap = {"GOLD": "GC=F", "COPPER": "HG=F", "BRENT_Y": "BZ=F", "MOVE": "^MOVE",
            "SPX_Y": "^GSPC", "NDX_Y": "^NDX", "RUT_Y": "^RUT"}
    for k, sym in ymap.items():
        s = yahoo(sym)
        if s is None or not len(s):
            L.gap(k.lower(), ["Yahoo chart API"], "ряд не получен")
            continue
        R[k] = s
        note = ""
        meta = s.attrs.get("meta")
        stale = (cut - s.index[-1].date()).days
        if stale > 4 and meta:
            R[k + "_meta"] = meta
            note = "котировка снимка meta.regularMarketPrice"
        if not note and k in ("EURUSD", "USDJPY", "USDCNY", "WTI", "BRENT_Y", "MOVE"):
            note = "замена: котировка снимка на дату среза"
        L.series(k, "Yahoo:%s" % sym, s.index[-1].date(), len(s), note=note)
    # CBOE
    for k, sym, col in (("VIX_C", "VIX", 4), ("VIX9D", "VIX9D", 4), ("VIX3M_C", "VIX3M", 4),
                        ("VVIX", "VVIX", 1), ("SKEW", "SKEW", 1)):
        s = cboe(sym, col)
        if s is None:
            continue
        R[k] = s
        L.series(k, "CBOE:%s" % sym, s.index[-1].date(), len(s))
    # put/call
    pc, pcd = put_call(cut)
    if pc:
        def g(d, key):
            for kk in d:
                if key in kk.lower():
                    return d[kk]
            return None
        C["пут_колл"] = {k: v for k, v in (pc.items() if isinstance(pc, dict) else [])}
        L.value("пут_колл", C["пут_колл"].get("ratio_total") or C["пут_колл"].get("total"),
                "CBOE daily options", pcd)
    else:
        L.gap("пут_колл", ["CBOE cdn daily_options"], "канал не ответил")
    # TGA
    tga = tga_dts()
    if tga is not None:
        R["TGA"] = tga
        L.series("tga", "Treasury DTS", tga.index[-1].date(), len(tga))
    # breadth
    names = constituents()
    if names:
        B = breadth(names)
        for c in ("above200", "adline", "nh_nl", "mcclellan"):
            if c in B.columns:
                R[c] = B[c]
        L.series("широта_рынка", "Yahoo цены состава индекса",
                 B.index[-1].date(), len(B))
        if "mcclellan" in B.columns:
            L.value("осциллятор_макклеллана", round(float(B["mcclellan"].iloc[-1]), 1),
                    "расчёт по линии роста и падения состава индекса",
                    B.index[-1].date(), "пункты")
        C["состав_секторов"] = {}
        for n in names:
            C["состав_секторов"].setdefault(n["sector"], []).append(n["t"])
    # секторные индексы
    SEC = {"Информационные технологии": "^SP500-45", "Финансы": "^SP500-40",
           "Здравоохранение": "^SP500-35", "Промышленность": "^SP500-20",
           "Товары длительного спроса": "^SP500-25", "Товары повседневного спроса": "^SP500-30",
           "Коммунальные услуги": "^SP500-55", "Материалы": "^SP500-15",
           "Недвижимость": "^SP500-60", "Связь": "^SP500-50", "Энергетика": "^SP500-1010"}
    # Запасной канал секторов — фонды SPDR: реестр промпта называет их прямо.
    # Секторные индексы S&P у Yahoo периодически замирают и отдают одну точку —
    # текущую котировку; на такой ряд опереться нельзя, и сектор берётся фондом.
    SEC_ETF = {"Информационные технологии": "XLK", "Финансы": "XLF",
               "Здравоохранение": "XLV", "Промышленность": "XLI",
               "Товары длительного спроса": "XLY", "Товары повседневного спроса": "XLP",
               "Коммунальные услуги": "XLU", "Материалы": "XLB",
               "Недвижимость": "XLRE", "Связь": "XLC", "Энергетика": "XLE"}
    sect, by_etf = {}, 0
    for name, sym in SEC.items():
        s = yahoo(sym)
        if s is not None and len(s) > 500:
            sect[name] = s
            L.series("сектор:" + name, "Yahoo:%s" % sym, s.index[-1].date(), len(s))
            continue
        alt = SEC_ETF.get(name)
        s = yahoo(alt) if alt else None
        if s is not None and len(s) > 500:
            sect[name] = s
            by_etf += 1
            L.series("сектор:" + name, "Yahoo:%s" % alt, s.index[-1].date(), len(s),
                     note="замена: секторный фонд SPDR, индекс S&P отдал обрубок")
        else:
            L.gap("сектор:" + name, ["Yahoo:%s" % sym, "Yahoo:%s" % (alt or "-")],
                  "ни индекс, ни фонд не дали ряда")
    C["секторный_канал"] = ("секторные фонды SPDR" if by_etf == len(SEC)
                            else ("секторные индексы S&P (^SP500-NN)" if not by_etf
                                  else "секторные индексы S&P, %d сектора(ов) по фондам SPDR" % by_etf))
    # международные индексы: китайский берётся по шэньчжэньскому зеркалу
    # 399300.SZ — шанхайский тикер 000300.SS замирает на недели
    C["международные"] = {}
    for name, sym in (("STOXX 600", "^STOXX"), ("Nikkei 225", "^N225"),
                      ("CSI 300", "399300.SZ"), ("Hang Seng", "^HSI"),
                      ("Bitcoin", "BTC-USD")):
        s_i = yahoo(sym, long_hist=False)
        if s_i is None or not len(s_i):
            L.gap(name, ["Yahoo chart API"], "ряд не получен")
            continue
        i0 = s_i.index.searchsorted(s_i.index[-1] - pd.Timedelta(days=30))
        C["международные"][name] = {
            "уровень": round(float(s_i.iloc[-1]), 2), "дата": str(s_i.index[-1].date()),
            "месяц": round((float(s_i.iloc[-1]) / float(s_i.iloc[i0]) - 1) * 100, 2)}
        L.series(name, "Yahoo:%s" % sym, s_i.index[-1].date(), len(s_i))

    # CNN
    fg = cnn_fg()
    if fg:
        C["fear_greed"] = {"значение": fg.get("fear_and_greed", {}).get("score"),
                           "оценка": fg.get("fear_and_greed", {}).get("rating"),
                           "дата": fg.get("fear_and_greed", {}).get("timestamp", "")[:10],
                           "компоненты": {k: round(v.get("score"), 1)
                                          for k, v in fg.items()
                                          if isinstance(v, dict) and "score" in v
                                          and k != "fear_and_greed"}}
    nc = nowcast()
    if nc is not None:
        try:
            last = nc.iloc[-1]; prev = nc.iloc[-2]
            def pick(row):
                d = {str(k): float(v) for k, v in row.items()
                     if k != "Forecast Date" and pd.notna(v)}
                return d
            C["nowcast"] = {"дата": str(pd.Timestamp(last["Forecast Date"]).date()),
                            "оценки": pick(last), "неделей_ранее": pick(prev)}
            L.value("nowcast", json.dumps(C["nowcast"]["оценки"], ensure_ascii=False),
                    "NY Fed Staff Nowcast", C["nowcast"]["дата"], "% г/г")
        except Exception as e:
            L.get("NY Fed Nowcast", "разбор листа", ok=False, note=str(e)[:80])

    # ── чистая ликвидность
    if all(k in R for k in ("WRESBAL", "RRP")):
        # WRESBAL и WALCL — млн $; RRPONTSYD и TGA(DTS) — млрд $. Приводим к млрд.
        w = (R["WRESBAL"] / 1000.0).resample("W-WED").last().dropna()
        rr = R["RRP"].resample("W-WED").last().reindex(w.index).ffill()
        netliq = (w - rr).dropna()
        R["NETLIQ"] = netliq
        L.series("чистая_ликвидность", "FRED WRESBAL − RRP", netliq.index[-1].date(),
                 len(netliq), note="недельная серия, лаг H.4.1", layer="медленный")
        if "WALCL" in R and "TGA" in R:
            wal = float(R["WALCL"].iloc[-1]) / 1000.0        # млрд
            tg = float(R["TGA"].iloc[-1])                     # млрд
            rrl = float(R["RRP"].iloc[-1])                    # млрд
            C["ликвидность_кросс"] = {
                "WALCL_млрд": round(wal, 1), "TGA_млрд": round(tg, 1),
                "RRP_млрд": round(rrl, 2),
                "оценка_WALCL_млрд": round(wal - tg - rrl, 1),
                "WRESBAL_млрд": round(float(R["WRESBAL"].iloc[-1]) / 1000.0, 1),
                "чистая_ликвидность_млрд": round(float(netliq.iloc[-1]), 1),
                "дельта_месяц_млрд": round(float(netliq.iloc[-1] - netliq.iloc[-5]), 1)
                if len(netliq) > 5 else None,
                "дата_TGA": str(R["TGA"].index[-1].date()),
                "дата_резервов": str(netliq.index[-1].date())}
    # ставка ФРС
    if "IORB" in R and "IOER" in R:
        R["IORB_FULL"] = pd.concat([R["IOER"][R["IOER"].index < R["IORB"].index[0]], R["IORB"]])

    # расчётные ряды
    spx = R.get("SPX_Y", R.get("SP500"))
    if spx is not None:
        r = spx.pct_change()
        R["RV20"] = (r.rolling(20).std() * np.sqrt(252) * 100).dropna()
        if "VIX" in R:
            v = R["VIX"].reindex(R["RV20"].index).ffill()
            R["VRP"] = (v - R["RV20"]).dropna()
        if "UST10Y" in R:
            b = -R["UST10Y"].diff()
            R["CORR_SB"] = r.rolling(63).corr(b.reindex(r.index)).dropna()
        R["SPX_200"] = (spx / spx.rolling(200).mean() - 1).dropna() * 100
        R["SPX_50"] = (spx / spx.rolling(50).mean() - 1).dropna() * 100

    # месячные производные
    if "COREPCE" in R:
        c3 = ((R["COREPCE"] / R["COREPCE"].shift(3)) ** 4 - 1) * 100
        R["COREPCE_3M"] = c3.dropna()
        R["COREPCE_YOY"] = (R["COREPCE"].pct_change(12) * 100).dropna()
    if "CORECPI" in R:
        R["CORECPI_YOY"] = (R["CORECPI"].pct_change(12) * 100).dropna()
        R["CORECPI_3M"] = (((R["CORECPI"] / R["CORECPI"].shift(3)) ** 4 - 1) * 100).dropna()
    if "CPI" in R:
        R["CPI_YOY"] = (R["CPI"].pct_change(12) * 100).dropna()
    if "NFP" in R:
        R["NFP_3M"] = (R["NFP"].diff().rolling(3).mean() * 1000).dropna()
    if "INDPRO" in R:
        R["INDPRO_3M"] = ((((R["INDPRO"] / R["INDPRO"].shift(3)) ** 4 - 1) * 100)).dropna()
    if "RETAIL" in R:
        R["RETAIL_YOY"] = (R["RETAIL"].pct_change(12) * 100).dropna()

    # ── Р.2 таблица нормировки (закрытый перечень)
    daily = [("SPX", "SPX_Y", "пункты"), ("NDX", "NDX_Y", "пункты"), ("RUT", "RUT_Y", "пункты"),
             ("VIX", "VIX", "пункты"), ("VIX9D", "VIX9D", "пункты"), ("VVIX", "VVIX", "пункты"),
             ("VXN", "VXN", "пункты"), ("SKEW", "SKEW", "пункты"),
             ("UST3M", "UST3M", "%"), ("UST2Y", "UST2Y", "%"), ("UST10Y", "UST10Y", "%"),
             ("UST30Y", "UST30Y", "%"), ("2s10s", "S2s10s", "п.п."), ("3m10y", "S3m10y", "п.п."),
             ("REAL10Y", "REAL10Y", "%"), ("BE5Y", "BE5Y", "%"), ("BE10Y", "BE10Y", "%"),
             ("HYOAS", "HYOAS", "б.п."), ("IGOAS", "IGOAS", "б.п."), ("BAA10Y", "BAA10Y", "п.п."),
             ("DXYB", "DXYB", "индекс"), ("EURUSD", "EURUSD", "курс"), ("USDJPY", "USDJPY", "курс"),
             ("WTI", "WTI", "$/барр"), ("BRENT", "BRENT_Y", "$/барр"), ("GOLD", "GOLD", "$/унц"),
             ("COPPER", "COPPER", "$/фунт"), ("MOVE", "MOVE", "пункты")]
    weekly = [("NFCI", "NFCI", "индекс"), ("NETLIQ", "NETLIQ", "$ млрд"),
              ("CLAIMS", "CLAIMS", "тыс."), ("MORT30", "MORT30", "%")]
    monthly = [("NFP_3M", "NFP_3M", "чел."), ("UNRATE", "UNRATE", "%"),
               ("COREPCE_YOY", "COREPCE_YOY", "%"), ("COREPCE_3M", "COREPCE_3M", "%"),
               ("CORECPI_YOY", "CORECPI_YOY", "%"), ("INDPRO_3M", "INDPRO_3M", "%"),
               ("RETAIL_YOY", "RETAIL_YOY", "%"), ("UMCSENT", "UMCSENT", "индекс"),
               ("JOLTS", "JOLTS", "тыс."), ("HOUST", "HOUST", "тыс."),
               ("above200", "above200", "%")]
    calc_rows = [("RV20", "RV20", "%"), ("VRP", "VRP", "пункты"), ("CORR_SB", "CORR_SB", "коэф.")]
    норм = []
    for label, key, unit in daily:
        row = norm_row(label, R.get(key), 252, unit, "д")
        if row:
            норм.append(row)
    for label, key, unit in weekly:
        row = norm_row(label, R.get(key), 52, unit, "н")
        if row:
            норм.append(row)
    for label, key, unit in monthly:
        s = R.get(key)
        if s is not None and label == "above200":
            s = s.resample("ME").last()
        row = norm_row(label, s, 60, unit, "м")
        if row:
            норм.append(row)
    for label, key, unit in calc_rows:
        row = norm_row(label, R.get(key), 252, unit, "расч.")
        if row:
            норм.append(row)
    C["нормировка"] = норм
    C["нормировка_пропуски"] = [l for l, k, u in daily + weekly + monthly + calc_rows
                                if R.get(k) is None or not len(R.get(k, pd.Series(dtype=float)).dropna())]

    # ── Р.4
    lent = classifier({k: R[k] for k in ("NFP", "UNRATE", "INDPRO", "COREPCE", "CORECPI") if k in R})
    C["лента_режимов"] = {str(k.date()): v for k, v in lent.items()}
    cur = lent.iloc[-1]
    months = 1
    for i in range(len(lent) - 2, -1, -1):
        if lent.iloc[i] == cur:
            months += 1
        else:
            break
    durations = []
    run, prev = 0, None
    for v in lent.values:
        if v == prev:
            run += 1
        else:
            if prev is not None:
                durations.append(run)
            run, prev = 1, v
    durations.append(run)
    C["режим"] = {"текущий": cur, "месяцев": months,
                  "медианная_длительность": float(np.median(durations)),
                  "доли": {k: round(float(v) * 100, 1)
                           for k, v in lent.value_counts(normalize=True).items()},
                  "история_с": str(lent.index[0].date())}
    C["переходы_1м"] = transitions(lent, 1)
    C["переходы_3м"] = transitions(lent, 3)
    assets = {k: R[k] for k in ("SPX_Y", "NDX_Y", "UST10Y", "BAA10Y", "GOLD", "DXYB") if k in R}
    C["условные_доходности"] = fwd_by_regime(lent, assets)

    # ── Р.9 секторный мост
    bridge = {}
    if sect and spx is not None:
        eps_by_reg = {}
        prev = None
        for t, r in lent.items():
            if r != prev:
                eps_by_reg.setdefault(r, []).append(t)
            prev = r
        for name, s in sect.items():
            s = s.dropna()
            bridge[name] = {}
            for reg, starts in eps_by_reg.items():
                for w in (21, 63):
                    res = []
                    for d in starts:
                        i = s.index.searchsorted(d); j = spx.index.searchsorted(d)
                        if i + w >= len(s) or j + w >= len(spx):
                            continue
                        if abs((s.index[i] - d).days) > 10 or abs((spx.index[j] - d).days) > 10:
                            continue
                        rs = float(s.iloc[i + w]) / float(s.iloc[i]) - 1
                        rm = float(spx.iloc[j + w]) / float(spx.iloc[j]) - 1
                        res.append((rs - rm) * 100)
                    k = "%s_%dд" % (reg, w)
                    if len(res) >= 5:
                        bridge[name][k] = {"n": len(res),
                                           "p50": round(float(np.median(res)), 2),
                                           "p25": round(float(np.percentile(res, 25)), 2),
                                           "p75": round(float(np.percentile(res, 75)), 2),
                                           "доля_плюс": round(float(np.mean([x > 0 for x in res]) * 100), 1)}
                    elif res:
                        bridge[name][k] = {"n": len(res), "эпизоды": [round(x, 2) for x in res]}
    C["секторный_мост"] = bridge

    # ── Р.3 триггеры
    trig = {}
    baa = R.get("BAA10Y")
    if baa is not None:
        p75 = float(np.percentile(baa[baa.index >= baa.index[-1] - pd.Timedelta(days=3650)], 75))
        eps = episodes(baa, p75, True)
        trig["кредитная_премия"] = {"порог": round(p75, 2), "эпизодов": len(eps),
                                    "текущее": round(float(baa.iloc[-1]), 2),
                                    "исходы": event_study(eps, assets)}
    if "VIX" in R:
        v = R["VIX"]
        thr = float(np.percentile(v[v.index >= v.index[-1] - pd.Timedelta(days=3650)], 85))
        eps = episodes(v, thr, True)
        trig["vix"] = {"порог": round(thr, 1), "эпизодов": len(eps),
                       "текущее": round(float(v.iloc[-1]), 2),
                       "исходы": event_study(eps, assets)}
    if "UST10Y" in R:
        y = R["UST10Y"]
        thr = float(np.percentile(y[y.index >= y.index[-1] - pd.Timedelta(days=3650)], 85))
        eps = episodes(y, thr, True)
        trig["доходность_10л"] = {"порог": round(thr, 2), "эпизодов": len(eps),
                                  "текущее": round(float(y.iloc[-1]), 2),
                                  "исходы": event_study(eps, assets)}
    if "S3m10y" in R:
        y = R["S3m10y"]
        eps = episodes(y, 0.0, False)
        trig["инверсия_3m10y"] = {"порог": 0.0, "эпизодов": len(eps),
                                  "текущее": round(float(y.iloc[-1]), 2),
                                  "исходы": event_study(eps, assets)}
    if "COREPCE_3M" in R:
        y = R["COREPCE_3M"]
        thr = 3.0
        eps = episodes(y, thr, True, gap_days=60)
        trig["базовая_инфляция_3м"] = {"порог": thr, "эпизодов": len(eps),
                                       "текущее": round(float(y.iloc[-1]), 2),
                                       "исходы": event_study(eps, assets)}
    if "UNRATE" in R:
        u = R["UNRATE"]
        um = u.rolling(12, min_periods=6).min()
        d = (u - um).dropna()
        eps = episodes(d, 0.5, True, gap_days=60)
        trig["правило_сама"] = {"порог": 0.5, "эпизодов": len(eps),
                                "текущее": round(float(d.iloc[-1]), 2),
                                "исходы": event_study(eps, assets)}
    if "BRENT_Y" in R:
        b = R["BRENT_Y"]
        thr = float(np.percentile(b[b.index >= b.index[-1] - pd.Timedelta(days=3650)], 85))
        eps = episodes(b, thr, True)
        trig["brent"] = {"порог": round(thr, 1), "эпизодов": len(eps),
                         "текущее": round(float(b.iloc[-1]), 2),
                         "исходы": event_study(eps, assets)}
    C["триггеры"] = trig

    # ── Р.5 модели
    if spx is not None and baa is not None:
        m_idx = pd.date_range(spx.index[0], spx.index[-1], freq="ME")
        def at(s, d):
            w = s[s.index <= d]
            return float(w.iloc[-1]) if len(w) else np.nan
        rows = []
        zbaa = zscore(baa, 252); zvix = zscore(R["VIX"], 252) if "VIX" in R else None
        zreal = zscore(R["REAL10Y"], 252) if "REAL10Y" in R else None
        znfci = zscore(R["NFCI"], 52) if "NFCI" in R else None
        spx200 = R.get("SPX_200")
        for d in m_idx:
            row = {"d": d,
                   "z_baa": at(zbaa, d) if zbaa is not None else np.nan,
                   "s2s10s": at(R["S2s10s"], d) if "S2s10s" in R else np.nan,
                   "s3m10y": at(R["S3m10y"], d) if "S3m10y" in R else np.nan,
                   "z_vix": at(zvix, d) if zvix is not None else np.nan,
                   "d_unrate6": (at(R["UNRATE"], d) - at(R["UNRATE"], d - pd.Timedelta(days=190)))
                                 if "UNRATE" in R else np.nan,
                   "z_real": at(zreal, d) if zreal is not None else np.nan,
                   "spx_vs200": at(spx200, d) if spx200 is not None else np.nan,
                   "z_nfci": at(znfci, d) if znfci is not None else np.nan}
            rows.append(row)
        X = pd.DataFrame(rows).set_index("d")
        # цели
        y_corr, y_cred = [], []
        for d in X.index:
            i = spx.index.searchsorted(d)
            if i >= len(spx) - 63 or abs((spx.index[min(i, len(spx) - 1)] - d).days) > 10:
                y_corr.append(np.nan)
            else:
                w = spx.iloc[i:i + 63]
                peak = float(spx.iloc[max(0, i - 252):i + 1].max())
                start = float(spx.iloc[i])
                if start < peak * 0.95:
                    y_corr.append(np.nan)          # старт глубже −5 % от максимума
                else:
                    y_corr.append(1 if float(w.min()) <= peak * 0.90 else 0)
            j = baa.index.searchsorted(d)
            if j >= len(baa) - 63 or abs((baa.index[min(j, len(baa) - 1)] - d).days) > 10:
                y_cred.append(np.nan)
            else:
                w = baa.iloc[j:j + 63]
                y_cred.append(1 if float(w.max()) - float(baa.iloc[j]) >= 1.0 else 0)
        D = {"X": X, "y_corr": pd.Series(y_corr, index=X.index),
             "y_credit": pd.Series(y_cred, index=X.index)}
        C["модели"] = logit_models(D)

    # ── Р.6 Monte-Carlo (условно на режим)
    if spx is not None:
        r = spx.pct_change().dropna()
        mask = pd.Series(False, index=r.index)
        for t, reg in lent.items():
            if reg == cur:
                a = t - pd.offsets.MonthBegin(1)
                mask.loc[(r.index >= a) & (r.index <= t)] = True
            regime_ret = r[mask]
        C["монте_карло"] = bootstrap(regime_ret)
        C["монте_карло_режим"] = cur
        C["монте_карло_уровень"] = round(float(spx.iloc[-1]), 2)
        # наложение по триггеру
        if baa is not None:
            p75 = float(np.percentile(baa[baa.index >= baa.index[-1] - pd.Timedelta(days=3650)], 75))
            hi = baa[baa > p75]
            m2 = r.index.isin(pd.DatetimeIndex(hi.index))
            over = r[m2]
            C["монте_карло_наложение"] = bootstrap(over, seed=11) if len(over) > 200 else \
                {"статус": "мало наблюдений", "n": int(len(over))}

    # ── Р.8 базовые частоты
    if spx is not None:
        by_reg = {}
        for reg in sorted(set(lent.values)):
            dates = [t for t, rr in lent.items() if rr == reg]
            corr, up5, cred = [], [], []
            for d in dates:
                i = spx.index.searchsorted(d)
                if i >= len(spx) - 63 or abs((spx.index[min(i, len(spx) - 1)] - d).days) > 10:
                    continue
                peak = float(spx.iloc[max(0, i - 252):i + 1].max())
                start = float(spx.iloc[i]); w = spx.iloc[i:i + 63]
                if start >= peak * 0.95:
                    corr.append(1 if float(w.min()) <= peak * 0.90 else 0)
                up5.append(1 if float(w.max()) >= start * 1.05 else 0)
                if baa is not None:
                    j = baa.index.searchsorted(d)
                    if j < len(baa) - 63 and abs((baa.index[min(j, len(baa) - 1)] - d).days) <= 10:
                        cred.append(1 if float(baa.iloc[j:j + 63].max()) - float(baa.iloc[j]) >= 1.0 else 0)
            by_reg[reg] = {"n": len(dates),
                           "коррекция_10": round(float(np.mean(corr) * 100), 1) if len(corr) >= 5 else None,
                           "n_коррекция": len(corr),
                           "рост_5": round(float(np.mean(up5) * 100), 1) if len(up5) >= 5 else None,
                           "расширение_премии": round(float(np.mean(cred) * 100), 1) if len(cred) >= 5 else None}
        C["базовые_частоты"] = by_reg

    # ── свежие котировки там, где канонический канал отстаёт (FRED по валютам
    # и сырью отстаёт на 3–5 торговых дней; Yahoo ^MOVE замирает)
    spot = {}
    for key, sym, unit in (("доллар_DXY", "DX=F", "индекс ICE"),
                           ("EURUSD_спот", "EURUSD=X", "курс"),
                           ("USDJPY_спот", "JPY=X", "курс"),
                           ("USDCNY_спот", "CNY=X", "курс"),
                           ("WTI_спот", "CL=F", "$/барр"),
                           ("MOVE_спот", "^MOVE", "пункты"),
                           ("VIX_спот", "^VIX", "пункты")):
        try:
            u = ("https://query1.finance.yahoo.com/v8/finance/chart/%s?range=5d&interval=1d"
                 % urllib.parse.quote(sym, safe="^"))
            j = json.loads(fetch(u, ua=BUA))
            m = j["chart"]["result"][0]["meta"]
            px = m.get("regularMarketPrice")
            ts = m.get("regularMarketTime")
            d = dt.datetime.utcfromtimestamp(ts).date() if ts else cut
            spot[key] = {"значение": round(float(px), 4), "дата": str(d), "единица": unit}
            L.value(key, round(float(px), 4), "Yahoo meta:%s" % sym, d, unit,
                    note="котировка снимка")
        except Exception as e:
            L.gap(key, ["Yahoo meta"], str(e)[:80])
    C["котировки_снимка"] = spot

    # ── ряды задания 04.09.2026: диагноз, а не описание (промпт v6.2)
    Н = {}

    def точка(ключ, имя, ед="", знаков=2, мес=0):
        """Последнее значение ряда с датой; мес — сравнение с точкой N месяцев назад."""
        s_ = R.get(ключ)
        if s_ is None or not len(s_):
            L.gap(имя, ["FRED:%s" % FRED.get(ключ, ключ)], "ряд не получен")
            return None
        v = float(s_.iloc[-1]); d = s_.index[-1].date()
        зап = {"значение": round(v, знаков), "дата": str(d), "единица": ед}
        if мес:
            i0 = s_.index.searchsorted(s_.index[-1] - pd.DateOffset(months=мес))
            i0 = min(max(i0, 0), len(s_) - 1)
            зап["было"] = round(float(s_.iloc[i0]), знаков)
            зап["дата_было"] = str(s_.index[i0].date())
        L.value(имя, зап["значение"], "FRED:%s" % FRED.get(ключ, ключ), d, ед)
        Н[имя] = зап
        return зап

    точка("GDPNOW", "рост_текущего_квартала", "% годовых", 2)
    точка("CFNAI", "ширина_экономики", "пункты", 2)
    точка("CFNAI3", "ширина_экономики_3м", "пункты", 2)
    точка("ANFCI", "условия_очищенные", "пункты", 3, мес=3)
    точка("REALINC", "реальный_доход_без_трансфертов", "млрд $", 1, мес=12)
    точка("REALSALES", "продажи_обработки_и_торговли", "млн $", 0, мес=12)
    точка("SLOOS_L", "стандарты_крупным_фирмам", "% банков", 1)
    точка("SLOOS_S", "стандарты_малым_фирмам", "% банков", 1)
    точка("QUITS", "доля_увольняющихся", "%", 1, мес=12)
    точка("CCLAIMS", "продолжающиеся_заявки", "человек", 0, мес=12)
    точка("TEMPHELP", "временный_найм", "тыс. человек", 1, мес=12)
    точка("TRIMPCE", "усечённая_средняя_инфляция", "% годовых", 2)
    точка("TRUCK", "перевозки_грузов", "пункты", 1, мес=12)
    точка("CCDELINQ", "просрочка_по_картам", "%", 2, мес=12)
    точка("ALLDELINQ", "просрочка_по_всем_ссудам", "%", 2, мес=12)

    # премия за смену работы: ради неё трекер и заведён
    if all(k in R for k in ("WGT_SW", "WGT_ST")):
        sw, st = R["WGT_SW"], R["WGT_ST"]
        d = min(sw.index[-1], st.index[-1])
        a_, b_ = float(sw.loc[:d].iloc[-1]), float(st.loc[:d].iloc[-1])
        общ = R.get("WGT")
        Н["премия_за_смену_работы"] = {
            "сменившие": round(a_, 2), "оставшиеся": round(b_, 2),
            "премия": round(a_ - b_, 2), "единица": "п. п.",
            "общий_рост_зарплат": round(float(общ.iloc[-1]), 2) if общ is not None else None,
            "дата": str(d.date())}
        L.value("премия_за_смену_работы", round(a_ - b_, 2),
                "FRED:FRBATLWGT12MMUMHWGJSW минус …JST", d.date(), "п. п.")

    # промышленный цикл: новые заказы против запасов, без ряда ISM
    if all(k in R for k in ("NEWORDERS", "INVENT")):
        no, iv = R["NEWORDERS"], R["INVENT"]
        d = min(no.index[-1], iv.index[-1])
        отн = float(no.loc[:d].iloc[-1]) / float(iv.loc[:d].iloc[-1])
        i0 = no.index.searchsorted(d - pd.DateOffset(months=12))
        отн0 = float(no.iloc[i0]) / float(iv.iloc[min(i0, len(iv) - 1)])
        Н["заказы_к_запасам"] = {"значение": round(отн, 3), "год_назад": round(отн0, 3),
                                 "дата": str(d.date()), "единица": "отношение"}
        L.value("заказы_к_запасам", round(отн, 3),
                "FRED:AMTMNO / FRED:AMTMTI", d.date(), "отношение")

    # расхождение широкого счёта и квартальной модели — вход для раздела 2.1
    if "рост_текущего_квартала" in Н and "ширина_экономики_3м" in Н:
        Н["расхождение_роста"] = {
            "модель_квартала": Н["рост_текущего_квартала"]["значение"],
            "широкий_счёт_3м": Н["ширина_экономики_3м"]["значение"],
            "толкование": ("модель квартала показывает разгон при широком счёте "
                           "около тренда" if Н["ширина_экономики_3м"]["значение"] > -0.35
                           and Н["рост_текущего_квартала"]["значение"] > 3
                           else "стороны сходятся")}

    # инфляция: устойчивая часть против заголовочной
    if "усечённая_средняя_инфляция" in Н and "COREPCE_YOY" in C.get("нормировка", {}):
        Н["инфляция_расхождение"] = {
            "усечённая_средняя": Н["усечённая_средняя_инфляция"]["значение"],
            "базовая_г_г": C["нормировка"]["COREPCE_YOY"]["значение"]}

    # ряды без свободного канала — объявляются пробелом, а не молчат
    for имя, каналы in (("опережающий_композит", ["Conference Board (платный)"]),
                        ("настроение_застройщика", ["NAHB/Wells Fargo HMI"]),
                        ("вклад_бюджета_в_рост", ["Hutchins Center FIM"]),
                        ("обратный_выкуп_акций", ["S&P Dow Jones Indices"])):
        if имя not in Н:
            L.gap(имя, каналы, "свободного ряда нет: значение берётся публикацией на прогоне")
    C["новые_ряды"] = Н

    # ── данные графиков
    def ser(s, n=520):
        s = s.dropna().iloc[-n:]
        return {"даты": [str(d.date()) for d in s.index], "значения": [round(float(v), 4) for v in s.values]}
    if spx is not None:
        ch["spx"] = ser(spx)
    for k in ("VIX", "BAA10Y", "UST10Y", "NETLIQ", "above200", "COREPCE_3M", "S2s10s",
              "CFNAI3", "QUITS", "TEMPHELP", "TRIMPCE", "CCLAIMS"):
        if k in R:
            ch[k] = ser(R[k], 260 if k in ("NETLIQ",) else 520)
    ch["лента_режимов"] = {str(k.date()): v for k, v in lent[lent.index >= lent.index[-1] - pd.Timedelta(days=3800)].items()}
    if "монте_карло" in C and C["монте_карло"]:
        ch["монте_карло"] = C["монте_карло"]

    json.dump(C, open(os.path.join(OUT, "calc.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1, default=str)
    json.dump(ch, open(os.path.join(OUT, "charts.json"), "w", encoding="utf-8"),
              ensure_ascii=False, default=str)
    print("готово: рядов %d, нормировка %d строк, режим %s (%d мес.)"
          % (len(R), len(норм), cur, months))
    print("пропуски нормировки:", C["нормировка_пропуски"])


if __name__ == "__main__":
    main()
