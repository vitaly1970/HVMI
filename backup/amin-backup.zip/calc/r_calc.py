#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""r_calc.py — раздел R промпта «Ротация секторов»: историческая проверка,
факторный разрез, макро-фон, оценка уверенности и уровни по спреду.

Раздел E не трогает и не импортирует: читает те же CSV из /home/claude/data.
Все числа выпуска берутся из печати этого скрипта и раздела E; интерпретатор
не считает сам.  Синтез точек запрещён: нет ряда — печатается «нет данных».
"""
import csv, json, math, os, statistics as st, datetime as dt, sys

# журнал источников (скилл amin-data): гейт раздела S не пропускает число,
# которое не прошло через журнал
sys.path.insert(0, "/mnt/skills/user/amin-data/assets")
from amin_run import Log

DATA = "/home/claude/data"
OUT = "/home/claude"
LOG_OUT = "out"          # каталог журнала каналов для гейта раздела S
SEC = ["XLK", "XLF", "XLV", "XLY", "XLP", "XLE", "XLI", "XLB", "XLU", "XLRE", "XLC"]
CORE = ["SPY", "RSP"]
FACT = {"MTUM": "моментум", "QUAL": "качество", "USMV": "низкая волатильность",
        "VLUE": "стоимость"}
RU = {"XLK": "Технологии", "XLF": "Финансы", "XLV": "Здравоохранение",
      "XLY": "Товары длительного спроса", "XLP": "Товары повседневного спроса",
      "XLE": "Энергетика", "XLI": "Промышленность", "XLB": "Материалы",
      "XLU": "Коммунальные услуги", "XLRE": "Недвижимость", "XLC": "Коммуникации"}
DEF = ["XLP", "XLU", "XLV", "XLRE"]                     # защитные
CYC = ["XLK", "XLY", "XLI", "XLF", "XLB", "XLE", "XLC"]  # циклические

W = 63                      # базовое окно, как в разделе E
WINDOWS = [42, 63, 84]
DISP_P25 = 0.0432
NARROW_P80 = 0.026
HOLD = 1                    # недель удержания
FWD = 4                     # окно проверки исхода сигнала, недель
COST_BP = 5                 # издержки на ногу при смене позиции, б.п.
NEAR = 40                   # соседей при подборе похожего макро-фона
HEAT = 52                   # недель в тепловой карте


def read_prices(t):
    p = os.path.join(DATA, t + ".csv")
    if not os.path.exists(p):
        return {}
    out = {}
    with open(p) as f:
        for row in csv.DictReader(f):
            try:
                out[row["date"][:10]] = float(row["adjClose"])
            except (KeyError, ValueError, TypeError):
                continue
    return out


def read_fred(sid):
    p = os.path.join(DATA, sid + ".csv")
    if not os.path.exists(p):
        return {}
    out = {}
    with open(p) as f:
        r = csv.reader(f)
        next(r, None)
        for row in r:
            if len(row) < 2:
                continue
            try:
                out[row[0][:10]] = float(row[1])
            except ValueError:
                continue
    return out


def pct(x):
    return "%+.1f" % (x * 100)


# ---------- панель ----------
px = {t: read_prices(t) for t in SEC + CORE}
missing = [t for t in SEC + CORE if not px[t]]
if missing:
    print("СТОП: нет рядов %s" % " ".join(missing))
    raise SystemExit(1)
dates = sorted(set.intersection(*(set(px[t]) for t in SEC + CORE)))
if len(dates) < W + 60:
    print("СТОП: истории %d дат, для проверки мало" % len(dates))
    raise SystemExit(1)
idx = {d: i for i, d in enumerate(dates)}
S = {t: [px[t][d] for d in dates] for t in SEC + CORE}

fx = {}
for t in FACT:
    s = read_prices(t)
    fx[t] = [s.get(d) for d in dates] if s else None

# недельная сетка: последний торговый день недели
weeks = []
for i, d in enumerate(dates):
    wd = dt.date.fromisoformat(d).isocalendar()[:2]
    if i + 1 == len(dates) or dt.date.fromisoformat(dates[i + 1]).isocalendar()[:2] != wd:
        weeks.append(i)
weeks = [i for i in weeks if i >= W]

print("=== РАЗДЕЛ R · ИСТОРИЧЕСКАЯ ПРОВЕРКА ===")
print("ПАНЕЛЬ: %d торговых дат %s → %s | недельных точек %d | окно %d дн."
      % (len(dates), dates[0], dates[-1], len(weeks), W))


def snap(i, win=W):
    """Срез метрик на индексе i дневной панели."""
    r = {t: S[t][i] / S[t][i - win] - 1.0 for t in SEC + CORE}
    rel = {t: r[t] - r["SPY"] for t in SEC}
    disp = st.pstdev(list(rel.values()))
    narrow = r["SPY"] - r["RSP"]
    med = st.median([abs(v) for v in rel.values()])
    strong = [v for v in rel.values() if abs(v) > med]
    two = int(any(v > 0 for v in strong) and any(v < 0 for v in strong))
    regime = int(disp > DISP_P25 and narrow <= NARROW_P80 and two)
    ir = {}
    for t in SEC:
        ex = [(S[t][k] / S[t][k - 1] - 1.0) - (S["SPY"][k] / S["SPY"][k - 1] - 1.0)
              for k in range(i - win + 1, i + 1)]
        v = st.pstdev(ex) if len(ex) > 1 else 0.0
        ir[t] = rel[t] / (v * math.sqrt(win)) if v > 0 else 0.0
    return rel, ir, disp, narrow, two, regime


# ---------- R.1 бэктест ----------
rows = []
for i in weeks:
    rel, ir, disp, narrow, two, regime = snap(i)
    rank = sorted(SEC, key=lambda t: -ir[t])
    rows.append({"i": i, "date": dates[i], "rel": rel, "ir": ir, "disp": disp,
                 "narrow": narrow, "two": two, "regime": regime,
                 "L": rank[0], "A": rank[-1]})

cost = COST_BP / 10000.0


def run(mode):
    eq, curve, pos, trades, wins, rets = 1.0, [], None, 0, 0, []
    for k in range(len(rows) - 1):
        a, b = rows[k], rows[k + 1]
        want = (a["L"], a["A"]) if a["regime"] else None
        if mode == "long" and a["regime"]:
            want = (a["L"], None)
        if want != pos:
            legs = (2 if pos else 0) + (2 if want else 0) if mode == "spread" else \
                   (1 if pos else 0) + (1 if want else 0)
            eq *= (1 - cost) ** legs
            trades += 1 if want else 0
            pos = want
        if pos:
            rl = S[pos[0]][b["i"]] / S[pos[0]][a["i"]] - 1.0
            ra = S[pos[1]][b["i"]] / S[pos[1]][a["i"]] - 1.0 if pos[1] else 0.0
            r = rl - ra
            rets.append(r)
            wins += 1 if r > 0 else 0
            eq *= (1 + r)
        curve.append((b["date"], eq))
    return eq, curve, trades, wins, rets


def stats(name, eq, curve, trades, wins, rets):
    if not rets:
        print("  %s: сделок нет" % name)
        return {}
    years = (dt.date.fromisoformat(curve[-1][0]) - dt.date.fromisoformat(curve[0][0])).days / 365.25
    peak, mdd = curve[0][1], 0.0
    for _, v in curve:
        peak = max(peak, v)
        mdd = min(mdd, v / peak - 1.0)
    d = {"итог": eq - 1, "годовых": eq ** (1 / years) - 1, "недель_в_рынке": len(rets),
         "сделок": trades, "доля_прибыльных": wins / len(rets),
         "средняя_неделя": sum(rets) / len(rets), "медиана_недели": st.median(rets),
         "просадка": mdd, "ожидание": sum(rets) / len(rets)}
    print("  %-22s итог %s%% | годовых %s%% | недель в рынке %d | сделок %d | "
          "доля прибыльных %.0f%% | средняя неделя %s%% | макс. просадка %.1f%%"
          % (name, pct(d["итог"]), pct(d["годовых"]), d["недель_в_рынке"], trades,
             100 * d["доля_прибыльных"], pct(d["средняя_неделя"]), 100 * mdd))
    return d


print("\nR.1 БЭКТЕСТ (недельный пересмотр, издержки %d б.п. на ногу, "
      "лидер и аутсайдер по IR):" % COST_BP)
sp = stats("спред лидер−аутсайдер", *run("spread"))
lo = stats("лидер или деньги", *run("long"))
bh_i0, bh_i1 = rows[0]["i"], rows[-1]["i"]
bh = S["SPY"][bh_i1] / S["SPY"][bh_i0] - 1.0
yrs = (dt.date.fromisoformat(dates[bh_i1]) - dt.date.fromisoformat(dates[bh_i0])).days / 365.25
print("  %-22s итог %s%% | годовых %s%%" % ("эталон S&P 500", pct(bh),
                                            pct((1 + bh) ** (1 / yrs) - 1)))

# ---------- R.2 таблица сигналов и ошибки ----------
sig = []
for k in range(len(rows) - FWD):
    a = rows[k]
    if not a["regime"]:
        continue
    j = rows[k + FWD]["i"]
    r = (S[a["L"]][j] / S[a["L"]][a["i"]] - 1.0) - (S[a["A"]][j] / S[a["A"]][a["i"]] - 1.0)
    sig.append({"дата": a["date"], "лидер": a["L"], "аутсайдер": a["A"],
                "спред_вперёд_4н": r})
noise = []
for k in range(len(rows) - FWD):
    a = rows[k]
    if a["regime"]:
        continue
    j = rows[k + FWD]["i"]
    r = (S[a["L"]][j] / S[a["L"]][a["i"]] - 1.0) - (S[a["A"]][j] / S[a["A"]][a["i"]] - 1.0)
    noise.append(r)
if sig:
    ok = sum(1 for s in sig if s["спред_вперёд_4н"] > 0)
    big = st.median([abs(s["спред_вперёд_4н"]) for s in sig])
    miss = sum(1 for r in noise if r > big)
    print("\nR.2 СИГНАЛЫ: всего %d | подтвердились за %d нед. %d (%.0f%%) | "
          "не подтвердились %d (ошибка первого рода %.0f%%)"
          % (len(sig), FWD, ok, 100 * ok / len(sig), len(sig) - ok,
             100 * (1 - ok / len(sig))))
    print("  ПРОПУСКИ: недель без сигнала %d, из них движение спреда выше медианы "
          "сигнальных %d (ошибка второго рода %.0f%%)"
          % (len(noise), miss, 100 * miss / len(noise) if noise else 0))
    print("  ПОСЛЕДНИЕ ВОСЕМЬ СИГНАЛОВ (спред лидер−аутсайдер за %d нед. вперёд):" % FWD)
    for s in sig[-8:]:
        print("    %s | %s (%s) − %s (%s) | %s п.п."
              % (s["дата"], RU[s["лидер"]], s["лидер"], RU[s["аутсайдер"]],
                 s["аутсайдер"], pct(s["спред_вперёд_4н"])))
    cont = st.median([s["спред_вперёд_4н"] for s in sig])
else:
    cont = 0.0
    print("\nR.2 СИГНАЛЫ: ни одного за историю панели")

# ---------- R.3 тепловая карта IR ----------
heat = [{"дата": r["date"], "ir": {t: round(r["ir"][t], 3) for t in SEC}}
        for r in rows[-HEAT:]]
print("\nR.3 ТЕПЛОВАЯ КАРТА: %d недельных срезов × %d секторов, %s → %s "
      "(в чат не печатается, идёт в график)"
      % (len(heat), len(SEC), heat[0]["дата"], heat[-1]["дата"]))

# ---------- R.4 факторный разрез ----------
cur = rows[-1]
i = cur["i"]
print("\nR.4 ФАКТОРЫ (окно %d дн., отклонение к S&P 500 и связь с раскладом секторов):" % W)
fac_out = {}
for t, name in FACT.items():
    if not fx[t] or any(fx[t][k] is None for k in range(i - W, i + 1)):
        print("  %-22s нет данных" % name)
        continue
    frel = fx[t][i] / fx[t][i - W] - 1.0 - (S["SPY"][i] / S["SPY"][i - W] - 1.0)
    exf = [(fx[t][k] / fx[t][k - 1] - 1.0) - (S["SPY"][k] / S["SPY"][k - 1] - 1.0)
           for k in range(i - W + 1, i + 1)]
    vf = st.pvariance(exf)
    load = {}
    for s in SEC:
        exs = [(S[s][k] / S[s][k - 1] - 1.0) - (S["SPY"][k] / S["SPY"][k - 1] - 1.0)
               for k in range(i - W + 1, i + 1)]
        load[s] = (sum(a * b for a, b in zip(exs, exf)) / len(exf) -
                   (sum(exs) / len(exs)) * (sum(exf) / len(exf))) / vf if vf > 0 else 0.0
    ra = sorted(SEC, key=lambda s: -cur["rel"][s])
    rb = sorted(SEC, key=lambda s: -load[s])
    n = len(SEC)
    dsq = sum((ra.index(s) - rb.index(s)) ** 2 for s in SEC)
    rho = 1 - 6 * dsq / (n * (n * n - 1))
    fac_out[t] = {"отклонение": frel, "связь": rho}
    print("  %-22s отклонение %s п.п. | связь с раскладом секторов %+.2f"
          % (name, pct(frel), rho))

# ---------- R.5 макро-фон ----------
print("\nR.5 МАКРО-ФОН:")
fred = {k: read_fred(k) for k in ("DGS10", "T10Y2Y", "DFF", "DTWEXBGS", "CFNAI", "ICSA")}
RUF = {"DGS10": "доходность 10 лет, %", "T10Y2Y": "наклон кривой 10−2, п.п.",
       "DFF": "ставка ФРС, %", "DTWEXBGS": "индекс доллара",
       "CFNAI": "индекс деловой активности ФРБ Чикаго", "ICSA": "первичные заявки, тыс."}
asof = dates[i]
d63 = dates[i - W]
macro = {}
for k, s in fred.items():
    if not s:
        print("  %-34s нет данных" % RUF[k])
        continue
    ds = sorted(d for d in s if d <= asof)
    if not ds:
        print("  %-34s нет данных" % RUF[k])
        continue
    last, lastd = s[ds[-1]], ds[-1]
    prev = [d for d in ds if d <= d63]
    ch = last - s[prev[-1]] if prev else None
    macro[k] = {"значение": last, "дата": lastd, "изменение_63д": ch}
    v = last / 1000.0 if k == "ICSA" else last
    print("  %-34s %8.2f  (на %s)%s" % (RUF[k], v, lastd,
          "" if ch is None else "  изменение за 63 дн. %+.2f" % (ch / 1000.0 if k == "ICSA" else ch)))

# состояние фона и похожие недели истории
def state(j):
    out = []
    for k in ("DGS10", "T10Y2Y", "DTWEXBGS"):
        s = fred.get(k) or {}
        ds = [d for d in sorted(s) if d <= dates[j]]
        dp = [d for d in sorted(s) if d <= dates[j - W]]
        if not ds or not dp:
            return None
        out.append(s[ds[-1]] - s[dp[-1]] if k != "T10Y2Y" else s[ds[-1]])
    return out


cur_state = state(i)
tilt_now = (sum(cur["rel"][t] for t in DEF) / len(DEF) -
            sum(cur["rel"][t] for t in CYC) / len(CYC))
if cur_state:
    hist = []
    for k in range(len(rows) - FWD):
        a = rows[k]
        s = state(a["i"])
        if not s:
            continue
        j = rows[k + FWD]["i"]
        fwd = (sum(S[t][j] / S[t][a["i"]] - 1 for t in DEF) / len(DEF) -
               sum(S[t][j] / S[t][a["i"]] - 1 for t in CYC) / len(CYC))
        hist.append((s, fwd))
    if len(hist) > NEAR:
        sd = [st.pstdev([h[0][c] for h in hist]) or 1.0 for c in range(3)]
        near = sorted(hist, key=lambda h: sum(((h[0][c] - cur_state[c]) / sd[c]) ** 2
                                              for c in range(3)))[:NEAR]
        avg = sum(h[1] for h in near) / len(near)
        agree = (avg > 0) == (tilt_now > 0)
        print("  ПОХОЖИЙ ФОН: %d ближайших недель истории по изменению доходности 10 лет, "
              "наклону кривой и доллару" % NEAR)
        print("  В них защитные сектора шли к циклическим на %s п.п. за %d нед. вперёд; "
              "сейчас перевес защитных %s п.п. → фон %s текущему раскладу"
              % (pct(avg), FWD, pct(tilt_now),
                 "СОГЛАСУЕТСЯ с" if agree else "ПРОТИВОРЕЧИТ"))
    else:
        agree, avg = None, None
        print("  ПОХОЖИЙ ФОН: истории мало")
else:
    agree, avg = None, None
    print("  ПОХОЖИЙ ФОН: нет данных")

# ---------- R.6 потоки и мультипликаторы SSGA ----------
print("\nR.6 ФОНДЫ SSGA (уровень активов и мультипликатор; поток считается только "
      "против приложенного снимка):")
ssga = {}
p = os.path.join(DATA, "ssga.xlsx")
if os.path.exists(p):
    try:
        import openpyxl

        def num(v):
            if v is None:
                return None
            s = str(v).replace(",", "").replace("$", "").strip()
            mult = 1.0
            if s.endswith(" M") or s.endswith("M"):
                s, mult = s.rstrip("M").strip(), 1e6
            elif s.endswith(" B") or s.endswith("B"):
                s, mult = s.rstrip("B").strip(), 1e9
            try:
                return float(s) * mult
            except ValueError:
                return None

        wb = openpyxl.load_workbook(p, data_only=True)
        for ws in wb.worksheets:
            head = None
            for row in ws.iter_rows(values_only=True):
                vals = [str(c).strip() if c is not None else "" for c in row]
                if head is None:
                    if "Ticker" in vals:
                        head = {v: n for n, v in enumerate(vals) if v}
                    continue
                tk = vals[head["Ticker"]].replace("®", "").strip().upper()
                if tk in SEC:
                    ssga[tk] = {
                        "паёв": num(row[head.get("Shares Outstanding", 0)]),
                        "чистые_активы": num(row[head.get("Total Net Assets", 0)]),
                        "pe": num(row[head.get("Price/Earnings Ratio FY1", 0)]),
                        "срез": vals[head.get("As of**", 0)]}
        if ssga:
            pes = {t: v["pe"] for t, v in ssga.items() if v.get("pe")}
            base = st.median(list(pes.values())) if pes else None
            for t in SEC:
                v = ssga.get(t)
                if not v:
                    continue
                rel_pe = ("%+.0f%%" % (100 * (v["pe"] / base - 1))) if v.get("pe") and base else "н/д"
                print("    %-26s паёв %s | активы %s | P/E %s | к медиане секторов %s"
                      % ("%s (%s)" % (RU[t], t),
                         "н/д" if not v["паёв"] else "%.1f млн" % (v["паёв"] / 1e6),
                         "н/д" if not v["чистые_активы"] else "%.1f млрд" % (v["чистые_активы"] / 1e9),
                         "н/д" if not v.get("pe") else "%.1f" % v["pe"], rel_pe))
            print("    СНИМОК ДЛЯ СЛЕДУЮЩЕГО ЦИКЛА: " +
                  json.dumps({t: round(v["паёв"] or 0) for t, v in sorted(ssga.items())},
                             ensure_ascii=False))
        else:
            print("    книга разобрана, секторных строк нет — нет данных")
    except Exception as e:
        print("    xlsx не разобран — нет данных (%s)" % e)
else:
    print("    файл не получен — нет данных")

# ---------- R.7 уровни по спреду ----------
L, A = cur["L"], cur["A"]
spread = [(S[L][k] / S[L][i - W] - 1.0) - (S[A][k] / S[A][i - W] - 1.0)
          for k in range(i - W, i + 1)]
dsp = [spread[k] - spread[k - 1] for k in range(1, len(spread))]
vol_d = st.pstdev(dsp) if len(dsp) > 1 else 0.0
vol_w = vol_d * math.sqrt(5)
volL = st.pstdev([S[L][k] / S[L][k - 1] - 1 for k in range(i - W + 1, i + 1)])
volA = st.pstdev([S[A][k] / S[A][k - 1] - 1 for k in range(i - W + 1, i + 1)])
EDGE = bool(sp) and sp.get("годовых", -1) > 0 and sp.get("доля_прибыльных", 0) > 0.5
print("\nR.7 УРОВНИ ПО СПРЕДУ %s−%s:" % (L, A))
if EDGE:
    print("  ЗАМОК ПРЕИМУЩЕСТВА: пройден (годовых %s%%, доля прибыльных %.0f%%) — "
          "уровни печатаются" % (pct(sp["годовых"]), 100 * sp["доля_прибыльных"]))
    print("  вход по закрытию недели сигнала: %s п.п. (текущий спред)" % pct(spread[-1]))
    print("  стоп: %s п.п. — две недельные сигмы спреда вниз (сигма %.2f п.п.)"
          % (pct(spread[-1] - 2 * vol_w), vol_w * 100))
    print("  цель: %s п.п. — медианное продолжение спреда за %d нед. после сигнала (%s п.п.)"
          % (pct(spread[-1] + cont), FWD, pct(cont)))
    print("  равный риск на ногу: на 1 доллара %s приходится %.2f доллара %s "
          "(отношение дневных волатильностей)" % (L, volL / volA if volA else 0, A))
else:
    print("  ЗАМОК ПРЕИМУЩЕСТВА: НЕ ПРОЙДЕН — на истории панели правило теряет деньги "
          "(годовых %s%%, доля прибыльных %.0f%%). Уровни входа, стопа и цели "
          "не печатаются: раздел выпуска сворачивается до строки о результате проверки."
          % (pct(sp.get("годовых", 0)), 100 * sp.get("доля_прибыльных", 0)))
print("  СПРАВКА РИСКА (печатается всегда): спред %s п.п., недельная сигма %.2f п.п., "
      "равный риск — на 1 доллара %s приходится %.2f доллара %s"
      % (pct(spread[-1]), vol_w * 100, L, volL / volA if volA else 0, A))

# ---------- R.8 оценка уверенности ----------
verd = []
for w in WINDOWS:
    if i - w < 0:
        continue
    _, _, dw, nw, tw, rw = snap(i, w)
    verd.append(rw)
agree_w = sum(1 for v in verd if v == cur["regime"])
c1 = 30.0 * (agree_w / len(verd)) if verd else 0.0
c2 = 20.0 * max(0.0, min(1.0, (NARROW_P80 - cur["narrow"]) / NARROW_P80))
wr = sp.get("доля_прибыльных")
c3 = 25.0 * max(0.0, min(1.0, (wr - 0.5) / 0.2)) if wr is not None else 0.0
c4 = 15.0 if agree is True else (0.0 if agree is False else 0.0)
c5 = 0.0
score = c1 + c2 + c3 + c4 + c5
LOG = Log(out=LOG_OUT, code="lead", cutoff=asof)
for _t, _ru in FACT.items():
    _p = read_prices(_t)
    # Файла факторного фонда может не быть: тогда это пробел с причиной,
    # а не остановка прогона.
    if _p:
        LOG.series("фактор_" + _ru.replace(" ", "_"), "Tiingo", max(_p), len(_p))
    else:
        LOG.gap("фактор_" + _ru.replace(" ", "_"), ["Tiingo:" + _t],
                "файл цен фонда не скачан")
for _key, _sid, _layer in (("доходность_10л", "DGS10", "быстрый"),
                           ("кривая_10л_2л", "T10Y2Y", "быстрый"),
                           ("ставка_фрс", "DFF", "быстрый"),
                           ("доллар", "DTWEXBGS", "медленный"),
                           ("деловая_активность", "CFNAI", "медленный"),
                           ("первичные_заявки", "ICSA", "медленный")):
    _r = read_fred(_sid)
    if _r:
        LOG.series(_key, "FRED " + _sid, max(_r), len(_r), layer=_layer)
    else:
        LOG.gap(_key, channels=["FRED " + _sid], reason="канал не отдал ряд")
if ssga:
    LOG.value("фонды_ssga", len(ssga), "книга фондов SSGA", asof, "секторов")
else:
    LOG.gap("фонды_ssga", channels=["книга фондов SSGA"], reason="таблица не распознана")
LOG.value("бэктест_правила", round(sp.get("годовых", 0) * 100, 1),
          "расчёт по панели секторных фондов", asof, "% годовых")
print("\nR.8 ОЦЕНКА УВЕРЕННОСТИ: %.0f из 100" % score)
LOG.value("уверенность", round(score), "расчёт по правилам раздела R", asof, "из 100")
print("  согласованность окон 42/63/84            %4.0f из 30 (совпало %d из %d)"
      % (c1, agree_w, len(verd)))
print("  запас по узости рынка                    %4.0f из 20" % c2)
print("  историческая доля прибыльных сделок      %4.0f из 25 (%.0f%%)"
      % (c3, 100 * wr if wr is not None else 0))
print("  согласие макро-фона                      %4.0f из 15" % c4)
print("  подтверждение потоками                   %4.0f из 10 (канал недоступен)" % c5)

# ---------- выгрузка для графиков ----------
bench = []
for k in range(len(rows) - 1):
    bench.append((rows[k + 1]["date"], S["SPY"][rows[k + 1]["i"]] / S["SPY"][rows[0]["i"]]))
json.dump({"heat": heat, "sectors": SEC, "RU": RU, "замок_преимущества": EDGE,
           "equity": run("spread")[1], "equity_long": run("long")[1],
           "equity_bench": bench,
           "factors": fac_out, "asof": dates[i], "score": score,
           "spread": {"L": L, "A": A, "уровни": [spread[-1],
                      spread[-1] - 2 * vol_w, spread[-1] + cont]}},
          open(os.path.join(OUT, "rdata.json"), "w"), ensure_ascii=False)
print("\nВЫГРУЗКА: rdata.json (тепловая карта, кривые стратегий, факторы, уровни)")

# --- журнал каналов прогона (гейт раздела S, скилл amin-data) ----------------
# В журнал идут ровно те величины, что напечатаны выше; пересчёта нет.
try:
    import sys as _sys
    _sys.path.insert(0, "/mnt/skills/user/amin-data/assets")
    from amin_run import Log as _Log
    _log = _Log(LOG_OUT)
    _asof = dates[i]
    _FKEY = {"MTUM": "фактор_моментум", "QUAL": "фактор_качество",
             "USMV": "фактор_низкая_волатильность", "VLUE": "фактор_стоимость"}
    for _t, _v in fac_out.items():
        _log.series(_FKEY[_t],
                    channel=f"Tiingo · {_t} · цены закрытия с поправкой на дивиденды и сплиты",
                    last_date=_asof, points=W, layer="быстрый")
        _log.value(_FKEY[_t], round(_v["отклонение"] * 100, 1),
                   f"Tiingo · {_t} · отклонение к S&P 500 за окно", _asof, "п.п.")
    _MKEY = {"DGS10": ("доходность_10л", "%", "быстрый"),
             "T10Y2Y": ("кривая_10л_2л", "п.п.", "быстрый"),
             "DFF": ("ставка_фрс", "%", "быстрый"),
             "DTWEXBGS": ("доллар", "индекс", "медленный"),
             "CFNAI": ("деловая_активность", "индекс", "медленный"),
             "ICSA": ("первичные_заявки", "тыс.", "медленный")}
    for _k, (_key, _unit, _layer) in _MKEY.items():
        _m = macro.get(_k)
        if not _m:
            _log.gap(_key, channels=["FRED"], reason="ряд не получен")
            continue
        _log.series(_key, channel=f"FRED · {_k}", last_date=_m["дата"], points=1, layer=_layer)
        _val = _m["значение"] / 1000.0 if _k == "ICSA" else _m["значение"]
        _log.value(_key, round(_val, 2), f"FRED · {_k}", _m["дата"], _unit)
    if ssga:
        _log.value("фонды_ssga", len(ssga),
                   "SSGA · книга данных фондов: паи, активы, мультипликатор",
                   _asof, "секторов", note="снимок на дату среза")
    else:
        _log.gap("фонды_ssga", channels=["SSGA"], reason="книга не разобрана")
    _log.value("бэктест_правила", round(sp.get("годовых", 0) * 100, 1),
               "скрипт R, блок R.1", _asof, "% годовых")
    _log.value("уверенность", score, "скрипт R, блок R.8", _asof, "из 100")
    print(f"ЖУРНАЛ КАНАЛОВ: факторы, макро-фон, фонды и величины проверки → {LOG_OUT}/channels.jsonl")
except Exception as _e:
    print(f"ЖУРНАЛ КАНАЛОВ: не записан — {_e}. Гейт раздела S остановит выдачу.")