#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""amin_run.py — общая инфраструктура прогона серии American Investor.
Реестр продуктов · cover()/slug() · журнал прогона · проверка перед выдачей.
Проверка ловит структурные ошибки; правдоподобное неверное значение — нет."""

import argparse, json, os, re, sys
import datetime as dt
import urllib.request, urllib.error, urllib.parse

REGISTRY = {
    "macro": {"name": "Макрорежим США", "period": "ежемесячно",
        "prompt": "AmIn_Monthly_US_Macro.md", "code": "macro",
        "minimum": ["ставка_фрс", "доходность_10л", "кривая_10л_2л", "инфляция_базовая",
            "занятость", "безработица", "премия_за_риск", "премия_за_волатильность",
            "чистая_ликвидность", "кредитная_премия", "широта_рынка", "vix",
            "доллар", "нефть", "золото", "потоки_в_фонды", "настроения",
            "пут_колл", "move", "просрочки", "нежилая_активность"]},
    "aicm": {"name": "Цикл сектора ИИ", "period": "ежемесячно",
        "prompt": "AmIn_Monthly_AI_Cycle_Monitor.md", "code": "aicm", "minimum": ["корзина_ма", "индекс_sox", "индекс_nasdaq", "широта_комплекса", "cds_oracle",
            "долг_neocloud", "спред_ig_tech", "облигации_сектора", "аренда_gpu",
            "сроки_поставки_gpu", "цены_hbm_dram", "мощности_дц", "инсайдеры", "плечо_ритейл",
            "ревизии_консенсуса", "короткие_продажи", "потоки_фондов", "перекос_опционов",
            "ставка_фрс", "vix", "доллар", "премия_за_срок", "экспортный_контроль",
            "rpo_google", "rpo_microsoft", "rpo_oracle", "рост_облаков", "tsmc",
            "риторика_кремний", "fcf", "капекс_к_ocf", "доля_долга_в_капексе",
            "качество_прибыли", "долг_к_ebitda", "доля_без_эффекта", "выручка_лабораторий",
            "openai", "отдача_на_капитал", "спрос_на_токены", "циркулярность_доля",
            "залог_gpu", "счётчик_вендорного", "forward_pe", "доля_mag7", "частные_оценки",
            "капекс_корзины", "разрыв_fcf", "индекс_циркулярности",
            "выручка_ии_против_капекса", "частный_кредит"]},
    "wlm": {"name": "Системная ликвидность", "period": "еженедельно",
        "prompt": "AmIn_Weekly_Liquidity_Monitor.md", "code": "wlm", "minimum": ["резервы", "резервы_к_ввп", "баланс_фрс", "tga", "rrp", "чистая_ликвидность", "sofr",
            "спред_sofr_iorb", "спред_effr_iorb", "перцентиль99_sofr", "srf", "доходность_10л",
            "vix", "hy_oas", "кредитный_прокси", "nfci", "sp500", "аукционы", "дилеры_fr2004",
            "маржинальный_долг", "mmf", "move", "дисконт_hyg", "gli"]},
    "flows": {"name": "Потоки в фонды", "period": "еженедельно",
        "prompt": "AmIn_Weekly_Fund_Flows.md", "code": "flows", "minimum": ["потоки_ici", "потоки_секторов", "потоки_стилей", "cot_плечевые", "cot_управляющие",
            "naaim", "aaii", "ритейл_сделки", "маржинальный_долг", "tic", "чистая_ликвидность",
            "tga", "rrp", "обратный_выкуп", "инсайдеры", "размещения", "mmf", "опционы_розница"]},
    "wpm": {"name": "Позиционирование участников", "period": "еженедельно",
        "prompt": "AmIn_Weekly_Positioning_Monitor.md", "code": "wpm", "minimum": []},
    "wsm": {"name": "Настроения рынка", "period": "еженедельно",
        "prompt": "AmIn_Weekly_Sentiment_Monitor.md", "code": "wsm", "minimum": []},
    "lead": {"name": "Ротация секторов", "period": "еженедельно",
        "prompt": "AmIn_Weekly_Leadership_Monitor.md", "code": "lead", "minimum": ["цены_xlk", "цены_xlf", "цены_xlv", "цены_xly", "цены_xlp", "цены_xle", "цены_xli",
            "цены_xlb", "цены_xlu", "цены_xlre", "цены_xlc", "цены_spy", "цены_rsp",
            "фактор_моментум", "фактор_качество", "фактор_низкая_волатильность",
            "фактор_стоимость", "доходность_10л", "кривая_10л_2л", "ставка_фрс", "доллар",
            "деловая_активность", "первичные_заявки", "фонды_ssga", "рассеяние_disp",
            "концентрация_narrow", "двусторонность", "ранжирование_секторов", "ir_секторов",
            "спред_лидер_аутсайдер", "устойчивость_окна", "бэктест_правила", "уверенность"]},
    "qeg": {"name": "Отчётность и прогнозы", "period": "квартально",
        "prompt": "AmIn_Quarterly_Earnings_Guidance.md", "code": "qeg",
        "minimum": ["прибыль_вперёд_ntm", "направление_пересмотров", "перекос_прогнозов",
            "доля_превысивших", "качество_прибыли", "ширина_без_топ10",
            "мультипликатор_и_премия", "источник_роста_индекса", "асимметрия_реакции",
            "кредитная_премия_hy", "опережающий_индикатор", "капекс_цикл"]},
    "credit": {"name": "Кредитный цикл", "period": "еженедельно",
        "prompt": "Amin_Weekly_Credit_Monitor.md", "code": "credit", "minimum": []},
    "mh": {"name": "Здоровье рынка", "period": "еженедельно",
        "prompt": "AmIn_Weekly_Market_Health.md", "code": "mh",
        "minimum": ["spy", "rsp", "iwm", "iwf", "iwd", "mtum", "qual", "usmv",
            "splv", "vlue", "sphb", "корзина_sp500", "состав_индекса",
            "dspx", "cor3m", "vix", "vvix", "доходность_10л", "доходность_2л",
            "индекс_доллара", "tlt", "ief", "gld", "uup", "ibit", "ashr",
            "ширина_выше_200", "ширина_выше_50", "новые_максимумы_минимумы",
            "разброс_21", "отношения_фондов", "vvix_к_vix", "score",
            "покрытие", "сценарные_развилки", "схожие_состояния",
            "кривая_волатильности"]},
    "deep-dive": {"name": "Разбор компании", "period": "разовый",
        "prompt": "AmIn_Company_Deep_Dive.md", "code": None, "minimum": []},
}

AUTHOR = "American Investor team & Solomon AI"
SUBTITLE = {"aicm": "Ежемесячный мониторинг цикла вложений в инфраструктуру ИИ",
            "qeg": "Ежеквартальный разбор сезона отчётности и прогнозов менеджмента"}


class RegistryError(Exception):
    """Неизвестный код продукта. Сборка обязана упасть, а не подставить строку."""


def product(code):
    if code not in REGISTRY:
        raise RegistryError("код продукта %r не найден в реестре; допустимые: %s"
                            % (code, ", ".join(sorted(REGISTRY))))
    return REGISTRY[code]


def cover(code, cutoff, extra=None):
    p = product(code)
    title = p["name"] if not extra else "%s · %s" % (p["name"], extra)
    return {"title": title, "subtitle": SUBTITLE.get(code, ""),
            "date": _date(cutoff).strftime("%d.%m.%Y"), "author": AUTHOR}


def slug(code, cutoff, extra=None):
    p = product(code)
    base = p["code"]
    if base is None:
        if not extra:
            raise RegistryError("продукт %r разовый: имя требует уточнения" % code)
        base = code
    parts = [base]
    if extra:
        parts.append(str(extra).strip().lower().replace(" ", "-"))
    parts.append(_date(cutoff).strftime("%Y-%m-%d"))
    return "-".join(parts)


def _date(v):
    if isinstance(v, dt.date):
        return v
    return dt.datetime.strptime(str(v)[:10], "%Y-%m-%d").date()


STATE_URL = "https://www.americaninvestor.capital/api/state/"
CALC_URL = "https://www.americaninvestor.capital/api/calc"
STATE_TOKEN_VARS = ("AMIN_STATE_TOKEN", "INDICATOR_TOKEN")
CALC_NAME_RX = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}\.(py|sh|js)$")


class CalcError(Exception):
    """Расчётный модуль не пришёл из хранилища или пришёл испорченным.
    Считать по копии из установленного набора запрещено: копия стареет и
    возвращает уже исправленные ошибки — ради этого модули и переехали на
    сервер."""


def _calc_request(url, data=None, timeout=60):
    req = urllib.request.Request(url)
    req.add_header("Authorization", "Bearer " + _state_token())
    req.add_header("User-Agent", "AmIn-run/1.0")
    if data is not None:
        req.data = data
        req.add_header("Content-Type", "text/plain; charset=utf-8")
        req.get_method = lambda: "POST"
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            # Имена заголовков приводятся к строчным: сервер отдаёт отпечаток
            # как `x-amin-sha256`, а обычный словарь регистр не прощает — модуль
            # читался как «пришедший без отпечатка» и прогон вставал.
            return r.read(), {k.lower(): v for k, v in r.headers.items()}, 200
    except urllib.error.HTTPError as e:
        body = b""
        try:
            body = e.read()
        except Exception:
            pass
        return body, {}, e.code
    except Exception as e:
        raise CalcError("хранилище модулей недоступно: %s" % e)


def _sha256(raw):
    import hashlib
    return hashlib.sha256(raw).hexdigest()


def calc_list():
    """Опись модулей в хранилище: имя, отпечаток, размер, дата записи."""
    body, _h, status = _calc_request(CALC_URL)
    if status == 401:
        raise CalcError("хранилище не пустило: секрет неверен или отозван")
    if status != 200:
        raise CalcError("чтение описи модулей: код %s, ответ %s"
                        % (status, body[:200].decode("utf-8", "replace")))
    return json.loads(body.decode("utf-8")).get("files") or []


def calc_get(name, dest="."):
    """Забрать модуль из хранилища в каталог `dest` и сверить отпечаток.

    Отпечаток считает сервер при записи и отдаёт заголовком; здесь он
    считается заново по полученным байтам. Расхождение — CalcError: прогон
    останавливается, а не запускает неизвестно что."""
    if not CALC_NAME_RX.match(str(name)):
        raise CalcError("имя модуля %r не разбирается" % name)
    body, head, status = _calc_request(CALC_URL + "/" + name)
    if status == 404:
        raise CalcError("модуля %r в хранилище нет" % name)
    if status == 401:
        raise CalcError("хранилище не пустило: секрет неверен или отозван")
    if status != 200:
        raise CalcError("чтение модуля %r: код %s" % (name, status))
    want = (head.get("x-amin-sha256") or "").strip().lower()
    got = _sha256(body)
    if not want:
        raise CalcError("модуль %r пришёл без отпечатка — запись в хранилище "
                        "неполная, запускать нельзя" % name)
    if want != got:
        raise CalcError("отпечаток модуля %r не сошёлся: в хранилище %s, "
                        "у полученного файла %s" % (name, want[:12], got[:12]))
    os.makedirs(dest, exist_ok=True)
    path = os.path.join(dest, name)
    with open(path, "wb") as fh:
        fh.write(body)
    if name.endswith(".sh"):
        os.chmod(path, 0o755)
    return path


def calc_put(path, name=None):
    """Положить модуль в хранилище. Отпечаток считает сервер и возвращает его;
    здесь он сверяется с отпечатком отправленного файла."""
    name = name or os.path.basename(path)
    if not CALC_NAME_RX.match(str(name)):
        raise CalcError("имя модуля %r не разбирается" % name)
    with open(path, "rb") as fh:
        raw = fh.read()
    if not raw:
        raise CalcError("файл %r пуст" % path)
    body, _h, status = _calc_request(CALC_URL + "/" + name, data=raw)
    if status != 200:
        raise CalcError("запись модуля %r: код %s, ответ %s"
                        % (name, status, body[:200].decode("utf-8", "replace")))
    got = json.loads(body.decode("utf-8"))
    if got.get("sha256") != _sha256(raw):
        raise CalcError("хранилище записало модуль %r с другим отпечатком" % name)
    return got


def calc_sync(dest=".", names=None):
    """Забрать из хранилища все модули описи (или названные) и сверить каждый.
    Возвращает список путей. Это первый шаг прогона: код берётся с сервера, а
    не из установленного набора."""
    свой = os.path.basename(__file__)
    if names:
        want = list(names)
    else:
        # Хозяин этого файла — установленный набор: им забираются все
        # остальные, и подменять его редакцией из хранилища нельзя. Экземпляр
        # в хранилище держится запасной копией и синхронизацией не берётся.
        want = [f["name"] for f in calc_list() if f["name"] != свой]
    return [calc_get(n, dest) for n in want]


class StateError(Exception):
    """Хранилище состояния недоступно. Считать по копии из промпта запрещено:
    копия справочная и стареет, расхождение решается в пользу хранилища."""


def _state_token():
    # Переменная окружения главнее файла: рутина с расписанием задаёт секрет
    # переменной и продолжает работать без правок.
    for name in STATE_TOKEN_VARS:
        v = os.environ.get(name)
        if v:
            return v.strip()
    token_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "state-token")
    try:
        with open(token_file, encoding="utf-8") as fh:
            v = fh.read().strip()
        if v:
            return v
    except OSError:
        pass
    raise StateError("секрет хранилища не задан: положить его в переменную окружения %s "
                     "или файлом assets/state-token рядом с amin_run.py"
                     % " или ".join(STATE_TOKEN_VARS))


def state_key(code, ticker=None):
    """Ключ хранилища. Регулярный продукт хранит одно состояние на продукт, и
    ключ равен коду. Разовый продукт («Разбор компании», «Второе мнение»)
    сравнивает выпуск не с прошлым выпуском продукта, а с прошлым выпуском ПО
    ТОМУ ЖЕ ЭМИТЕНТУ, поэтому ключ несёт тикер: deep-dive-goog, deep-dive-msft.
    Решение издателя 13.08.2026 — снимок ушёл из выпуска в хранилище."""
    if not ticker:
        return code
    t = re.sub(r"[^a-z0-9.]", "", str(ticker).strip().lower())
    if not t:
        raise RegistryError("тикер %r пуст после очистки" % ticker)
    return "%s-%s" % (code, t)


def _base_code(key):
    """Код продукта из ключа хранилища: deep-dive-goog → deep-dive."""
    if key in REGISTRY:
        return key
    base, _, _t = key.rpartition("-")
    if base in REGISTRY:
        return base
    raise RegistryError("ключ состояния %r не разбирается: ни код продукта, "
                        "ни пара «код-тикер»" % key)


def _state_call(code, payload=None, timeout=20, params=None):
    _base_code(code)                    # неизвестный ключ падает здесь, а не на сервере
    url = STATE_URL + code
    if params:
        url += "?" + urllib.parse.urlencode({k: v for k, v in params.items() if v})
    req = urllib.request.Request(url)
    req.add_header("Authorization", "Bearer " + _state_token())
    # Заголовок обязателен: защита сайта отвечает 403 (error code 1010) на
    # обращение без него — прогон получал бы отказ вместо состояния.
    req.add_header("User-Agent", "AmIn-run/1.0")
    if payload is not None:
        req.data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req.add_header("Content-Type", "application/json")
        req.get_method = lambda: "POST"
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8")), 200
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8")
        except Exception:
            pass
        return body, e.code
    except Exception as e:
        raise StateError("хранилище недоступно: %s" % e)


def _state_read(code, params=None, what="состояния"):
    """Общий разбор ответа хранилища. 404 → None (штатный исход первого цикла),
    401 → отозванный секрет, прочее → остановка прогона."""
    data, status = _state_call(code, params=params)
    if status == 200:
        return data
    if status == 404:
        return None
    if status == 401:
        raise StateError("хранилище не пустило: секрет неверен или отозван")
    raise StateError("чтение %s %r: код %s, ответ %s" % (what, code, status, data))


def _unwrap(st):
    # Метка пустоты: у хранилища нет удаления, поэтому очистка записывается
    # как {"пусто": true} и читается так же, как отсутствие состояния.
    if isinstance(st, dict) and st.get("пусто") is True:
        return None
    return st


def state_get(code):
    """Состояние прошлого прогона — самый свежий снимок продукта.
    Первый цикл (404) → None, это штатный исход. Любой другой отказ —
    StateError: прогон останавливается, а не считает вслепую."""
    data = _state_read(code)
    return None if data is None else _unwrap(data.get("state"))


def state_at(code, issued):
    """Снимок КОНКРЕТНОГО выпуска продукта по дате выпуска. Снимка нет → None."""
    _check_date(issued)
    data = _state_read(code, {"at": issued}, "снимка")
    return None if data is None else _unwrap(data.get("state"))


def state_history(code, frm=None, to=None, limit=None):
    """Все снимки продукта, свежие первыми: список записей
    {"issued_at": дата, "updated_at": дата, "state": снимок}.

    Ради этого списка и заведена подпись снимка датой (правка 14.08.2026):
    показатель, у которого первоисточник не отдаёт истории, копится только
    здесь — от выпуска к выпуску."""
    for d in (frm, to):
        if d:
            _check_date(d)
    params = {"history": "1", "from": frm, "to": to,
              "limit": str(limit) if limit else None}
    data = _state_read(code, params, "истории снимков")
    if data is None:
        return []
    return data.get("history") or []


def state_series(code, path, frm=None, to=None):
    """Ряд одного показателя по истории снимков: список пар (дата, значение),
    старые первыми. path — ключ снимка либо путь через точку:
    "разрывы.ccc_минус_bb". Снимок без этого ключа в ряд не попадает —
    пропуск не подставляется."""
    keys = str(path).split(".")
    out = []
    for rec in state_history(code, frm, to):
        node = _unwrap(rec.get("state"))
        for k in keys:
            if not isinstance(node, dict) or k not in node:
                node = None
                break
            node = node[k]
        if node is not None:
            out.append((rec.get("issued_at"), node))
    return sorted(out)


def _check_date(v):
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", str(v)):
        raise StateError("дата выпуска %r не вида ГГГГ-ММ-ДД" % v)


def state_put(code, state, issued=None):
    """Записать состояние после выдачи выпуска. Возвращает True при успехе.

    С датой выпуска строка не затирает прошлые — снимки копятся, и по ним
    строится ряд показателя. Без даты хранилище ведёт себя как прежде:
    одна строка на продукт, перезапись."""
    body = {"state": state}
    if issued:
        _check_date(issued)
        body["issued_at"] = str(issued)[:10]
    data, status = _state_call(code, body)
    if status == 200:
        return True
    raise StateError("запись состояния %r: код %s, ответ %s" % (code, status, data))


class Log(object):
    """Журнал источников: строка JSON на событие в out/channels.jsonl."""

    def __init__(self, out="out", code=None, cutoff=None):
        self.dir = out
        self.path = os.path.join(out, "channels.jsonl")
        self.code = code
        self.cutoff = str(cutoff)[:10] if cutoff else None
        os.makedirs(out, exist_ok=True)
        open(self.path, "a").close()

    def _w(self, rec):
        rec["ts"] = dt.datetime.now().isoformat(timespec="seconds")
        if self.code:
            rec["продукт"] = self.code
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return rec

    def get(self, channel, url="", ok=True, note=""):
        return self._w({"вид": "обращение", "канал": channel, "адрес": url,
                        "успех": bool(ok), "пометка": note})

    def series(self, key, channel, last_date="", points=0, note="", layer="быстрый"):
        # слой: быстрый (день/неделя) или медленный (месяц/квартал). Порог свежести
        # применяется только к быстрому слою: месячная серия отстаёт по определению.
        return self._w({"вид": "ряд", "показатель": key, "канал": channel,
                        "последняя_дата": str(last_date)[:10], "слой": layer,
                        "точек": int(points), "пометка": note})

    def value(self, key, value, source, date, unit="", note=""):
        return self._w({"вид": "значение", "показатель": key, "значение": value,
                        "источник": source, "дата": str(date)[:10],
                        "единица": unit, "пометка": note})

    def gap(self, key, channels=(), reason=""):
        return self._w({"вид": "пробел", "показатель": key,
                        "опрошено": list(channels), "причина": reason})

    def note(self, text):
        return self._w({"вид": "пометка", "текст": text})

    @staticmethod
    def read(out="out"):
        p = os.path.join(out, "channels.jsonl")
        if not os.path.exists(p):
            return []
        recs = []
        for line in open(p, encoding="utf-8"):
            line = line.strip()
            if line:
                try:
                    recs.append(json.loads(line))
                except ValueError:
                    pass
        return recs


def _walk(node, path=""):
    if isinstance(node, dict):
        for k, v in node.items():
            for pair in _walk(v, path + "/" + str(k)):
                yield pair
    elif isinstance(node, list):
        for i, v in enumerate(node):
            for pair in _walk(v, path + "/%d" % i):
                yield pair
    else:
        yield path, node


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def check(code, title=None, cutoff=None, out="out", calc=None, strict_days=2,
          deliver="/mnt/user-data/outputs", stage="full"):
    """Возвращает список дефектов. Пустой список = прогон чист."""
    bad = []
    p = product(code)
    recs = Log.read(out)

    if title is not None and title.strip() != p["name"]:
        bad.append("заголовок обложки %r не совпадает с реестром (%r)"
                   % (title.strip(), p["name"]))
    if not recs:
        bad.append("журнал прогона пуст: out/channels.jsonl не содержит записей")

    logged, got, gaps = set(), set(), {}
    for r in recs:
        k = r.get("показатель")
        if r.get("вид") in ("ряд", "значение") and k:
            logged.add(k); got.add(k)
        if r.get("вид") == "пробел" and k:
            logged.add(k); gaps[k] = r

    for k in p["minimum"]:
        if k not in logged:
            bad.append("обязательный показатель %r не появился в журнале — тихий пропуск" % k)
    for k, r in gaps.items():
        if not r.get("опрошено"):
            bad.append("пробел по %r объявлен без опроса каналов" % k)
        if k in got:
            bad.append("показатель %r объявлен пробелом, хотя по нему есть данные" % k)

    if cutoff:
        cut = _date(cutoff)
        last_by_key = {}
        for r in recs:
            if r.get("вид") != "ряд" or not r.get("последняя_дата"):
                continue
            last_by_key[r.get("показатель")] = r
        for key, r in last_by_key.items():
            # порог свежести — только для быстрого слоя: месячная серия
            # отстаёт по определению, и это не нарушение
            if r.get("слой", "быстрый") != "быстрый":
                continue
            try:
                last = _date(r["последняя_дата"])
            except Exception:
                continue
            days = _trading_days(last, cut)
            note = r.get("пометка") or ""
            if days > strict_days and "снимок" not in note and "замена" not in note:
                bad.append("ряд %r отстаёт на %d торговых дня(ей) (последняя точка %s) "
                           "без снимка и без записанной замены"
                           % (key, days, r["последняя_дата"]))

    # Формат доставки. У прогона две остановки: ночная задача доводит выпуск до
    # текста и отдаёт один файл разметки, а вёрстка идёт отдельным ходом после
    # правки издателем. Поэтому на шаге "text" ждём текст, на шаге "full" —
    # пару файлов, и черновик разметки вместо пары ловим как дефект.
    if cutoff and stage == "text":
        base  = slug(code, cutoff)
        draft = os.path.join(deliver, base + ".md")
        if not os.path.exists(draft):
            bad.append("нет файла текста %s — выпуск не написан" % (base + ".md"))
    if cutoff and stage == "full":
        base = slug(code, cutoff)
        pdf = os.path.join(deliver, base + ".pdf")
        htm = os.path.join(deliver, base + ".summary.html")
        if not os.path.exists(pdf):
            bad.append("нет файла доставки %s — выпуск не собран" % (base + ".pdf"))
        if not os.path.exists(htm):
            bad.append("нет файла доставки %s — краткая версия не собрана" % (base + ".summary.html"))
        draft = os.path.join(deliver, base + ".md")
        if os.path.exists(draft) and not os.path.exists(pdf):
            bad.append("в каталоге выдачи лежит черновик %s вместо пары файлов" % (base + ".md"))

    if calc and os.path.exists(calc):
        bad += _check_calc(json.load(open(calc, encoding="utf-8")))
    return bad


def _trading_days(a, b):
    if b <= a:
        return 0
    n, d = 0, a
    while d < b:
        d += dt.timedelta(days=1)
        if d.weekday() < 5:
            n += 1
    return n


def _check_calc(data):
    bad = []
    for node, path in _blocks(data):
        p25, p50, p75 = node.get("p25"), node.get("p50"), node.get("p75")
        if _num(p25) and _num(p50) and _num(p75):
            if p25 == p50 == p75:
                bad.append("%s: перцентили схлопнулись (p25=p50=p75=%s) — признак "
                           "ошибки guard'а по датам" % (path, p25))
            if p25 > p75:
                bad.append("%s: p25 (%s) больше p75 (%s)" % (path, p25, p75))
        n = node.get("n")
        if _num(n) and n < 5 and any(_num(node.get(x)) for x in ("p25", "p50", "p75", "медиана")):
            bad.append("%s: агрегат построен при n=%s (< 5) — должна печататься "
                       "поэпизодная таблица" % (path, n))
    for path, v in _walk(data):
        low = path.lower()
        if not _num(v):
            continue
        if low.endswith("/z") or "/z_" in low or low.endswith("_z"):
            if abs(v) > 6:
                bad.append("%s: |Z| = %.2f, невозможное значение" % (path, v))
        if "доля" in low or "процент" in low or "покрытие" in low:
            if isinstance(v, float) and (v < -100 or v > 100):
                bad.append("%s: доля вне диапазона (%s)" % (path, v))
    sc = _find(data, "сценарии")
    if isinstance(sc, dict):
        s = sum(v for v in sc.values() if _num(v))
        if s and abs(s - 100) > 0.5:
            bad.append("сумма весов сценариев %.1f, требуется 100" % s)
    return bad


def _blocks(node, path=""):
    if isinstance(node, dict):
        if any(k in node for k in ("p25", "p50", "p75", "n")):
            yield node, path or "/"
        for k, v in node.items():
            for pair in _blocks(v, path + "/" + str(k)):
                yield pair
    elif isinstance(node, list):
        for i, v in enumerate(node):
            for pair in _blocks(v, path + "/%d" % i):
                yield pair


def _find(node, key):
    if isinstance(node, dict):
        if key in node:
            return node[key]
        for v in node.values():
            r = _find(v, key)
            if r is not None:
                return r
    elif isinstance(node, list):
        for v in node:
            r = _find(v, key)
            if r is not None:
                return r
    return None


def _skills_check():
    """Сверка редакций установленных скиллов. Список расхождений (пустой — всё
    сошлось) либо None, когда сверка не состоялась и прогон обязан встать."""
    try:
        import skills_print
    except ImportError:
        здесь = os.path.dirname(os.path.abspath(__file__))
        if здесь not in sys.path:
            sys.path.insert(0, здесь)
        try:
            import skills_print
        except ImportError:
            print("СТОП: модуль skills_print не найден рядом с amin_run.py — "
                  "сверить редакции скиллов нечем")
            return None
    try:
        return skills_print.сверить(печатать=False)
    except skills_print.ОтпечатокError as e:
        print("СТОП: %s" % e)
        return None


def _passport_check(code, out):
    """Сверка выпуска с паспортом промпта. Список расхождений либо None, когда
    сверка не состоялась и прогон обязан встать."""
    здесь = os.path.dirname(os.path.abspath(__file__))
    if здесь not in sys.path:
        sys.path.insert(0, здесь)
    try:
        import issue_check
    except ImportError:
        print("СТОП: модуль issue_check не найден рядом с amin_run.py — "
              "сверить выпуск с паспортом нечем")
        return None
    try:
        return issue_check.сверить(code, out, печатать=False)
    except issue_check.ПаспортError as e:
        print("СТОП: %s" % e)
        return None


def main():
    ap = argparse.ArgumentParser(description="Проверка прогона перед выдачей")
    ap.add_argument("--code"); ap.add_argument("--title"); ap.add_argument("--cutoff")
    ap.add_argument("--out", default="out"); ap.add_argument("--calc", default=None)
    ap.add_argument("--extra", default=None)
    ap.add_argument("--slug", action="store_true"); ap.add_argument("--list", action="store_true")
    ap.add_argument("--ticker", default=None,
                    help="тикер для разового продукта: ключ станет <код>-<тикер>")
    ap.add_argument("--state-get", action="store_true",
                    help="напечатать состояние прошлого прогона (JSON) и выйти")
    ap.add_argument("--state-put", metavar="ФАЙЛ",
                    help="записать состояние из файла JSON и выйти")
    ap.add_argument("--issued", metavar="ГГГГ-ММ-ДД",
                    help="дата выпуска: снимок подписывается ею и не затирает прошлые")
    ap.add_argument("--state-at", metavar="ГГГГ-ММ-ДД",
                    help="напечатать снимок конкретного выпуска и выйти")
    ap.add_argument("--state-history", action="store_true",
                    help="напечатать список снимков продукта, свежие первыми")
    ap.add_argument("--state-series", metavar="КЛЮЧ",
                    help="напечатать ряд одного показателя по истории снимков; "
                         "путь через точку: разрывы.ccc_минус_bb")
    ap.add_argument("--from", dest="frm", metavar="ГГГГ-ММ-ДД",
                    help="нижняя граница даты выпуска для истории и ряда")
    ap.add_argument("--to", metavar="ГГГГ-ММ-ДД",
                    help="верхняя граница даты выпуска для истории и ряда")
    ap.add_argument("--limit", type=int, default=None,
                    help="сколько снимков вернуть в истории")
    ap.add_argument("--calc-list", action="store_true",
                    help="напечатать опись расчётных модулей хранилища и выйти")
    ap.add_argument("--calc-get", metavar="ИМЯ",
                    help="забрать модуль из хранилища со сверкой отпечатка")
    ap.add_argument("--calc-put", metavar="ФАЙЛ",
                    help="положить модуль в хранилище")
    ap.add_argument("--calc-sync", action="store_true",
                    help="забрать из хранилища все модули описи со сверкой отпечатков")
    ap.add_argument("--stage", choices=["full", "text"], default="full",
                    help="что проверяем: full — пару файлов выпуска, "
                         "text — текст выпуска до вёрстки")
    ap.add_argument("--dest", default=".",
                    help="куда класть забранные модули (по умолчанию рабочий каталог)")
    a = ap.parse_args()

    # Работа с хранилищем модулей кода продукта не требует.
    if a.calc_list:
        try:
            files = calc_list()
        except CalcError as e:
            print("СТОП: %s" % e); return 2
        if not files:
            print("ХРАНИЛИЩЕ МОДУЛЕЙ ПУСТО: ни один расчёт ещё не положен")
            return 0
        for f in files:
            print("%-24s %8s Б  %s  записан %s"
                  % (f.get("name"), f.get("size"),
                     (f.get("sha256") or "")[:12], f.get("updated_at")))
        print("модулей: %d" % len(files)); return 0
    if a.calc_get:
        try:
            print("взят и сверен: %s" % calc_get(a.calc_get, a.dest))
        except CalcError as e:
            print("СТОП: %s" % e); return 2
        return 0
    if a.calc_put:
        try:
            got = calc_put(a.calc_put)
        except CalcError as e:
            print("СТОП: %s" % e); return 2
        print("записан: %s · отпечаток %s · %s Б"
              % (got.get("name"), (got.get("sha256") or "")[:12], got.get("size")))
        return 0
    if a.calc_sync:
        try:
            paths = calc_sync(a.dest)
        except CalcError as e:
            print("СТОП: %s" % e); return 2
        for p in paths:
            print("взят и сверен: %s" % p)
        print("модулей: %d" % len(paths)); return 0

    if a.list:
        for k in sorted(REGISTRY):
            r = REGISTRY[k]
            print("%-12s %-28s %-12s %s" % (k, r["name"], r["period"], r["prompt"]))
        return 0
    if not a.code:
        ap.error("нужен --code")
    if a.slug:
        print(slug(a.code, a.cutoff, a.extra)); return 0
    if a.state_get:
        try:
            st = state_get(state_key(a.code, a.ticker))
        except StateError as e:
            print("СТОП: %s" % e); return 2
        if st is None:
            print("СОСТОЯНИЯ НЕТ: первый цикл продукта — сравнение с прошлым срезом не строится")
            return 0
        print(json.dumps(st, ensure_ascii=False, indent=1)); return 0
    if a.state_at:
        try:
            st = state_at(state_key(a.code, a.ticker), a.state_at)
        except StateError as e:
            print("СТОП: %s" % e); return 2
        if st is None:
            print("СНИМКА НА ЭТУ ДАТУ НЕТ"); return 0
        print(json.dumps(st, ensure_ascii=False, indent=1)); return 0
    if a.state_history:
        try:
            recs = state_history(state_key(a.code, a.ticker), a.frm, a.to, a.limit)
        except StateError as e:
            print("СТОП: %s" % e); return 2
        if not recs:
            print("ИСТОРИИ СНИМКОВ НЕТ: продукт ещё не писал снимки с датой выпуска")
            return 0
        for r in recs:
            print("%s  записан %s  ключей %d"
                  % (r.get("issued_at"), r.get("updated_at"),
                     len(r.get("state") or {}) if isinstance(r.get("state"), dict) else 0))
        print("снимков: %d" % len(recs)); return 0
    if a.state_series:
        try:
            ser = state_series(state_key(a.code, a.ticker), a.state_series, a.frm, a.to)
        except StateError as e:
            print("СТОП: %s" % e); return 2
        if not ser:
            print("РЯДА НЕТ: показателя %r нет ни в одном снимке продукта" % a.state_series)
            return 0
        for d, v in ser:
            print("%s\t%s" % (d, json.dumps(v, ensure_ascii=False)
                              if isinstance(v, (dict, list)) else v))
        print("точек: %d" % len(ser)); return 0
    if a.state_put:
        try:
            body = json.load(open(a.state_put, encoding="utf-8"))
            issued = a.issued or body.get("issued_at")
            state_put(state_key(a.code, a.ticker), body.get("state", body), issued)
        except StateError as e:
            print("СТОП: %s" % e); return 2
        print("Состояние записано: %s%s" % (state_key(a.code, a.ticker),
                                            ("@" + issued) if issued else ""))
        return 0

    # Сторож редакции: скилл на машине издателя мог остаться прежним, и тогда
    # прогон исполняет старые правила, ничего об этом не говоря. Сверка стоит
    # ПЕРЕД проверкой выпуска и падает вместе с ней.
    расхождения = _skills_check()
    if расхождения is None:
        return 2
    if расхождения:
        print("ПРОВЕРКА НЕ ПРОЙДЕНА: установлены не те редакции скиллов")
        for имя, было, стало in расхождения:
            print("  x %s: ожидается %s, установлена %s" % (имя, было, стало))
        print("Файлы не отдаются. Поставьте свежие скиллы либо объявите "
              "текущие редакции ожидаемыми: python3 skills_print.py --записать")
        return 1

    # Паспорт выпуска: промпт объявил состав, прогон его собрал. Сверка идёт
    # там, где рядом лежит файл данных выпуска; продукты, ещё не переведённые
    # на общий сборщик, её не касаются.
    if os.path.isfile(os.path.join(a.out, "issue.json")):
        разошлось = _passport_check(a.code, a.out)
        if разошлось is None:
            return 2
        if разошлось:
            print("ПРОВЕРКА НЕ ПРОЙДЕНА: выпуск разошёлся с паспортом промпта")
            for р in разошлось:
                print("  x " + р)
            print("Файлы не отдаются.")
            return 1

    calc = a.calc or os.path.join(a.out, "calc.json")
    bad = check(a.code, a.title, a.cutoff, a.out, calc, stage=a.stage)
    if bad:
        print("ПРОВЕРКА НЕ ПРОЙДЕНА, дефектов: %d" % len(bad))
        for b in bad:
            print("  x " + b)
        print("Файлы не отдаются. Обходить проверку и править её пороги "
              "под конкретный выпуск запрещено.")
        return 1
    print("Проверка пройдена: %s · %s" % (product(a.code)["name"],
                                          slug(a.code, a.cutoff, a.extra)))
    print("Напоминание: структурные ошибки проверка ловит, правдоподобное "
          "неверное значение — нет.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
