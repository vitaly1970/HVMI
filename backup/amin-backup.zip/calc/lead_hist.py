#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""lead_hist.py — история расклада секторов для раздела «Как менялся расклад».

Считает по тем же CSV, что разделы E и R:
  * для каждого из последних четырёх кварталов — лидер, аутсайдер и разрыв
    между ними в процентах на последний торговый день квартала (окно 63 дня,
    как в разделе E);
  * недельный ряд разрыва лидер — аутсайдер за год с отметками смены лидера.

Своей интерпретации нет: величины считаются той же формулой, что в разделе E
(относительная доходность сектора к S&P 500 за 63 торговых дня).
"""
import csv, json, os, sys, datetime as dt

sys.path.insert(0, "/mnt/skills/user/amin-data/assets")
from amin_run import Log

DATA = "/home/claude/data"
LOG_OUT = os.environ.get("RUN_OUT", "out")
SEC = ["XLK", "XLF", "XLV", "XLY", "XLP", "XLE", "XLI", "XLB", "XLU", "XLRE", "XLC"]
RU = {"XLK": "Технологии", "XLF": "Финансы", "XLV": "Здравоохранение",
      "XLY": "Товары длительного спроса", "XLP": "Товары повседневного спроса",
      "XLE": "Энергетика", "XLI": "Промышленность", "XLB": "Материалы",
      "XLU": "Коммунальные услуги", "XLRE": "Недвижимость", "XLC": "Коммуникации"}
W = 63
QUARTERS = 4
YEAR_WEEKS = 53

LOG = Log(LOG_OUT)


def series(t):
    rows = {}
    with open(os.path.join(DATA, t + ".csv")) as f:
        rd = csv.DictReader(f)
        for r in rd:
            try:
                rows[r["date"][:10]] = float(r["adjClose"])
            except (TypeError, ValueError):
                continue
    return rows


px = {t: series(t) for t in SEC + ["SPY"]}
dates = sorted(set(px["SPY"]).intersection(*[set(px[t]) for t in SEC]))


def rel(t, i):
    """Относительная доходность сектора к S&P 500 за окно W, доли единицы."""
    d0, d1 = dates[i - W], dates[i]
    s = px[t][d1] / px[t][d0] - 1
    b = px["SPY"][d1] / px["SPY"][d0] - 1
    return s - b


def rank_at(i):
    r = sorted(((t, rel(t, i)) for t in SEC), key=lambda x: -x[1])
    return r


def q_label(d):
    y, m = int(d[:4]), int(d[5:7])
    q = (m - 1) // 3 + 1
    return "%s кв. %d" % (["I", "II", "III", "IV"][q - 1], y)


# --- последние точки календарных кварталов ---
ends = {}
for i, d in enumerate(dates):
    if i < W:
        continue
    ends[(d[:4], (int(d[5:7]) - 1) // 3)] = i
keys = sorted(ends)
cur = (dates[-1][:4], (int(dates[-1][5:7]) - 1) // 3)
keys = [k for k in keys if k != cur]
rows = []
for k in keys[-(QUARTERS - 1):]:
    i = ends[k]
    r = rank_at(i)
    rows.append({"метка": q_label(dates[i]), "дата": dates[i],
                 "лидер": r[0][0], "лидер_%": round(r[0][1] * 100, 1),
                 "аутсайдер": r[-1][0], "аутсайдер_%": round(r[-1][1] * 100, 1),
                 "разрыв": round((r[0][1] - r[-1][1]) * 100, 1)})
i = len(dates) - 1
r = rank_at(i)
rows.append({"метка": "Сейчас", "дата": dates[i],
             "лидер": r[0][0], "лидер_%": round(r[0][1] * 100, 1),
             "аутсайдер": r[-1][0], "аутсайдер_%": round(r[-1][1] * 100, 1),
             "разрыв": round((r[0][1] - r[-1][1]) * 100, 1)})

print("ИСТОРИЯ РАСКЛАДА (окно 63 дн., отклонение к S&P 500):")
for x in rows:
    print("  %-12s %s | лидер %s %+.1f%% | аутсайдер %s %+.1f%% | разрыв %.1f%%"
          % (x["метка"], x["дата"], RU[x["лидер"]], x["лидер_%"],
             RU[x["аутсайдер"]], x["аутсайдер_%"], x["разрыв"]))

# --- недельный ряд разрыва за год ---
weekly = []
idx = [i for i in range(W, len(dates))]
last = None
for i in idx:
    d = dates[i]
    wk = dt.date(int(d[:4]), int(d[5:7]), int(d[8:10])).isocalendar()[:2]
    if wk != last:
        if last is not None:
            weekly.append(prev_i)
        last = wk
    prev_i = i
weekly.append(idx[-1])
weekly = weekly[-YEAR_WEEKS:]

ser = []
for i in weekly:
    r = rank_at(i)
    ser.append({"дата": dates[i], "разрыв": round((r[0][1] - r[-1][1]) * 100, 1),
                "лидер": r[0][0]})
changes = [s for n, s in enumerate(ser) if n and s["лидер"] != ser[n - 1]["лидер"]]

print("РЯД РАЗРЫВА: %d недельных точек, %s → %s | смен лидера за год %d"
      % (len(ser), ser[0]["дата"], ser[-1]["дата"], len(changes)))
print("  смены лидера: " + ", ".join("%s → %s" % (c["дата"], RU[c["лидер"]]) for c in changes))
print("  разрыв: минимум %.1f%%, максимум %.1f%%, сейчас %.1f%%"
      % (min(s["разрыв"] for s in ser), max(s["разрыв"] for s in ser), ser[-1]["разрыв"]))

json.dump({"кварталы": rows, "ряд": ser, "смены": changes, "RU": RU},
          open("/home/claude/histdata.json", "w"), ensure_ascii=False)

asof = dates[-1]
LOG.value("разрыв_лидер_аутсайдер_история", rows[-1]["разрыв"],
          "расчёт по ценам Tiingo", asof, "%")
LOG.value("смен_лидера_за_год", len(changes), "расчёт по ценам Tiingo", asof)
print("ВЫГРУЗКА: histdata.json")