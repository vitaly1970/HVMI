#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""wlm_calc.py — расчёт выпуска «Системная ликвидность» (код wlm).

Устройство выпуска от 25.08.2026: четыре раздела и приложение под одну боль
читателя — пора ли снижать риск, и если нет, то по какому признаку и в какой
срок это станет пора.

Р.1  запас денег и его движение          → раздел «Ответ на сегодня»
Р.2  календарь изъятий и траектория      → раздел «Когда станет пора»
Р.3  похожие недели истории с 2008 года  → раздел «Насколько это серьёзно»
Р.4  четыре точки напряжения             → там же, мера остроты
Р.5  портфель и условия слома вывода     → раздел «Что делаем»
Р.6  приложение: баланс недели, ряды

Сравнение с прошлым делается методом похожих недель: состояние описывается
пятью величинами, из истории берётся десятая часть самых близких недель,
разница их исхода с обычным проверяется блочным бутстрэпом. Печатается только
то, чей доверительный интервал не накрывает ноль.
"""
import argparse, io, json, os, sys, time, urllib.request, warnings
import numpy as np, pandas as pd

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import amin_run
from amin_run import Log

CALC_VERSION = "6.0.0"
UA = "curl/8.5.0"
BUA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
BURN, SHARE, BLOCK, REPS = 104, 0.10, 13, 4000
L = None


# ─────────────────────────── каналы ───────────────────────────
def fetch(url, ua=UA, headers=None, tries=3, timeout=60):
    h = {"User-Agent": ua, "Accept": "*/*"}
    if headers:
        h.update(headers)
    last = None
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=h)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except Exception as e:
            last = e
            time.sleep(1.0 * (i + 1))
    raise last


def fred(code, data="data"):
    os.makedirs(data, exist_ok=True)
    f = os.path.join(data, "fred_%s.csv" % code)
    if not os.path.exists(f):
        url = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=" + code
        try:
            open(f, "wb").write(fetch(url, headers={"Accept": "text/plain"}))
        except Exception as e:
            L.get("FRED", url, ok=False, note=str(e)[:100])
            return None
        time.sleep(0.8)
    d = pd.read_csv(f)
    d.columns = ["date", "v"]
    d["date"] = pd.to_datetime(d["date"])
    d["v"] = pd.to_numeric(d["v"], errors="coerce")
    s = d.dropna().set_index("date")["v"]
    return s if len(s) else None


def yahoo(sym, data="data"):
    os.makedirs(data, exist_ok=True)
    f = os.path.join(data, "yh_%s.csv" % sym.replace("^", "i_"))
    if not os.path.exists(f):
        url = ("https://query1.finance.yahoo.com/v8/finance/chart/%s"
               "?period1=-1893456000&period2=%d&interval=1d"
               % (urllib.parse.quote(sym, safe="^"), int(time.time())))
        try:
            j = json.loads(fetch(url, ua=BUA))
            r = j["chart"]["result"][0]
            px = r["indicators"]["adjclose"][0]["adjclose"]
            s = pd.Series(px, index=pd.to_datetime(r["timestamp"], unit="s").normalize()).dropna()
            s.to_csv(f, header=["v"])
        except Exception as e:
            L.get("Yahoo", sym, ok=False, note=str(e)[:100])
            return None
        time.sleep(0.4)
    d = pd.read_csv(f, parse_dates=[0], index_col=0)
    return d.iloc[:, 0].dropna()


def nyfed_dealers(data="data"):
    """Позиции первичных дилеров FR 2004, чистая позиция в госбумагах."""
    f = os.path.join(data, "pd.json")
    url = "https://markets.newyorkfed.org/api/pd/get/PDPOSGST-TOT.json"
    if not os.path.exists(f):
        try:
            open(f, "wb").write(fetch(url))
        except Exception as e:
            L.get("NY Fed FR2004", url, ok=False, note=str(e)[:100])
            return None
    try:
        j = json.load(open(f, encoding="utf-8"))
        rows = j["pd"]["timeseries"]
        s = pd.Series({pd.Timestamp(r["asofdate"]): float(r["value"])
                       for r in rows if r.get("value") not in (None, "", "*")}).sort_index()
        return s
    except Exception as e:
        L.get("NY Fed FR2004", url, ok=False, note=str(e)[:100])
        return None


def auctions(data="data"):
    """Прошедшие и объявленные размещения казначейских бумаг."""
    out = {}
    for name, url in [
        ("прошедшие", "https://www.treasurydirect.gov/TA_WS/securities/auctioned?format=json&days=40"),
        ("объявленные", "https://www.treasurydirect.gov/TA_WS/securities/upcoming?format=json")]:
        f = os.path.join(data, "auc_%s.json" % name)
        if not os.path.exists(f):
            try:
                open(f, "wb").write(fetch(url, ua=BUA))
            except Exception as e:
                L.get("TreasuryDirect", url, ok=False, note=str(e)[:100])
                continue
            time.sleep(0.5)
        try:
            out[name] = json.load(open(f, encoding="utf-8"))
        except Exception:
            pass
    return out


def move_now(data="data"):
    f = os.path.join(data, "move.json")
    url = "https://query1.finance.yahoo.com/v8/finance/chart/%5EMOVE?range=5d&interval=1d"
    if not os.path.exists(f):
        try:
            open(f, "wb").write(fetch(url, ua=BUA))
        except Exception as e:
            L.get("Yahoo ^MOVE", url, ok=False, note=str(e)[:100])
            return None, None
    try:
        j = json.load(open(f, encoding="utf-8"))
        m = j["chart"]["result"][0]["meta"]
        return float(m["regularMarketPrice"]), str(pd.Timestamp(m["regularMarketTime"], unit="s"))[:10]
    except Exception:
        return None, None


# ─────────────────────────── панель истории ───────────────────────────
FEAT = ["рез_ввп", "спред", "tga_ввп", "rrp_ввп", "д4_рез"]


def build_panel(cut, data="data"):
    res, wal = fred("WRESBAL", data), fred("WALCL", data)
    tga, rrp = fred("WDTGAL", data), fred("RRPONTSYD", data)
    ff, ioer, iorb = fred("DFF", data), fred("IOER", data), fred("IORB", data)
    gdp = fred("GDP", data)
    spx = yahoo("^GSPC", data)
    io = pd.concat([ioer, iorb]).sort_index()
    io = io[~io.index.duplicated(keep="last")]
    spread = (ff - io).dropna() * 100.0

    W = pd.DataFrame(index=res.index)
    W["резервы"] = res / 1000.0
    W["баланс"] = wal / 1000.0
    W["tga"] = tga / 1000.0
    W["rrp"] = rrp.reindex(W.index, method="ffill")
    W["спред"] = spread.reindex(W.index, method="ffill")
    W["ввп"] = gdp.reindex(pd.date_range("2002-01-01", "2027-12-31", freq="D"),
                          method=None).ffill().reindex(W.index, method="ffill")
    W = W.dropna(subset=["резервы", "спред", "ввп"])
    W = W[(W.index >= "2008-10-09") & (W.index <= pd.Timestamp(cut))]
    W["рез_ввп"] = W["резервы"] / W["ввп"] * 100.0
    W["tga_ввп"] = W["tga"] / W["ввп"] * 100.0
    W["rrp_ввп"] = W["rrp"] / W["ввп"] * 100.0
    W["д4_рез"] = W["рез_ввп"].diff(4)

    idx = spx.index
    def fwd(d, n):
        i = idx.searchsorted(d)
        return float(spx.iloc[i + n] / spx.iloc[i] - 1) * 100 if i + n < len(idx) else np.nan
    W["исх_63"] = [fwd(d, 63) for d in W.index]
    W["сист_рез"] = W["рез_ввп"].shift(-13) - W["рез_ввп"]
    W["сист_спред"] = W["спред"].rolling(13).max().shift(-13)
    W = W.dropna(subset=["д4_рез"])
    return W, spx


def neighbours(W, t, col):
    lag = pd.Timedelta(days=95)
    m = (W.index < t - lag) & W[col].notna()
    pool = W.index[m]
    if len(pool) < 260:
        return None
    X = W[FEAT].astype(float)
    mu, sd = X.expanding(BURN).mean().shift(1), X.expanding(BURN).std().shift(1)
    Z = (X - mu) / sd.replace(0, np.nan)
    ok = Z.loc[pool].notna().all(axis=1) & Z.loc[t].notna().all()
    pool = pool[ok.values]
    if len(pool) < 260:
        return None
    d = np.sqrt(((Z.loc[pool] - Z.loc[t]) ** 2).sum(axis=1).values)
    k = max(30, int(round(len(pool) * SHARE)))
    flag = np.zeros(len(pool), bool)
    flag[np.argsort(d)[:k]] = True
    return pool, W.loc[pool, col].values.astype(float), flag


def test(y, flag, reps=REPS, seed=7):
    """Блочный бутстрэп: разница медианы похожих недель с обычной."""
    rng = np.random.default_rng(seed)
    n = len(y)
    nb = int(np.ceil(n / BLOCK))
    st = rng.integers(0, n - BLOCK + 1, size=(reps, nb))
    ix = (st[:, :, None] + np.arange(BLOCK)[None, None, :]).reshape(reps, -1)[:, :n]
    ys, fs = y[ix], flag[ix]
    diff = np.nanmedian(np.where(fs, ys, np.nan), axis=1) - np.median(ys, axis=1)
    diff = diff[np.isfinite(diff)]
    lo, hi = np.nanpercentile(diff, [2.5, 97.5])
    return {"разница": round(float(np.median(y[flag]) - np.median(y)), 2),
            "низ": round(float(lo), 2), "верх": round(float(hi), 2),
            "печатаем": bool(lo > 0 or hi < 0),
            "у_похожих": round(float(np.median(y[flag])), 2),
            "обычно": round(float(np.median(y)), 2),
            "похожих_недель": int(flag.sum()), "всего_недель": int(len(y))}


def место(s, v, years=10):
    if s is None or len(s) < 60:
        return None
    tail = s[s.index >= s.index.max() - pd.Timedelta(days=365 * years)]
    if len(tail) < 60:
        tail = s
    return round(float((tail <= v).mean() * 100), 1)


# ─────────────────────────── расчёт ───────────────────────────
def main():
    global L
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutoff", required=True)
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="out")
    ap.add_argument("--spot", default="spot.json")
    a = ap.parse_args()
    cut = pd.Timestamp(a.cutoff)
    os.makedirs(a.out, exist_ok=True)
    L = Log(a.out, code="wlm", cutoff=a.cutoff)
    R = {"версия_расчёта": CALC_VERSION, "срез": a.cutoff}

    W, spx = build_panel(cut, a.data)
    last = W.index[-1]
    L.series("резервы", "FRED WRESBAL", last, len(W))
    L.series("баланс_фрс", "FRED WALCL", last, len(W))
    L.series("tga", "FRED WDTGAL", last, len(W))
    L.series("rrp", "FRED RRPONTSYD", last, len(W))
    L.series("sp500", "Yahoo ^GSPC", spx.index.max(), len(spx))

    # ── Р.1 запас денег
    def d(col, n):
        return float(W[col].iloc[-1] - W[col].iloc[-1 - n])
    R["запас"] = {
        "резервы": round(float(W["резервы"].iloc[-1]), 1),
        "резервы_к_ввп": round(float(W["рез_ввп"].iloc[-1]), 2),
        "д1_резервы": round(d("резервы", 1), 1), "д4_резервы": round(d("резервы", 4), 1),
        "tga": round(float(W["tga"].iloc[-1]), 1), "д4_tga": round(d("tga", 4), 1),
        "rrp": round(float(W["rrp"].iloc[-1]), 1),
        "баланс_фрс": round(float(W["баланс"].iloc[-1]), 1), "д4_баланс": round(d("баланс", 4), 1),
        "дата": str(last)[:10],
        "место_резервы": место(W["рез_ввп"], float(W["рез_ввп"].iloc[-1])),
        "чистая_ликвидность": round(float(W["резервы"].iloc[-1]), 1),
    }
    for k in ["резервы", "резервы_к_ввп", "баланс_фрс", "tga", "rrp", "чистая_ликвидность"]:
        L.value(k, R["запас"][k], "FRED", str(last)[:10], "млрд долларов")

    # ── ставки овернайт
    sofr, s99 = fred("SOFR", a.data), fred("SOFR99", a.data)
    iorb = fred("IORB", a.data)
    if sofr is not None and iorb is not None:
        sp = ((sofr - iorb.reindex(sofr.index, method="ffill")) * 100).dropna()
        sp = sp[sp.index <= cut]
        R["овернайт"] = {"sofr": round(float(sofr[sofr.index <= cut].iloc[-1]), 2),
                         "спред_sofr_iorb": round(float(sp.iloc[-1]), 1),
                         "спред_макс_4нед": round(float(sp.iloc[-20:].max()), 1),
                         "место_спреда": место(sp, float(sp.iloc[-1]), 3),
                         "дата": str(sp.index[-1])[:10]}
        L.series("sofr", "FRED SOFR", sofr.index.max(), len(sofr))
        L.value("спред_sofr_iorb", R["овернайт"]["спред_sofr_iorb"], "FRED SOFR/IORB",
                str(sp.index[-1])[:10], "базисных пунктов")
    if s99 is not None:
        s99 = s99[s99.index <= cut]
        R["овернайт"]["перцентиль99_sofr"] = round(float(s99.iloc[-1]), 2)
        R["овернайт"]["перцентиль99_превышение"] = round(
            float((s99.iloc[-1] - iorb.reindex(s99.index, method="ffill").iloc[-1]) * 100), 1)
        L.value("перцентиль99_sofr", R["овернайт"]["перцентиль99_sofr"], "FRED SOFR99",
                str(s99.index[-1])[:10], "% годовых")
    R["овернайт"]["спред_effr_iorb"] = round(float(W["спред"].iloc[-1]), 1)
    L.value("спред_effr_iorb", R["овернайт"]["спред_effr_iorb"], "FRED DFF/IORB",
            str(last)[:10], "базисных пунктов")

    srf = fred("RPONTSYD", a.data)
    if srf is not None:
        srf = srf[srf.index <= cut]
        R["овернайт"]["srf"] = round(float(srf.iloc[-1]), 2)
        R["овернайт"]["srf_макс_4нед"] = round(float(srf.iloc[-20:].max()), 2)
        L.value("srf", R["овернайт"]["srf"], "FRED RPONTSYD", str(srf.index[-1])[:10], "млрд долларов")

    # ── Р.2 календарь и траектория
    au = auctions(a.data)
    cal = []
    if au.get("объявленные"):
        for r in au["объявленные"]:
            try:
                dt_ = pd.Timestamp(r.get("auctionDate"))
            except Exception:
                continue
            if cut <= dt_ <= cut + pd.Timedelta(days=56):
                cal.append({"дата": str(dt_)[:10], "бумага": r.get("securityType", ""),
                            "срок": r.get("securityTerm", ""),
                            "оплата": str(r.get("issueDate", ""))[:10]})
    R["календарь"] = sorted(cal, key=lambda x: x["дата"])[:24]
    if R["календарь"]:
        L.value("аукционы", len(R["календарь"]), "TreasuryDirect", a.cutoff, "объявлено размещений")
    else:
        L.gap("аукционы", ["TreasuryDirect upcoming"], "объявленных размещений в окне не получено")

    # точечные величины календаря приходят файлом и проходят через журнал
    SP = {}
    if os.path.exists(a.spot):
        SP = json.load(open(a.spot, encoding="utf-8"))
        for k, v in SP.items():
            L.value(k, v["значение"], v["источник"], v["дата"], v.get("единица", ""),
                    v.get("пометка", ""))
    R["календарь_минфина"] = {k: v["значение"] for k, v in SP.items()}

    drift = float(W["резервы"].diff().iloc[-8:].mean())      # прочие обязательства, млрд в неделю
    tga_now = float(W["tga"].iloc[-1])
    цель_сент = float(SP.get("цель_tga_конец_сентября", {}).get("значение", tga_now))
    пик_окт = float(SP.get("пик_tga_конец_октября", {}).get("значение", цель_сент))
    def tga_на(d):
        """Путь счёта Казначейства: к цели на конец сентября, затем к пику конца октября."""
        d = pd.Timestamp(d)
        a1, a2, a3 = last, pd.Timestamp("2026-09-30"), pd.Timestamp("2026-10-30")
        if d <= a2:
            w = (d - a1).days / max((a2 - a1).days, 1)
            return tga_now + w * (цель_сент - tga_now)
        w = (d - a2).days / max((a3 - a2).days, 1)
        return цель_сент + min(w, 1.0) * (пик_окт - цель_сент)
    гор4, гор8 = last + pd.Timedelta(weeks=4), last + pd.Timedelta(weeks=8)
    R["траектория"] = {
        "дрейф_неделя": round(drift, 1),
        "через_4_недели": round(float(W["резервы"].iloc[-1]) - (tga_на(гор4) - tga_now) + 4 * drift, 1),
        "через_8_недель": round(float(W["резервы"].iloc[-1]) - (tga_на(гор8) - tga_now) + 8 * drift, 1),
        "дата_4": str(гор4)[:10], "дата_8": str(гор8)[:10],
        "tga_через_4": round(tga_на(гор4), 1), "tga_через_8": round(tga_на(гор8), 1),
        "метод": ("счёт Казначейства идёт к объявленной Минфином цели на конец сентября и "
                  "к оценке пика конца октября; прочие обязательства растут средним темпом "
                  "восьми недель; баланс ФРС держится плоским")}
    R["траектория"]["к_ввп_через_8"] = round(R["траектория"]["через_8_недель"] /
                                             float(W["ввп"].iloc[-1]) * 100, 2)
    R["траектория"]["к_ввп_через_4"] = round(R["траектория"]["через_4_недели"] /
                                             float(W["ввп"].iloc[-1]) * 100, 2)
    R["траектория"]["порог_история"] = round(float(np.percentile(W["рез_ввп"], 10)), 2)

    # ── Р.3 похожие недели
    R["похожие"] = {}
    for col, key in [("сист_спред", "напряжение_овернайт"), ("сист_рез", "запас_денег"),
                     ("исх_63", "индекс_квартал")]:
        r = neighbours(W, last, col)
        if r is None:
            continue
        pool, y, flag = r
        R["похожие"][key] = test(y, flag)
        if key == "напряжение_овернайт":
            nb = pd.Series(1, index=pool[flag])
            g = (nb.index.to_series().diff() > pd.Timedelta(days=21)).cumsum()
            ep = nb.groupby(g.values).apply(lambda s: [str(s.index.min())[:10],
                                                       str(s.index.max())[:10], len(s)])
            R["похожие"]["эпизоды"] = sorted(ep.tolist(), key=lambda x: -x[2])[:6]
            R["похожие"]["доля_срыв_похожие"] = round(float((y[flag] >= 0).mean() * 100), 1)
            R["похожие"]["доля_срыв_обычно"] = round(float((y >= 0).mean() * 100), 1)
    R["похожие"]["панель"] = {"недель": int(len(W)), "начало": str(W.index[0])[:10]}

    # ── Р.4 точки напряжения
    R["точки"] = {}
    y10, y30 = fred("DGS10", a.data), fred("DGS30", a.data)
    hy, ig = fred("BAMLH0A0HYM2", a.data), fred("BAMLC0A0CM", a.data)
    vix, nfci = fred("VIXCLS", a.data), fred("NFCI", a.data)
    dxy = fred("DTWEXBGS", a.data)
    swp = fred("SWPT", a.data)
    for s, key, chan, unit in [(y10, "доходность_10л", "FRED DGS10", "% годовых"),
                               (hy, "hy_oas", "FRED BAMLH0A0HYM2", "% годовых"),
                               (ig, "кредитный_прокси", "FRED BAMLC0A0CM", "% годовых"),
                               (vix, "vix", "FRED VIXCLS", "пунктов"),
                               (nfci, "nfci", "FRED NFCI", "пунктов")]:
        if s is None:
            L.gap(key, [chan], "ряд не получен")
            continue
        s = s[s.index <= cut]
        L.series(key, chan, s.index.max(), len(s),
                 "снимок: индекс публикуется в среду за неделю до предыдущей пятницы"
                 if key == "nfci" else "")
        R["точки"][key] = {"значение": round(float(s.iloc[-1]), 2),
                           "место": место(s, float(s.iloc[-1])),
                           "д4": round(float(s.iloc[-1] - s.iloc[-21]), 2) if len(s) > 21 else None,
                           "дата": str(s.index[-1])[:10]}
    if y30 is not None:
        y30 = y30[y30.index <= cut]
        R["точки"]["доходность_30л"] = {"значение": round(float(y30.iloc[-1]), 2),
                                        "место": место(y30, float(y30.iloc[-1])),
                                        "дата": str(y30.index[-1])[:10]}
    if dxy is not None:
        dxy = dxy[dxy.index <= cut]
        L.series("доллар", "FRED DTWEXBGS", dxy.index.max(), len(dxy),
                 "ЛАГ_КАНАЛА: широкий индекс доллара отстаёт на четыре торговых дня")
        R["точки"]["доллар"] = {"значение": round(float(dxy.iloc[-1]), 2),
                                "место": место(dxy, float(dxy.iloc[-1])),
                                "д4": round(float(dxy.iloc[-1] - dxy.iloc[-21]), 2),
                                "дата": str(dxy.index[-1])[:10]}
    if swp is not None:
        swp = swp[swp.index <= cut]
        R["точки"]["своп_линии"] = {"значение": round(float(swp.iloc[-1]) / 1000.0, 2),
                                    "дата": str(swp.index[-1])[:10]}

    pdl = nyfed_dealers(a.data)
    if pdl is not None:
        pdl = pdl[pdl.index <= cut]
        L.series("дилеры_fr2004", "NY Fed FR2004", pdl.index.max(), len(pdl),
                 "снимок: отчётность дилеров публикуется с лагом восемь дней")
        R["точки"]["дилеры"] = {"значение": round(float(pdl.iloc[-1]) / 1000.0, 1),
                                "место": место(pdl, float(pdl.iloc[-1])),
                                "д4": round(float(pdl.iloc[-1] - pdl.iloc[-4]) / 1000.0, 1),
                                "дата": str(pdl.index[-1])[:10]}
    else:
        L.gap("дилеры_fr2004", ["NY Fed markets API"], "ряд позиций дилеров не получен")

    mv, mvd = move_now(a.data)
    if mv:
        R["точки"]["move"] = {"значение": round(mv, 1), "дата": mvd}
        L.value("move", round(mv, 1), "Yahoo ^MOVE", mvd, "пунктов",
                "снимок: история индекса по каналу не отдаётся")
    else:
        L.gap("move", ["Yahoo ^MOVE", "ICE"], "индекс волатильности облигаций не получен")

    # ── размещения: прошедшие, спрос и доля дилеров
    R["размещения"] = []
    if au.get("прошедшие"):
        for r in au["прошедшие"]:
            try:
                if r.get("securityType") not in ("Bond", "Note"):
                    continue
                if str(r.get("tips", "")).lower() in ("true", "yes", "y"):
                    continue
                if str(r.get("floatingRate", "")).lower() in ("true", "yes", "y"):
                    continue
                dt_ = pd.Timestamp(r.get("auctionDate"))
                if not (cut - pd.Timedelta(days=30) <= dt_ <= cut):
                    continue
                R["размещения"].append({
                    "дата": str(dt_)[:10], "срок": r.get("securityTerm", ""),
                    "ставка": float(r.get("highYield") or 0),
                    "спрос": float(r.get("bidToCoverRatio") or 0),
                    "дилеры": round(float(r.get("primaryDealerAccepted") or 0) /
                                    max(float(r.get("totalAccepted") or 1), 1) * 100, 1)})
            except Exception:
                continue
        R["размещения"] = sorted(R["размещения"], key=lambda x: x["дата"], reverse=True)[:6]

    # ── недоступные по подписке каналы
    L.gap("маржинальный_долг", ["FINRA margin statistics"],
          "месячная статистика долга под залог бумаг на срез не обновлена")
    L.gap("mmf", ["ICI weekly money market", "FRED"],
          "недельная статистика денежных фондов закрыта для машинного чтения (ICI отдаёт 403)")
    L.gap("дисконт_hyg", ["iShares NAV", "Yahoo"],
          "расхождение цены фонда HYG с чистой стоимостью активов по каналам не получено")
    L.gap("gli", ["CrossBorder Capital"], "индекс мировой ликвидности публикуется по подписке")

    # ── Р.5 портфель: цены и ставки инструментов
    R["портфель"] = {}
    for t, nm in [("TLT", "длинные_госбумаги"), ("IEF", "средние_госбумаги"),
                  ("SGOV", "короткие_госбумаги"), ("GLD", "золото")]:
        s = yahoo(t, a.data)
        if s is None:
            continue
        s = s[s.index <= cut]
        R["портфель"][nm] = {"тикер": t, "цена": round(float(s.iloc[-1]), 2),
                             "д4_проц": round(float(s.iloc[-1] / s.iloc[-21] - 1) * 100, 1),
                             "год_проц": round(float(s.iloc[-1] / s.iloc[-252] - 1) * 100, 1)}
    b3 = fred("DGS3MO", a.data)
    if b3 is not None:
        b3 = b3[b3.index <= cut]
        R["портфель"]["ставка_3м"] = round(float(b3.iloc[-1]), 2)

    # ── приложение: баланс недели
    R["баланс"] = []
    for nm, col, unit in [("Резервы банков в ФРС", "резервы", "млрд долларов"),
                          ("Счёт Казначейства в ФРС", "tga", "млрд долларов"),
                          ("Обратное репо ФРС", "rrp", "млрд долларов"),
                          ("Баланс ФРС", "баланс", "млрд долларов")]:
        s = W[col]
        R["баланс"].append({"строка": nm, "единица": unit,
                            "значение": round(float(s.iloc[-1]), 1),
                            "д1": round(float(s.iloc[-1] - s.iloc[-2]), 1),
                            "д4": round(float(s.iloc[-1] - s.iloc[-5]), 1),
                            "место": место(s, float(s.iloc[-1]))})

    # ── данные графиков
    ser = W.loc[W.index >= cut - pd.Timedelta(days=365 * 3)]
    R["chart_data"] = {
        "резервы": {"даты": [str(x)[:10] for x in ser.index],
                    "значения": [round(float(v), 1) for v in ser["резервы"]],
                    "к_ввп": [round(float(v), 2) for v in ser["рез_ввп"]]},
        "спред": {"даты": [str(x)[:10] for x in ser.index],
                  "значения": [round(float(v), 1) for v in ser["спред"]]},
        "спред_репо": {"даты": [], "значения": []},
        "траектория": {"сейчас": R["запас"]["резервы"],
                       "через_4": R["траектория"]["через_4_недели"],
                       "через_8": R["траектория"]["через_8_недель"],
                       "tga_сейчас": R["запас"]["tga"],
                       "tga_через_4": R["траектория"]["tga_через_4"],
                       "tga_через_8": R["траектория"]["tga_через_8"]},
    }
    if sofr is not None and iorb is not None:
        sp3 = ((sofr - iorb.reindex(sofr.index, method="ffill")) * 100).dropna()
        sp3 = sp3[(sp3.index <= cut) & (sp3.index >= cut - pd.Timedelta(days=365 * 3))]
        R["chart_data"]["спред_репо"] = {"даты": [str(x)[:10] for x in sp3.index],
                                         "значения": [round(float(v), 1) for v in sp3]}

    if "напряжение_овернайт" in R["похожие"]:
        r = neighbours(W, last, "сист_спред")
        pool, y, flag = r
        R["chart_data"]["похожие"] = {
            "у_похожих": [round(float(v), 1) for v in y[flag]],
            "обычно": [round(float(v), 1) for v in y]}

    json.dump(R, open(os.path.join(a.out, "calc.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    cov = amin_run.cover("wlm", a.cutoff)
    meta = {"slug": amin_run.slug("wlm", a.cutoff), "title": cov["title"],
            "date": cov["date"], "subtitle": cov["subtitle"]}
    json.dump(meta, open(os.path.join(a.out, "meta.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print("готово:", meta["slug"], "| резервы", R["запас"]["резервы"],
          "| спред SOFR−IORB", R.get("овернайт", {}).get("спред_sofr_iorb"),
          "| панель недель", R["похожие"]["панель"]["недель"])


if __name__ == "__main__":
    main()
