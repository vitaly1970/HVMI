/* md2doc.js — разбор текста выпуска (markdown) в элементы вёрстки AmIn style.
   Текст выпуска живёт в отдельном файле <slug>.md и правится издателем.
   Скрипт сборки продукта берёт текст ТОЛЬКО отсюда: своей прозы он не хранит.

   Разметка файла выпуска
   ----------------------
   Шапка между строками --- : slug, title, subtitle, crumb, date, date_en.
   # Заголовок | пояснение      раздел с новой страницы
   ## Подзаголовок              подзаголовок внутри раздела
   обычный абзац                проза
   > Вывод. текст               карточка вывода
   ![имя.png|вывод|что по осям](вид)  график: заголовок-вывод и строка осей
                                      печатаются НАД картинкой, источник — под
   >> текст                     врезка слева от следующего графика
   | шапка | … |                таблица markdown, ширины считаются сами
   :annotation … :              Annotation: печатается на обложке и в изложении
   :режим Заголовок | пояснение полоса состояния под Annotation
   :термины … :                 строки «Термин — объяснение»
   :правовая                    правовая страница постоянным текстом
*/

const S = require("./assets/report-style.js");
const { Table, TableRow, TableCell, WidthType, BorderStyle, VerticalAlign, Paragraph, LineRuleType,
        ImageRun, HorizontalPositionRelativeFrom, VerticalPositionRelativeFrom, TextWrappingType } = require("docx");
const { AlignmentType: A } = S;
const dim = require("./assets/img-size.js");
const fs = require("fs");
const path = require("path");

const TOTAL_W = 9360;              // сумма ширин колонок таблицы, жёстко
const IMG_KIND = { standard: 520, donut: 420, ranges: 440 };
const NOBORDER = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const BORDERLESS = { top: NOBORDER, bottom: NOBORDER, left: NOBORDER, right: NOBORDER,
                     insideHorizontal: NOBORDER, insideVertical: NOBORDER };

const LEGAL = [
  "Материал носит информационно-аналитический характер и не является инвестиционной рекомендацией, офертой или предложением совершить сделку с каким-либо финансовым инструментом.",
  "Оценки и суждения отражают состояние данных на дату выпуска и могут измениться без уведомления. Издатель не принимает на себя обязательства обновлять материал.",
  "Источники указаны при каждом показателе. Часть данных получена через вторичные источники и помечена соответствующим образом.",
  "Историческая динамика и результаты расчётов на исторических выборках не гарантируют будущих результатов.",
  "Решения, принятые на основании настоящего материала, принимаются читателем самостоятельно и под его ответственность.",
];

/* ── неразрывный пробел между числом и единицей ────────────────────────────
   В файле выпуска стоят обычные пробелы: так текст удобно править. Связка
   числа с единицей — работа сборки, а не издателя. Без неё строка таблицы
   рвётся после цифры и знак единицы уезжает на следующую строку.        */
const UNITS = "%|п\\.п\\.|млрд|млн|тыс\\.|трлн";
function nb(s) {
  if (typeof s !== "string") return s;
  return s.replace(new RegExp("(\\d)\\s(" + UNITS + ")", "g"), "$1\u00A0$2");
}

/* ── шапка файла ───────────────────────────────────────────────────────── */
function head(text) {
  const m = text.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
  if (!m) throw new Error("в файле выпуска нет шапки между строками ---");
  const meta = {};
  m[1].split(/\r?\n/).forEach(line => {
    const k = line.match(/^([a-z_]+)\s*:\s*(.*)$/);
    if (k) meta[k[1]] = k[2].trim();
  });
  for (const need of ["slug", "title", "subtitle", "crumb", "date"]) {
    if (!meta[need]) throw new Error("в шапке выпуска нет поля " + need);
  }
  return { meta, body: text.slice(m[0].length) };
}

/* ── таблица: ширины считаются по содержимому, сумма всегда 9360 ───────── */
function isNum(v) {
  return /^[−-]?[\d\s\u00A0]+([.,]\d+)?\s*%?$/.test(String(v).trim()) && /\d/.test(v);
}

function table(rows) {
  const headCells = rows[0];
  const body = rows.slice(1);
  const n = headCells.length;
  const numeric = [];
  for (let c = 0; c < n; c++) {
    numeric.push(body.length > 0 && body.every(r => isNum(r[c] || "")));
  }
  // вес колонки — самая длинная строка в ней, с поправкой на шапку
  const weight = [];
  for (let c = 0; c < n; c++) {
    let w = headCells[c].length * 1.4;
    body.forEach(r => { w = Math.max(w, (r[c] || "").length); });
    weight.push(Math.max(w, 6));
  }
  const sum = weight.reduce((a, b) => a + b, 0);
  const widths = weight.map(w => Math.round(TOTAL_W * w / sum));
  // хвост правим так, чтобы сумма была ровно 9360 (иначе текст молча режется)
  widths[n - 1] += TOTAL_W - widths.reduce((a, b) => a + b, 0);

  /* Колонка из коротких значений («Доля», «Фонд сегмента») получает по
     содержимому такую долю, что в неё не встаёт даже одно слово, и конвертер
     рвёт слово на обрывок: «До» + «ля». Долю считаем как раньше, но каждой
     колонке даём нижний предел по её самому длинному слову, а недостачу
     забираем у самой широкой. Сумма остаётся ровно TOTAL_W. */
  const longest = [];
  for (let c = 0; c < n; c++) {
    let L = 0;
    [headCells, ...body].forEach(r => {
      String(r[c] || "").split(/\s+/).forEach(word => { L = Math.max(L, word.length); });
    });
    longest.push(L);
  }
  const floors = longest.map(L => Math.min(Math.round(L * 130 + 220), Math.round(TOTAL_W / n * 2)));
  for (let c = 0; c < n; c++) {
    let need = floors[c] - widths[c];
    if (need <= 0) continue;
    while (need > 0) {
      let donor = -1;
      for (let d = 0; d < n; d++) {
        if (d === c) continue;
        if (widths[d] - floors[d] <= 0) continue;
        if (donor < 0 || widths[d] > widths[donor]) donor = d;
      }
      if (donor < 0) break;
      const give = Math.min(need, widths[donor] - floors[donor]);
      widths[donor] -= give;
      widths[c] += give;
      need -= give;
    }
  }

  const cols = headCells.map((t, c) => {
    const col = { t, w: widths[c] };
    if (numeric[c]) col.align = A.RIGHT;
    return col;
  });
  const data = body.map(r => r.map((v, c) => (numeric[c] ? S.num(v.trim()) : nb(v))));
  return S.table(cols, data);
}

function splitRow(line) {
  return line.replace(/^\||\|$/g, "").split("|").map(s => s.trim());
}

/* ── разбор тела ───────────────────────────────────────────────────────── */
function parse(text, opt) {
  const { meta, body } = head(text);
  const charts = opt.charts || ".";
  const K = [];
  const toc = [];
  let annotation = [];

  const lines = body.split(/\r?\n/);
  let i = 0;
  let aside = "";                        // врезка, ждущая своего графика
  const para = [];                       // копится абзац по строкам

  /* Полужирный внутри абзаца: **текст**. Без разбора звёздочки печатаются
     как есть и читаются браком вёрстки. */
  const runs = (s) => {
    if (!s.includes("**")) return s;
    const out = [];
    s.split(/\*\*/).forEach((chunk, k) => {
      if (chunk) out.push(S.run(chunk, { bold: k % 2 === 1 }));
    });
    return out;
  };

  const flush = () => {
    if (!para.length) return;
    K.push(S.p(runs(nb(para.join(" ").trim()))));
    para.length = 0;
  };

  while (i < lines.length) {
    const line = lines[i];
    const t = line.trim();

    if (!t) { flush(); i++; continue; }

    // блок с меткой
    if (t.startsWith(":")) {
      flush();
      const name = t.slice(1).split(/[\s|]/)[0];
      if (name === "annotation") {
        // однострочная запись «:annotation текст :» — так её пишет черновик
        // прогона v5.0; многострочная с закрывающим «:» на своей строке
        // остаётся (правка 07.09.2026)
        const oneLine = t.match(/^:annotation\s+(.+?)\s+:$/);
        if (oneLine) {
          annotation = [nb(oneLine[1])];
          i++;
          continue;
        }
        i++;
        const buf = [];
        while (i < lines.length && lines[i].trim() !== ":") {
          if (lines[i].trim()) buf.push(lines[i].trim());
          i++;
        }
        i++;
        annotation = buf.map(x => nb(x));   // печатается на обложке, в теле её нет
        continue;
      }
      // :название … : — название статьи, крупный заголовок обложки (пишет
      // редактор; решение издателя 07.09.2026). Перекрывает title шапки.
      if (name === "название") {
        const one = t.match(/^:название\s+(.+?)\s+:$/);
        if (one) meta.title = one[1].trim();
        i++;
        continue;
      }
      if (name === "режим") {
        const rest = t.slice(":режим".length).trim();
        const parts = rest.split("|").map(s => s.trim());
        K.push(...S.regime(nb(parts[0]), nb(parts[1] || "")));
        K.push(S.spacer(140));
        i++;
        continue;
      }
      if (name === "термины") {
        i++;
        const pairs = [];
        while (i < lines.length && lines[i].trim() !== ":") {
          const s = lines[i].trim();
          if (s) {
            const m = s.split(/\s+—\s+/);
            pairs.push([m[0], nb(m.slice(1).join(" — "))]);
          }
          i++;
        }
        i++;
        K.push(...S.glossary(pairs));
        continue;
      }
      if (name === "правовая") {
        K.push(...S.disclaimerPage(LEGAL));
        i++;
        continue;
      }
      throw new Error("неизвестная метка блока: " + t);
    }

    // разрыв страницы: строка из трёх дефисов внутри тела
    if (/^-{3,}$/.test(t)) {
      flush();
      K.push(S.pageBreak());
      i++;
      continue;
    }

    // заголовок раздела
    if (t.startsWith("# ")) {
      flush();
      const [title, note] = t.slice(2).split("|").map(s => s.trim());
      toc.push({ t: title });
      // Разделы письма идут подряд, с новой страницы открывается только
      // «Приложение» (решение издателя 03.09.2026): иначе на коротких частях
      // остаётся пустой низ страницы.
      const fromNewPage = toc.length > 0 && /^Приложени/i.test(title);
      const h = S.heading(nb(title), S.C.navy, nb(note || ""), { newPage: fromNewPage });
      h.__heading = true;
      K.push(h);
      i++;
      continue;
    }

    // подзаголовок
    if (t.startsWith("## ")) {
      flush();
      const st = t.slice(3).trim();
      toc.push({ t: st, sub: true });
      K.push(S.sub(nb(st)));
      i++;
      continue;
    }

    // вывод
    if (t.startsWith("> ")) {
      flush();
      K.push(S.conclusion(nb(t.slice(2).replace(/^Вывод\.\s*/, "").trim())));
      i++;
      continue;
    }

    // карточка с собственной меткой: «>! Метка. текст» — полоса слева, метка
    // полужирным; так выделяется структурный блок (три сценария), решение
    // издателя 07.09.2026
    if (t.startsWith(">! ")) {
      flush();
      const body = t.slice(3).trim();
      const m = body.match(/^([^.]+)\.\s+([\s\S]+)$/);
      K.push(m ? S.conclusion(nb(m[2]), m[1]) : S.conclusion(nb(body), ""));
      i++;
      continue;
    }

    // врезка к следующему графику: копится и печатается колонкой слева от него
    if (t.startsWith(">> ")) {
      flush();
      aside = nb(t.slice(3).trim());
      i++;
      continue;
    }

    // график: заголовок-вывод и строка осей над картинкой, источник под ней
    const im = t.match(/^!\[([^\]]+)\]\(([^)]*)\)$/);
    if (im) {
      flush();
      const [file, lead1, lead2] = im[1].split("|").map(x => x.trim());
      const kind = im[2] || "standard";
      const p = path.join(charts, file);
      if (!fs.existsSync(p)) throw new Error("нет файла графика: " + p);

      i++;
      let note = "";
      if (i < lines.length && lines[i].trim() && !lines[i].trim().startsWith("#")) {
        note = nb(lines[i].trim());
        i++;
      }

      // Блок графика собирает компонент figure() набора report-format: он
      // единственный дом приёмов, утверждённых 04.09.2026 (заголовок-вывод,
      // строка осей, источник под картинкой, врезка узкой колонкой слева).
      // Своя копия этой раскладки здесь стояла до 06.09.2026 и от правок
      // набора отставала бы молча.
      const d = dim(p);
      if (aside) {
        const wR = TOTAL_W - 3300;
        const imgW = Math.round(wR / 1440 * 96) - 8;
        K.push(...S.figure(p, { w: imgW, h: Math.round(imgW * d.h / d.w),
                                lead: lead1, axes: lead2, note, aside,
                                width: TOTAL_W }));
        aside = "";
        continue;
      }
      const width = IMG_KIND[kind] || IMG_KIND.standard;
      K.push(...S.figure(p, { w: width, h: Math.round(width * d.h / d.w),
                              lead: lead1, axes: lead2, note }));
      continue;
    }

    // таблица
    if (t.startsWith("|")) {
      flush();
      const rows = [];
      while (i < lines.length && lines[i].trim().startsWith("|")) {
        const cells = splitRow(lines[i].trim());
        if (!cells.every(c => /^:?-{2,}:?$/.test(c))) rows.push(cells);
        i++;
      }
      K.push(table(rows));
      K.push(S.spacer(140));
      continue;
    }

    para.push(t);
    i++;
  }
  flush();

  // блоки до первого заголовка раздела — обложка
  const firstHead = K.findIndex(b => b && b.__heading);
  const lead = firstHead > 0 ? K.slice(0, firstHead) : [];
  const blocks = firstHead > 0 ? K.slice(firstHead) : K;
  return { meta, blocks, toc, annotation, lead };
}

/* ── сборка документа ──────────────────────────────────────────────────── */
function build(text, opt) {
  opt = opt || {};
  const r = parse(text, opt);
  const m = r.meta;
  const pages = opt.pages || {};        // {заголовок: номер} из toc-pages.py

  const K = [];
  // Обложка несёт только имя выпуска, подзаголовок, дату и авторство (решение
  // издателя 03.09.2026). Annotation, вердикт и шкала открывают письмо — они
  // встают сразу после его заголовка. Содержание идёт второй страницей и
  // собирается по двум уровням: разделы и части письма.
  // Обложка в три ступени: рубрика мелким, имя выпуска крупным, ниже
  // Annotation (решение издателя 04.09.2026). В теле выпуска Annotation не
  // печатается — обложка её единственное место; в изложение для архива она
  // уходит по-прежнему.
  const lead = r.lead || [];
  K.push(...S.cover(m.title, { subtitle: m.subtitle, crumb: m.crumb, date: m.date, product: m.product,
                               annotation: r.annotation, landscape: false }));
  const leadRest = lead;
  // Обложка сама разрыва не даёт: его ставит содержание. Содержания нет —
  // ставим разрыв здесь, иначе текст выпуска поднимается на обложку.
  if (r.toc.length <= 1) K.push(S.pageBreak());
  if (r.toc.length > 1) {
    K.push(...S.toc(r.toc.map((e, k) => ({
                      t: (e.sub ? "\u2003" : "") + e.t,
                      page: pages[e.t] || (3 + k),
                      accent: e.sub ? S.C.line : undefined,
                    })),
                    "Содержание", { newPage: true }));
  }
  // Annotation, вердикт и шкала идут отдельной страницей сразу после
  // содержания, перед первым разделом выпуска (решение издателя 03.09.2026).
  // Разрыв ставится и тогда, когда до первого заголовка ничего нет: без него
  // первый раздел печатается впритык к строкам оглавления.
  K.push(S.pageBreak());
  if (leadRest.length) {
    K.push(...leadRest);
  }
  K.push(...r.blocks);

  const doc = S.buildDoc(K, {
    brand: "American Investor",
    orientation: "portrait",
    titlePage: { date: m.date_en || m.date },
    header: { crumb: m.crumb, date: m.date },
    disclaimer: "Аналитический материал · не является инвестиционной рекомендацией · данные на " + m.date,
  });
  return { doc, meta: m, annotation: r.annotation, toc: r.toc };
}

module.exports = { build, parse, LEGAL };
