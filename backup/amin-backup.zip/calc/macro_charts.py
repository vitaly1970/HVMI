#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""macro_charts.py — графики выпуска «Макрорежим США» (промпт v8.3).

Строит из calc.json, charts.json прогона и рядов на диске. Правило отбора —
решение издателя 08.09.2026: график печатается, когда картина общая и нужна для
понимания положения дел, либо когда место требует особого внимания (расхождение,
перелом, необычное значение). Модуль строит ВСЕ доступные картинки, черновик
ставит только те, что проходят это правило; список оснований — в calc.json под
ключом «графики_основания». Портфель месяца снят (портфели ведёт отдельный
сервис). Построители одной линии берутся из набора report-format
(assets/charts.py); многолинейные рисуются здесь в том же стиле. Синтетические
ряды запрещены — рисуется только то, что лежит в charts.json.

    python3 macro_charts.py --calc out/calc.json --charts out/charts.json --data data --out charts
"""
import argparse, json, os, sys
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def _charts():
    import glob
    roots = glob.glob("/mnt/skills/**/report-format/assets", recursive=True) + ["."]
    for p in roots:
        if os.path.exists(os.path.join(p, "charts.py")):
            sys.path.insert(0, p)
            import charts
            return charts
    raise SystemExit("charts.py набора report-format не найден")


def _lines(CH, path, series, title, recent=None, threshold=None, ylabel=None):
    """Несколько линий одного масштаба: series — список (имя, x, y). Стиль тот же,
    что у band_series набора: первая линия чернилами, остальные — синим и золотым."""
    import matplotlib.pyplot as plt
    цвета = [CH.INK, CH.WARN, CH.GREEN, CH.NAVY]
    fig, ax = plt.subplots(figsize=(6.8, 2.6))
    for i, (имя, x, y) in enumerate(series):
        ax.plot(x, y, color=цвета[i % len(цвета)], lw=2.0 if i == 0 else 1.6,
                ls="-" if i < 3 else (0, (4, 3)), label=имя, zorder=4 - i * 0.1)
    if threshold is not None:
        tv, tl = threshold
        ax.axhline(tv, color=CH.DANGER, lw=1.2, ls=(0, (4, 3)), zorder=5)
        if tl:
            ax.annotate(tl, xy=(series[0][1][0], tv), xytext=(2, 3), textcoords="offset points",
                        fontsize=CH.FS_NOTE, color=CH.DANGER, va="bottom", ha="left")
    if ylabel:
        ax.set_ylabel(ylabel, fontsize=CH.FS_LABEL, color=CH.INK2)
    CH._flat(ax)
    ax.legend(loc="upper left", frameon=False, fontsize=CH.FS_NOTE, ncol=min(3, len(series)))
    ax.set_title(title, loc="left", fontsize=CH.FS_TITLE, fontweight="bold", pad=8)
    fig.tight_layout(); fig.savefig(path, dpi=150, facecolor="white", bbox_inches="tight"); plt.close(fig)


def _panel(CH, path, panels, title, threshold=0.0):
    """Панель малых графиков в ряд: panels — список (имя, x, y). Для однородных
    групп (опросы округов), где пять картинок заменяет одна."""
    import matplotlib.pyplot as plt
    n = len(panels)
    fig, axes = plt.subplots(1, n, figsize=(6.8, 2.3), sharey=False)
    if n == 1:
        axes = [axes]
    for ax, (имя, x, y) in zip(axes, panels):
        ax.plot(x, y, color=CH.INK, lw=1.6)
        if threshold is not None:
            ax.axhline(threshold, color=CH.DANGER, lw=1.0, ls=(0, (4, 3)))
        ax.set_title(имя, loc="left", fontsize=CH.FS_LABEL, fontweight="bold")
        ax.tick_params(axis="x", labelsize=CH.FS_NOTE, labelrotation=0)
        ax.tick_params(axis="y", labelsize=CH.FS_NOTE)
        CH._flat(ax)
        ax.xaxis.set_major_locator(__import__("matplotlib.dates", fromlist=["YearLocator"]).YearLocator())
        ax.xaxis.set_major_formatter(__import__("matplotlib.dates", fromlist=["DateFormatter"]).DateFormatter("%y"))
    fig.suptitle(title, x=0.01, ha="left", fontsize=CH.FS_TITLE, fontweight="bold")
    fig.tight_layout(); fig.savefig(path, dpi=150, facecolor="white", bbox_inches="tight"); plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--calc", default="out/calc.json")
    ap.add_argument("--charts", default="out/charts.json")
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="charts")
    a = ap.parse_args()
    CH = _charts()
    os.makedirs(a.out, exist_ok=True)
    R = json.load(open(a.calc, encoding="utf-8"))
    CJ = json.load(open(a.charts, encoding="utf-8")) if os.path.exists(a.charts) else {}
    O = lambda имя: os.path.join(a.out, имя)

    def _ser(key, years):
        s = CJ.get(key)
        if not s or not s.get("даты"):
            return None
        x = pd.to_datetime(s["даты"]); y = [float(v) for v in s["значения"]]
        m = x >= x[-1] - pd.Timedelta(days=365 * years)
        return list(x[m]), [v for v, ok in zip(y, m) if ok]

    # ── общая картина
    d = R.get("секторы_динамика") or {}
    if d:
        rows = sorted(((k, v.get("месяц")) for k, v in d.items() if v.get("месяц") is not None),
                      key=lambda x: -x[1])
        CH.signed_bars(O("sectors.png"), [r[0] for r in rows], [round(r[1], 2) for r in rows],
                       "Секторы S&P 500 за месяц", unit=" %", highlight_first=False)
    mk = R.get("монте_карло") or {}
    if mk:
        CH.scenario_ranges(O("mc.png"),
                           [("Девять исходов из десяти", mk["p5"], mk["p95"], "blue"),
                            ("Половина исходов", mk["p25"], mk["p75"], "green")],
                           "S&P 500 через квартал: разброс исходов, %")
    r = _ser("CORR_SB", 3)
    if r:
        CH.band_series(O("corr.png"), r[0], r[1], "Корреляция акций и облигаций, 63 дня", recent=63,
                       threshold=(0.0, "выше нуля облигации падают вместе с акциями"))
    r = _ser("REAL_FFR", 10)
    if r:
        CH.band_series(O("realrate.png"), r[0], r[1],
                       "Реальная ставка ФРС: ставка минус базовая инфляция, %", recent=12, threshold=(0.0, "ноль"))
    # эпизоды нынешнего режима: индекс через квартал после начала каждого
    ист = (R.get("широкий_срез") or {}).get("место_в_истории") or {}
    эп = [e for e in ист.get("последние", []) if "S&P 500_через_квартал" in e]
    if эп:
        CH.signed_bars(O("history.png"), ["с " + e["начало"][:7] for e in эп],
                       [e["S&P 500_через_квартал"] for e in эп],
                       "Режим «%s» раньше: S&P 500 через квартал после начала эпизода" % ист.get("режим", ""),
                       unit=" %", highlight_first=False)
    # мир вокруг США: премия Франции к Германии и инфляция еврозоны
    r1, r2 = _ser("OAT_BUND", 5), _ser("EA_HICP_YOY", 5)
    if r1:
        CH.band_series(O("europe.png"), r1[0], r1[1],
                       "Франция платит больше Германии: спред 10-летних, б. п.", recent=12)
    if r2:
        CH.band_series(O("eainfl.png"), r2[0], r2[1], "Инфляция еврозоны, % г/г", recent=12, threshold=(2.0, "цель ЕЦБ"))

    # ── точки внимания и «по поводу»
    r1, r2 = _ser("SPREAD_2Y_SOFR", 5), _ser("SPREAD_2Y_3M", 5)
    if r1 and r2:
        _lines(CH, O("ratepath.png"), [("двухлетка минус SOFR", r1[0], r1[1]), ("двухлетка минус вексель", r2[0], r2[1])],
               "Что рынок закладывает по ставке: спреды двухлетки, п. п.", threshold=(0.0, "пауза"))
    pn = [(имя, *_ser(k, 5)) for k, имя in (("DALLAS", "Даллас"), ("PHILLY", "Филадельфия"), ("EMPIRE", "Нью-Йорк")) if _ser(k, 5)]
    if len(pn) >= 2:
        _panel(CH, O("regional.png"), pn, "Опросы округов ФРС: общая активность, пункты")
    tr = [(имя, *_ser(k, 5)) for k, имя in (("HIRES", "найм"), ("QUITS_L", "уходы по своей воле"), ("LAYOFFS", "увольнения")) if _ser(k, 5)]
    if len(tr) >= 2:
        _lines(CH, O("turnover.png"), tr, "Оборот рынка труда, тыс. человек в месяц")
    ri, rt = _ser("REALINC", 12), _ser("REALINC_TREND", 12)
    if ri and rt:
        _lines(CH, O("income.png"), [("реальный доход без трансфертов", ri[0], ri[1]), ("тренд 2010–2019", rt[0], rt[1])],
               "Реальный доход населения против тренда, млрд $ 2017 года")
    hs, pm = _ser("HOUST", 5), _ser("PERMIT", 5)
    if hs and pm:
        _lines(CH, O("housing.png"), [("начала строительства", hs[0], hs[1]), ("разрешения", pm[0], pm[1])],
               "Жильё: начала строительства и разрешения, тыс. в год")
    r = _ser("NEWHOME", 5)
    if r:
        CH.band_series(O("newhome.png"), r[0], r[1], "Продажи новых домов, тыс. в год", recent=12)
    r = _ser("CIVPART", 20)
    if r:
        ср = sum(r[1]) / len(r[1])
        CH.band_series(O("lfpr.png"), r[0], r[1], "Доля экономически активного населения, %", recent=24,
                       threshold=(round(ср, 1), "средняя за 20 лет"))
    r = _ser("REALPCE", 3)
    if r:
        CH.band_series(O("realpce.png"), r[0], r[1], "Реальные расходы населения, млрд $ 2017 года", recent=6)
    r = _ser("USDJPY", 3)
    if r:
        CH.band_series(O("yen.png"), r[0], r[1], "Иен за доллар", recent=22)
    f = os.path.join(a.data, "fred_DGS30.csv")
    if os.path.exists(f):
        s = pd.read_csv(f, index_col=0, parse_dates=True).iloc[:, 0].dropna()
        s = s[s.index >= s.index[-1] - pd.Timedelta(days=365)]
        CH.band_series(O("ust30.png"), list(s.index), [float(x) for x in s.values],
                       "Доходность тридцатилетних бумаг Казначейства США, %", recent=22)
    r = _ser("DEFICIT12", 10)
    if r:
        CH.band_series(O("deficit.png"), r[0], r[1], "Дефицит бюджета США за скользящие 12 месяцев, млрд $", recent=12)
    r = _ser("TERMPREM", 10)
    if r:
        CH.band_series(O("termprem.png"), r[0], r[1], "Премия за срок в 10-летних бумагах (ACM), п. п.", recent=12,
                       threshold=(0.0, "ноль"))
    print("графики готовы:", ", ".join(sorted(os.listdir(a.out))))


if __name__ == "__main__":
    main()
