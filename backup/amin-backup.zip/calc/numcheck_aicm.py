#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сверка чисел текста выпуска «Цикл сектора ИИ» с расчётом прогона.

Запуск: python3 numcheck_aicm.py <текст выпуска.md> <calc.json>

Проверяются те величины, которые прогон посчитал сам: индекс пузыря, просадки
бумаг корзины и межквартильные размахи исходов. Каждая должна стоять в тексте
дословно. Выход 0 — всё сошлось; выход 1 — расхождение, вёрстка не идёт.
"""
import json
import re
import sys


def norm(t: str) -> str:
    for ch in ("\u00a0", "\u202f", "\u2009"):
        t = t.replace(ch, " ")
    return t.replace("\u2212", "-").replace("−", "-")


def one(x: float) -> str:
    """Число как его печатает выпуск: запятая, один знак, целое без хвоста."""
    v = round(float(x), 1)
    s = ("%.1f" % v).replace(".", ",")
    return s[:-2] if s.endswith(",0") else s


def main() -> int:
    text = norm(open(sys.argv[1], encoding="utf-8").read())
    calc = json.load(open(sys.argv[2], encoding="utf-8"))
    miss = []

    idx = calc.get("индекс_пузыря")
    if idx is not None and one(idx) not in text:
        miss.append("индекс пузыря %s" % one(idx))

    for name, row in (calc.get("рынок") or {}).items():
        v = row.get("просадка_%")
        if v is None:
            continue
        if one(abs(v)) not in text:
            miss.append("просадка %s: %s" % (name, one(abs(v))))

    ep = ((calc.get("эпизоды") or {}).get("полупроводники_просадка_10") or {}).get("диапазоны") or {}
    for group, row in ep.items():
        for edge in ("p25", "p75"):
            v = row.get(edge)
            if v is None:
                continue
            if one(abs(v)) not in text:
                miss.append("размах %s %s: %s" % (group, edge, one(abs(v))))

    if miss:
        print("РАСХОЖДЕНИЕ ЧИСЕЛ — вёрстка не идёт:")
        for m in miss:
            print("  нет в тексте: " + m)
        return 1

    print("числа текста сошлись с расчётом")
    return 0


if __name__ == "__main__":
    sys.exit(main())
