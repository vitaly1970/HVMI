#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""flows_calc.py — расчёт продукта «Потоки в фонды» (код flows), промпт v6.0.

Считает свободный слой недели — то, что берётся кодом без ручного поиска:
позиции участников из отчёта CFTC по трём индексам, системную ликвидность,
маржинальную статистику, наблюдение активных менеджеров, межрыночный контур,
структуру срочности волатильности и перекос опционов. Всё, что промпт относит
к спот-поиску (секторные потоки, розница, обратный выкуп, размещения), модуль
не трогает: там нет открытого канала, и эти строки собирает сам прогон.

Каждое число проходит через журнал out/channels.jsonl с источником и датой:
величина без записи в журнале дальше не передаётся. Неполученный ряд уходит
в «пробелы» с перечнем опрошенных каналов и причиной, а в выпуске не
печатается вовсе — ни строкой, ни пометкой.

Что считается по разделам промпта:
  Р.2  каузальный Z за 252 наблюдения и десятилетний перцентиль на дату среза;
  Р.3  поведение рынка после экстремумов — окна 5, 21 и 63 дня;
  Р.4  та же статистика отдельно выше и ниже 200-дневной средней S&P 500;
  Р.7  долларовая нормировка позиций: контракты × цена индекса × множитель;
  Р.8  межрыночный контур с корреляциями недельных изменений за 63 и 252 дня;
  Р.9  опционный контур: структура срочности и перекос по SPY и QQQ.

Запуск:
    python3 flows_calc.py --cutoff 2026-08-21 --data data --out out
"""

import argparse
import csv
import datetime as dt
import io
import json
import math
import os
import re
import statistics
import time
import urllib.parse
import urllib.request
import zipfile

CALC_VERSION = "6.0.0"

BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36")
# Ловушка канала: FRED отвечает отказом на браузерный заголовок и отдаёт файл
# на заголовок curl. Проверено 26.08.2026.
CURL_UA = "curl/8.5.0"

YAHOO = "https://query1.finance.yahoo.com/v8/finance/chart/%s?range=%s&interval=1d"
STOOQ = "https://stooq.com/q/d/l/?s=%s&i=d"
FRED_CSV = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=%s"
COT_TFF = "https://www.cftc.gov/files/dea/history/fut_fin_txt_%d.zip"
FINRA_MARGIN = "https://www.finra.org/sites/default/files/%d-%02d/margin-statistics.xlsx"
NAAIM_XLSX = "https://naaim.org/wp-content/uploads/2026/01/Exposure-Index-Data.xlsx"
CBOE_CHAIN = "https://cdn.cboe.com/api/global/delayed_quotes/options/%s.json"
DTS_TGA = ("https://api.fiscaldata.treasury.gov/services/api/fiscal_service/v1/"
           "accounting/dts/operating_cash_balance?fields=record_date,close_today_bal,"
           "open_today_bal,"
           "account_type&filter=record_date:gte:%s&page[size]=10000&sort=-record_date")

# Множители пункта фьючерса: контракты разных индексов несравнимы напрямую.
FUT = {"ES": {"рынок": "E-MINI S&P 500", "тикер": "^GSPC", "множитель": 50.0},
       "NQ": {"рынок": "NASDAQ-100 CONSOLIDATED", "тикер": "^NDX", "множитель": 20.0},
       "RTY": {"рынок": "RUSSELL E-MINI", "тикер": "^RUT", "множитель": 50.0}}

FRED_SERIES = {
    "резервы_банков": "WRESBAL",
    "баланс_фрс": "WALCL",
    "обратное_репо": "RRPONTSYD",
    "премия_высокодоходных": "BAMLH0A0HYM2",
    "премия_инвестиционного_уровня": "BAMLC0A0CM",
    "ставка_10_лет": "DGS10",
    "ставка_2_года": "DGS2",
    "курс_доллара": "DTWEXBGS",
    "волатильность": "VIXCLS",
    "волатильность_3м": "VXVCLS",
}

# ----------------------------------------------------------------- журнал

try:
    from amin_run import Log
except Exception:
    class Log(object):
        def __init__(self, out="out", code=None, cutoff=None):
            self.path = os.path.join(out, "channels.jsonl")
            self.code = code
            self.cutoff = str(cutoff)[:10] if cutoff else None
            os.makedirs(out, exist_ok=True)
            open(self.path, "a").close()

        def _w(self, rec):
            rec["ts"] = dt.datetime.now().isoformat(timespec="seconds")
            if self.code:
                rec["продукт"] = self.code
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            return rec

        def get(self, channel, url="", ok=True, note=""):
            return self._w({"вид": "обращение", "канал": channel, "адрес": url,
                            "успех": bool(ok), "пометка": note})

        def series(self, key, channel, last_date="", points=0, note="", layer="быстрый"):
            return self._w({"вид": "ряд", "показатель": key, "канал": channel,
                            "последняя_дата": str(last_date)[:10], "слой": layer,
                            "точек": int(points), "пометка": note})

        def value(self, key, value, source, date, unit="", note=""):
            return self._w({"вид": "значение", "показатель": key, "значение": value,
                            "источник": source, "дата": str(date)[:10],
                            "единица": unit, "пометка": note})

        def gap(self, key, channels=(), reason=""):
            return self._w({"вид": "пробел", "показатель": key,
                            "опрошено": list(channels), "причина": reason})

        def note(self, text):
            return self._w({"вид": "пометка", "текст": text})


# ------------------------------------------------------------------ сеть

def http(url, ua=BROWSER_UA, tries=4, binary=False, timeout=90):
    delay = 1.0
    for _ in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": ua,
                                                       "Accept": "*/*"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                blob = r.read()
            return blob if binary else blob.decode("utf-8", "replace")
        except Exception:
            time.sleep(delay)
            delay = min(delay * 2, 12)
    return None


def cached(path, fn, binary=False):
    if os.path.exists(path):
        mode = "rb" if binary else "r"
        kw = {} if binary else {"encoding": "utf-8", "errors": "replace"}
        return open(path, mode, **kw).read()
    blob = fn()
    if blob is None:
        return None
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if binary:
        open(path, "wb").write(blob)
    else:
        open(path, "w", encoding="utf-8").write(blob)
    return blob


def _date_any(s):
    s = str(s).strip()
    for f in ("%Y-%m-%d", "%m/%d/%Y", "%Y%m%d", "%d.%m.%Y"):
        try:
            return dt.datetime.strptime(s, f).date()
        except ValueError:
            pass
    return None


# ---------------------------------------------------------------- каналы

def yahoo(ticker, data_dir, log=None, rng="15y"):
    safe = ticker.replace("^", "_")
    txt = cached(os.path.join(data_dir, "y_%s.json" % safe),
                 lambda: http(YAHOO % (urllib.parse.quote(ticker), rng)))
    out = {}
    if txt:
        try:
            res = json.loads(txt)["chart"]["result"][0]
            for t, c in zip(res.get("timestamp") or [],
                            res["indicators"]["quote"][0].get("close") or []):
                if c is not None:
                    out[dt.date.fromtimestamp(t)] = float(c)
        except Exception:
            out = {}
    # Ряд из одной точки — это текущая котировка, а не история: такой канал
    # считается недоступным, и в дело идёт запасной.
    if len(out) < 200:
        alt = stooq(ticker, data_dir)
        if len(alt) > len(out):
            if log:
                log.series("цена:" + ticker, "Stooq:" + ticker,
                           max(alt) if alt else "", len(alt),
                           note="замена: Yahoo отдал обрубок")
            return alt
    if log and out:
        log.series("цена:" + ticker, "Yahoo:" + ticker, max(out), len(out))
    elif log:
        log.gap("цена:" + ticker, ["Yahoo:" + ticker, "Stooq:" + ticker],
                "ряда цен не дал ни один канал")
    return out


def stooq(ticker, data_dir):
    code = {"^GSPC": "^spx", "^NDX": "^ndx", "^RUT": "^rut"}.get(ticker, ticker.lower())
    txt = cached(os.path.join(data_dir, "s_%s.csv" % ticker.replace("^", "_")),
                 lambda: http(STOOQ % urllib.parse.quote(code)))
    out = {}
    if not txt:
        return out
    for row in csv.DictReader(io.StringIO(txt)):
        d = _date_any(row.get("Date", ""))
        try:
            v = float(row.get("Close", ""))
        except (TypeError, ValueError):
            continue
        if d:
            out[d] = v
    return out


def fred(series_id, data_dir, log=None, layer="быстрый"):
    txt = cached(os.path.join(data_dir, "fred_%s.csv" % series_id),
                 lambda: http(FRED_CSV % series_id, ua=CURL_UA))
    if log:
        log.get("FRED:" + series_id, FRED_CSV % series_id, ok=bool(txt))
    out = {}
    if not txt:
        return out
    for row in csv.reader(io.StringIO(txt)):
        if len(row) < 2:
            continue
        d = _date_any(row[0])
        try:
            v = float(row[1])
        except (TypeError, ValueError):
            continue
        if d:
            out[d] = v
    if log and out:
        log.series(series_id, "FRED:" + series_id, max(out), len(out), layer=layer)
    return out


def tga_balance(cutoff, data_dir, log=None):
    """Остаток казначейского счёта по ежедневному отчёту казначейства."""
    since = (cutoff - dt.timedelta(days=3650)).isoformat()
    txt = cached(os.path.join(data_dir, "dts_tga.json"),
                 lambda: http(DTS_TGA % since))
    if log:
        log.get("Treasury DTS", DTS_TGA % since, ok=bool(txt))
    out = {}
    if not txt:
        return out
    try:
        rows = json.loads(txt).get("data") or []
    except Exception:
        return out
    for r in rows:
        acc = (r.get("account_type") or "").lower()
        if "closing balance" not in acc and "treasury general account" not in acc:
            continue
        d = _date_any(r.get("record_date", ""))
        raw = r.get("open_today_bal")
        if raw in (None, "", "null"):
            raw = r.get("close_today_bal")
        try:
            v = float(raw)
        except (TypeError, ValueError):
            continue
        if d:
            out[d] = v / 1000.0  # млн → млрд долларов
    if log and out:
        log.series("остаток_казначейского_счёта", "Treasury DTS", max(out), len(out))
    return out


def cot_all(cutoff, data_dir, log=None):
    """Позиции участников по трём индексам: фонды с плечом и управляющие."""
    hits = {k: {} for k in FUT}
    got_files = 0
    for year in range(cutoff.year - 10, cutoff.year + 1):
        path = os.path.join(data_dir, "cot_%d.zip" % year)
        if not os.path.exists(path):
            blob = http(COT_TFF % year, binary=True)
            if blob is None:
                continue
            os.makedirs(data_dir, exist_ok=True)
            open(path, "wb").write(blob)
        try:
            z = zipfile.ZipFile(path)
        except zipfile.BadZipFile:
            continue
        got_files += 1
        with z.open(z.namelist()[0]) as f:
            for r in csv.reader(io.TextIOWrapper(f, "utf-8", "replace")):
                if len(r) < 20:
                    continue
                name = r[0].upper()
                for key, spec in FUT.items():
                    if spec["рынок"] not in name:
                        continue
                    d = _date_any(r[2])
                    if not d or d > cutoff:
                        continue
                    try:
                        oi = float(r[7])
                        am_l, am_s = float(r[11]), float(r[12])
                        lev_l, lev_s = float(r[14]), float(r[15])
                    except (ValueError, IndexError):
                        continue
                    if oi <= 0:
                        continue
                    hits[key][d] = {"открытый_интерес": oi,
                                    "управляющие_нетто": am_l - am_s,
                                    "плечевые_нетто": lev_l - lev_s}
    if log:
        log.get("CFTC отчёт о позициях", COT_TFF % cutoff.year,
                ok=got_files > 0, note="годовых файлов: %d" % got_files)
    return hits


def finra_margin(cutoff, data_dir, log=None):
    """Маржинальный долг и свободные деньги на счетах, месячный ряд."""
    path = os.path.join(data_dir, "margin-statistics.xlsx")
    if not os.path.exists(path):
        blob = None
        d = cutoff
        for _ in range(4):  # файл лежит в папке месяца публикации
            blob = http(FINRA_MARGIN % (d.year, d.month), binary=True)
            if blob:
                break
            d = (d.replace(day=1) - dt.timedelta(days=1))
        if log:
            log.get("FINRA маржа", FINRA_MARGIN % (d.year, d.month), ok=bool(blob))
        if not blob:
            return {}
        os.makedirs(data_dir, exist_ok=True)
        open(path, "wb").write(blob)
    try:
        z = zipfile.ZipFile(path)
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            sx = z.read("xl/sharedStrings.xml").decode("utf-8", "replace")
            shared = re.findall(r"<t[^>]*>(.*?)</t>", sx, re.S)
        sheet = z.read("xl/worksheets/sheet1.xml").decode("utf-8", "replace")
    except Exception:
        return {}
    out = {}
    cell_rx = r'<c[^>]*?(?:\s+t="(\w+)")?[^>]*>(?:<v>(.*?)</v>|<is><t[^>]*>(.*?)</t></is>)?</c>'
    for row in re.findall(r"<row[^>]*>(.*?)</row>", sheet, re.S):
        cells = []
        for typ, v, inline in re.findall(cell_rx, row, re.S):
            if inline:
                cells.append(inline)
            elif typ == "s" and v.isdigit() and int(v) < len(shared):
                cells.append(shared[int(v)])
            else:
                cells.append(v)
        if not cells or not cells[0]:
            continue
        m = re.match(r"^(\d{4})-(\d{2})$", str(cells[0]).strip())
        if not m:
            continue
        nums = []
        for x in cells[1:5]:
            try:
                nums.append(float(x))
            except (TypeError, ValueError):
                nums.append(None)
        out["%s-%s" % (m.group(1), m.group(2))] = {
            "долг": nums[0] if nums else None,
            "свободные": sum(v for v in nums[1:3] if v) or None}
    if log and out:
        log.series("маржинальный_долг", "FINRA:margin-statistics", max(out) + "-01",
                   len(out), layer="медленный", note="лаг публикации около месяца")
    return out


def naaim_index(data_dir, log=None):
    """Наблюдение активных управляющих: недельная доля вложений в акции."""
    path = os.path.join(data_dir, "naaim.xlsx")
    if not os.path.exists(path):
        blob = http(NAAIM_XLSX, binary=True)
        if log:
            log.get("NAAIM", NAAIM_XLSX, ok=bool(blob))
        if not blob:
            return {}
        os.makedirs(data_dir, exist_ok=True)
        open(path, "wb").write(blob)
    try:
        z = zipfile.ZipFile(path)
        sheet = z.read("xl/worksheets/sheet1.xml").decode("utf-8", "replace")
    except Exception:
        return {}
    out = {}
    rows = re.findall(r"<row[^>]*>(.*?)</row>", sheet, re.S)
    for row in rows:
        vals = re.findall(r"<v>(.*?)</v>", row)
        if len(vals) < 2:
            continue
        try:
            serial = float(vals[0])
            mean = float(vals[1])
        except ValueError:
            continue
        if serial < 20000 or serial > 60000:
            continue
        d = dt.date(1899, 12, 30) + dt.timedelta(days=int(serial))
        out[d] = mean
    if log and out:
        log.series("наблюдение_активных_управляющих", "NAAIM:Exposure Index",
                   max(out), len(out))
    return out


def cboe_skew(symbol, data_dir, spot, log=None):
    """Перекос: волатильность пута −5 % минус волатильность колла +5 %."""
    txt = cached(os.path.join(data_dir, "cboe_%s.json" % symbol),
                 lambda: http(CBOE_CHAIN % symbol))
    if log:
        log.get("CBOE:" + symbol, CBOE_CHAIN % symbol, ok=bool(txt))
    if not txt or not spot:
        return None
    try:
        opts = json.loads(txt)["data"]["options"]
    except Exception:
        return None
    exps = sorted({o["option"][len(symbol):len(symbol) + 6] for o in opts
                   if len(o.get("option", "")) > len(symbol) + 6})
    if not exps:
        return None

    def _monthly(tag):
        try:
            d = dt.date(2000 + int(tag[:2]), int(tag[2:4]), int(tag[4:6]))
        except ValueError:
            return None
        return d if d.weekday() == 4 and 15 <= d.day <= 21 else None

    month = [e for e in exps if _monthly(e) and _monthly(e) - dt.date.today() >= dt.timedelta(days=10)]
    near = month[0] if month else exps[0]
    put_t, call_t = spot * 0.95, spot * 1.05
    best_p = best_c = None
    for o in opts:
        tag = o.get("option", "")
        if not tag.startswith(symbol) or tag[len(symbol):len(symbol) + 6] != near:
            continue
        kind = tag[len(symbol) + 6]
        try:
            strike = float(tag[len(symbol) + 7:]) / 1000.0
            iv = float(o.get("iv") or 0)
        except (ValueError, TypeError):
            continue
        if iv <= 0:
            continue
        if kind == "P":
            if best_p is None or abs(strike - put_t) < abs(best_p[0] - put_t):
                best_p = (strike, iv)
        elif kind == "C":
            if best_c is None or abs(strike - call_t) < abs(best_c[0] - call_t):
                best_c = (strike, iv)
    if not best_p or not best_c:
        return None
    return {"экспирация": near, "страйк_пут": best_p[0], "страйк_колл": best_c[0],
            "перекос": round((best_p[1] - best_c[1]) * 100, 2)}


# --------------------------------------------------------------- счётчики

def z_score(series, cutoff, window=252):
    """Каузальный Z: только наблюдения на дату среза и раньше."""
    days = [d for d in sorted(series) if d <= cutoff]
    if len(days) < 30:
        return None
    vals = [series[d] for d in days[-window:]]
    sd = statistics.pstdev(vals)
    if sd == 0:
        return None
    return round((series[days[-1]] - statistics.fmean(vals)) / sd, 2)


def percentile(series, cutoff, years=10):
    """Место последнего значения в десятилетнем ряду, без заглядывания вперёд."""
    start = cutoff - dt.timedelta(days=int(365.25 * years))
    vals = [series[d] for d in sorted(series) if start <= d <= cutoff]
    if len(vals) < 60:
        return None
    cur = vals[-1]
    below = sum(1 for v in vals if v < cur)
    return round(100.0 * below / len(vals), 1)


def level_block(series, cutoff, name, log=None, source="", unit="", years=10):
    """Уровень, недельное изменение, Z и место в истории — одним куском."""
    days = [d for d in sorted(series) if d <= cutoff]
    if not days:
        return None
    last = days[-1]
    week = [d for d in days if d <= last - dt.timedelta(days=7)]
    out = {"значение": round(series[last], 4), "дата": last.isoformat(),
           "z": z_score(series, cutoff), "место_в_истории": percentile(series, cutoff, years)}
    if week:
        out["изменение_за_неделю"] = round(series[last] - series[max(week)], 4)
    if log and source:
        log.value(name, out["значение"], source, last, unit=unit)
    return out


def correlation(a, b, days_back, cutoff):
    """Корреляция недельных изменений двух рядов за отрезок."""
    start = cutoff - dt.timedelta(days=days_back)
    xs, ys = [], []
    for d in sorted(a):
        if not (start <= d <= cutoff):
            continue
        prev = d - dt.timedelta(days=7)
        pa = max([x for x in a if x <= prev], default=None)
        pb = max([x for x in b if x <= prev], default=None)
        if pa is None or pb is None or d not in b:
            continue
        if a[pa] and b[pb]:
            xs.append(a[d] / a[pa] - 1)
            ys.append(b[d] / b[pb] - 1)
    if len(xs) < 10:
        return None
    mx, my = statistics.fmean(xs), statistics.fmean(ys)
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    den = math.sqrt(sum((x - mx) ** 2 for x in xs) * sum((y - my) ** 2 for y in ys))
    return round(num / den, 2) if den else None


def forward_stats(triggers, px, horizons=(5, 21, 63), gap_days=21):
    """Поведение рынка после экстремумов: медиана, квартили и доля роста."""
    days = sorted(px)
    picked, last = [], None
    for d in sorted(triggers):
        if last and (d - last).days < gap_days:
            continue
        if d not in px and not [x for x in days if x >= d]:
            continue
        picked.append(d)
        last = d
    out = {"эпизодов": len(picked), "окна": {}}
    if not picked:
        return out
    for h in horizons:
        rets = []
        for d in picked:
            base_days = [x for x in days if x >= d]
            if not base_days:
                continue
            i = days.index(base_days[0])
            if i + h >= len(days):
                continue
            base, fwd = px[days[i]], px[days[i + h]]
            if base:
                rets.append(100.0 * (fwd / base - 1))
        if len(rets) < 3:
            continue
        rets.sort()
        out["окна"][str(h)] = {
            "медиана": round(statistics.median(rets), 2),
            "нижняя_четверть": round(rets[max(0, len(rets) // 4 - 1)], 2),
            "верхняя_четверть": round(rets[min(len(rets) - 1, 3 * len(rets) // 4)], 2),
            "доля_роста": round(100.0 * sum(1 for r in rets if r > 0) / len(rets), 1),
            "наблюдений": len(rets)}
    # Меньше пяти эпизодов — агрегат не строится, промпт запрещает.
    if out["эпизодов"] < 5:
        out["агрегат"] = "эпизодов меньше пяти, сводных чисел нет"
    return out


def regime(px, cutoff):
    """Режим на дату среза: рынок выше или ниже 200-дневной средней."""
    days = [d for d in sorted(px) if d <= cutoff]
    if len(days) < 200:
        return None, {}
    ma = {}
    vals = [px[d] for d in days]
    for i in range(199, len(days)):
        ma[days[i]] = statistics.fmean(vals[i - 199:i + 1])
    cur = "выше 200-дневной средней" if px[days[-1]] >= ma[days[-1]] else "ниже 200-дневной средней"
    return cur, ma


# ------------------------------------------------------------------ сборка

def run(cutoff, data_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(data_dir, exist_ok=True)
    log = Log(out_dir, code="flows", cutoff=cutoff)
    R = {"версия_расчёта": CALC_VERSION, "срез": cutoff.isoformat()}
    gaps = []

    # --- цены индексов: нужны и сами по себе, и для нормировки позиций
    px = {k: yahoo(spec["тикер"], data_dir, log) for k, spec in FUT.items()}
    spx = px["ES"]
    if not spx:
        raise SystemExit("нет ряда S&P 500: без него не считаются ни режим, ни окна")

    mode, ma200 = regime(spx, cutoff)
    R["режим_рынка"] = mode
    log.value("режим_рынка", mode, "расчёт по ценам S&P 500", cutoff)

    # --- Р.7. Позиции участников в долларах, а не в контрактах
    cot = cot_all(cutoff, data_dir, log)
    R["позиции"] = {}
    for key, spec in FUT.items():
        rows = cot.get(key) or {}
        if not rows:
            gaps.append("позиции по " + key)
            log.gap("позиции по " + key, ["CFTC:fut_fin_txt"], "рынок не найден в архиве")
            continue
        days = sorted(rows)
        last = days[-1]
        price_days = [d for d in sorted(px[key]) if d <= cutoff]
        price = px[key][price_days[-1]] if price_days else None
        block = {"дата_отчёта": last.isoformat(),
                 "открытый_интерес": round(rows[last]["открытый_интерес"])}
        for who in ("плечевые_нетто", "управляющие_нетто"):
            ser = {d: rows[d][who] for d in days}
            b = {"контракты": round(rows[last][who]),
                 "доля_открытого_интереса": round(
                     100.0 * rows[last][who] / rows[last]["открытый_интерес"], 1),
                 "z": z_score(ser, cutoff, window=104),
                 "место_в_истории": percentile(ser, cutoff)}
            if price:
                b["в_долларах_млрд"] = round(
                    rows[last][who] * spec["множитель"] * price / 1e9, 1)
            if len(days) > 1:
                b["изменение_за_неделю_контракты"] = round(
                    rows[last][who] - rows[days[-2]][who])
            block[who] = b
        R["позиции"][key] = block
        log.series("позиции:" + key, "CFTC:fut_fin_txt", last, len(days),
                   layer="медленный", note="недельный отчёт, лаг публикации три дня")
        log.value("плечевые_нетто:" + key, block["плечевые_нетто"]["контракты"],
                  "CFTC Traders in Financial Futures", last, unit="контракт")

    # --- системная ликвидность: баланс минус обратное репо минус счёт казначейства
    ser = {name: fred(sid, data_dir, log,
                      layer="медленный" if name in ("баланс_фрс", "резервы_банков") else "быстрый")
           for name, sid in FRED_SERIES.items()}
    tga = tga_balance(cutoff, data_dir, log)
    # FRED отдаёт баланс и резервы в миллионах — приводим к миллиардам
    for name in ("баланс_фрс", "резервы_банков"):
        if ser.get(name):
            ser[name] = {d: v / 1000.0 for d, v in ser[name].items()}

    R["ликвидность"] = {}
    for name in ("резервы_банков", "баланс_фрс", "обратное_репо"):
        b = level_block(ser[name], cutoff, name, log, source="FRED:" + FRED_SERIES[name],
                        unit="млрд долл.")
        if b:
            R["ликвидность"][name] = b
        else:
            gaps.append(name)
            log.gap(name, ["FRED:" + FRED_SERIES[name]], "ряд не получен")

    if ser["баланс_фрс"] and ser["обратное_репо"] and tga:
        net = {}
        for d in sorted(ser["баланс_фрс"]):
            if d > cutoff:
                continue
            rrp = [x for x in ser["обратное_репо"] if x <= d]
            tg = [x for x in tga if x <= d]
            if not rrp or not tg:
                continue
            net[d] = ser["баланс_фрс"][d] - ser["обратное_репо"][max(rrp)] - tga[max(tg)]
        b = level_block(net, cutoff, "кросс_проверка_ликвидности", log,
                        source="расчёт: баланс ФРС − обратное репо − счёт казначейства",
                        unit="млрд долл.")
        if b:
            R["ликвидность"]["кросс_проверка"] = b
        w = R["ликвидность"].get("резервы_банков")
        if w:
            R["ликвидность"]["чистая_ликвидность"] = dict(w)
            R["ликвидность"]["чистая_ликвидность"]["источник"] = "FRED:WRESBAL"
    else:
        gaps.append("чистая ликвидность")
        log.gap("чистая ликвидность", ["FRED:WALCL", "FRED:RRPONTSYD", "Treasury DTS"],
                "не хватило одного из трёх рядов")

    # --- Р.8. Межрыночный контур с корреляциями недельных изменений
    R["межрыночный_контур"] = {}
    btc = yahoo("BTC-USD", data_dir, log, rng="10y")
    contour = {
        "премия_высокодоходных": ser["премия_высокодоходных"],
        "премия_инвестиционного_уровня": ser["премия_инвестиционного_уровня"],
        "курс_доллара": ser["курс_доллара"],
        "волатильность": ser["волатильность"],
        "биткойн": btc,
    }
    if ser["ставка_10_лет"] and ser["ставка_2_года"]:
        slope = {d: ser["ставка_10_лет"][d] - ser["ставка_2_года"][d]
                 for d in ser["ставка_10_лет"] if d in ser["ставка_2_года"]}
        contour["наклон_кривой"] = slope
    for name, s in contour.items():
        if not s:
            gaps.append(name)
            log.gap(name, ["FRED", "Yahoo"], "ряд не получен")
            continue
        b = level_block(s, cutoff, name, log, source="FRED / Yahoo", unit="")
        if b:
            b["корреляция_63д"] = correlation(s, spx, 63, cutoff)
            b["корреляция_252д"] = correlation(s, spx, 252, cutoff)
            if (b["корреляция_63д"] is not None and b["корреляция_252д"] is not None
                    and b["корреляция_63д"] * b["корреляция_252д"] < 0):
                b["пометка"] = "знак короткой и длинной корреляции разошёлся: смена режима"
            R["межрыночный_контур"][name] = b

    # --- Р.9. Опционный контур
    R["опционный_контур"] = {}
    if ser["волатильность"] and ser["волатильность_3м"]:
        ratio = {d: ser["волатильность"][d] / ser["волатильность_3м"][d]
                 for d in ser["волатильность"] if d in ser["волатильность_3м"]
                 and ser["волатильность_3м"][d]}
        b = level_block(ratio, cutoff, "структура_срочности", log,
                        source="FRED:VIXCLS / VXVCLS", unit="отношение")
        if b:
            b["инверсия"] = b["значение"] > 1
            R["опционный_контур"]["структура_срочности"] = b
    else:
        gaps.append("структура срочности")
        log.gap("структура срочности", ["FRED:VIXCLS", "FRED:VXVCLS"], "ряд не получен")

    for sym, ticker in (("SPY", "SPY"), ("QQQ", "QQQ")):
        prices = yahoo(ticker, data_dir, log, rng="1y")
        spot = prices[max(d for d in prices if d <= cutoff)] if prices else None
        sk = cboe_skew(sym, data_dir, spot, log)
        if sk:
            R["опционный_контур"]["перекос_" + sym] = sk
            log.value("перекос_" + sym, sk["перекос"], "CBOE цепочка опционов",
                      cutoff, unit="пункт волатильности",
                      note="история перекоса недоступна, печатается уровень")
        else:
            gaps.append("перекос опционов " + sym)
            log.gap("перекос опционов " + sym, ["CBOE:" + sym],
                    "цепочка не дала пары страйков около ±5 %")

    # --- маржинальная статистика и наблюдение активных управляющих
    marg = finra_margin(cutoff, data_dir, log)
    if marg:
        keys = sorted(marg)
        cur = keys[-1]
        block = {"месяц": cur, "долг_млн": marg[cur]["долг"]}
        if marg[cur]["свободные"]:
            block["свободные_деньги_млн"] = marg[cur]["свободные"]
        if len(keys) > 1 and marg[keys[-2]]["долг"]:
            block["за_месяц_проц"] = round(
                100.0 * (marg[cur]["долг"] / marg[keys[-2]]["долг"] - 1), 1)
        if len(keys) > 12 and marg[keys[-13]]["долг"]:
            block["за_год_проц"] = round(
                100.0 * (marg[cur]["долг"] / marg[keys[-13]]["долг"] - 1), 1)
        hist = {}
        for k in keys:
            if marg[k]["долг"]:
                y, m = k.split("-")
                hist[dt.date(int(y), int(m), 1)] = marg[k]["долг"]
        block["место_в_истории"] = percentile(hist, cutoff)
        R["маржинальный_долг"] = block
        log.value("маржинальный_долг_млн", marg[cur]["долг"], "FINRA margin statistics",
                  cur + "-01", unit="млн долл.")
    else:
        gaps.append("маржинальная статистика")
        log.gap("маржинальная статистика", ["FINRA:margin-statistics"], "файл не получен")

    naaim = naaim_index(data_dir, log)
    if naaim:
        b = level_block(naaim, cutoff, "наблюдение_активных_управляющих", log,
                        source="NAAIM Exposure Index", unit="%")
        if b:
            R["наблюдение_активных_управляющих"] = b
    else:
        gaps.append("наблюдение активных управляющих")
        # Страница показывает ряд скриптом, отдельного файла выгрузки нет:
        # прямой адрес отвечает «нет такой страницы». Проверено 26.08.2026.
        log.gap("наблюдение активных управляющих", ["NAAIM:Exposure Index"],
                "файла выгрузки на сайте нет, ряд рисуется на странице скриптом")

    # --- Р.3 и Р.4. Поведение рынка после экстремумов, отдельно по режимам
    R["поведение_после_экстремумов"] = {}
    for key in FUT:
        rows = cot.get(key) or {}
        if len(rows) < 60:
            continue
        ser_lev = {d: rows[d]["плечевые_нетто"] / rows[d]["открытый_интерес"] * 100
                   for d in rows}
        vals = sorted(ser_lev.values())
        lo, hi = vals[len(vals) // 20], vals[-max(1, len(vals) // 20)]
        for tag, cond in (("плечевые_на_минимуме", lambda v: v <= lo),
                          ("плечевые_на_максимуме", lambda v: v >= hi)):
            trig = {d for d, v in ser_lev.items() if cond(v)}
            same = {d for d in trig
                    if d in ma200 and ((spx.get(d, 0) >= ma200[d]) ==
                                       (mode == "выше 200-дневной средней"))}
            R["поведение_после_экстремумов"]["%s:%s" % (key, tag)] = {
                "все_режимы": forward_stats(trig, spx),
                "текущий_режим": forward_stats(same, spx)}

    # --- ряды, которых у нас нет свободным каналом: промпт относит их к поиску
    for key, chans, why in (
            ("потоки в фонды по классам", ["ICI:flows/etf_flows/mmf"],
             "выгрузка закрыта, недельные потоки берутся поиском"),
            ("иностранные покупки", ["Treasury TIC"],
             "релиз публикуется таблицами в тексте, свободного канала нет"),
            ("опрос частных инвесторов", ["AAII"], "выгрузка платная"),
            ("обратный выкуп и размещения", ["обзоры банков"],
             "свободного канала нет, собирается поиском")):
        gaps.append(key)
        log.gap(key, chans, why)

    R["пробелы"] = gaps
    R["покрытие"] = round(100.0 * (1 - len(gaps) / (len(gaps) + _counted(R))), 1)

    json.dump(R, open(os.path.join(out_dir, "calc.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    json.dump({"версия_расчёта": CALC_VERSION, "срез": cutoff.isoformat(),
               "режим": mode, "пробелов": len(gaps)},
              open(os.path.join(out_dir, "meta.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    return R


def _counted(R):
    """Сколько показателей реально посчитано — для доли покрытия."""
    n = 0
    for key in ("позиции", "ликвидность", "межрыночный_контур", "опционный_контур"):
        n += len(R.get(key) or {})
    for key in ("маржинальный_долг", "наблюдение_активных_управляющих"):
        if R.get(key):
            n += 1
    return n


def main():
    ap = argparse.ArgumentParser(description="Расчёт продукта «Потоки в фонды»")
    ap.add_argument("--cutoff", required=True, help="дата среза ГГГГ-ММ-ДД")
    ap.add_argument("--data", default="data", help="каталог с забранными файлами")
    ap.add_argument("--out", default="out", help="куда класть calc.json и журнал")
    a = ap.parse_args()
    cut = dt.datetime.strptime(a.cutoff, "%Y-%m-%d").date()
    R = run(cut, a.data, a.out)

    print("готово: flows-%s | режим %s | покрытие %s %%"
          % (a.cutoff, R.get("режим_рынка"), R.get("покрытие")))
    for k, v in (R.get("позиции") or {}).items():
        lev = v["плечевые_нетто"]
        print("  %-4s плечевые %8d контрактов (%s %% ОИ, место %s)"
              % (k, lev["контракты"], lev["доля_открытого_интереса"],
                 lev["место_в_истории"]))
    liq = (R.get("ликвидность") or {}).get("чистая_ликвидность")
    if liq:
        print("  чистая ликвидность %.0f млрд, место %s" %
              (liq["значение"], liq["место_в_истории"]))
    if R.get("пробелы"):
        print("  пробелов: %d" % len(R["пробелы"]))


if __name__ == "__main__":
    main()
