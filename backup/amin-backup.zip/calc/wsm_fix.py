#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""wsm_fix.py — дотягивает инсайдерский ряд понедельно и пересчитывает
термометр, историю и исходы.

Базовый расчёт берёт сделки инсайдеров из квартальных наборов регулятора,
которые отстают на полтора месяца: на срезе 21.08.2026 свежая неделя ряда —
03.07. Недостающие недели лежат в хранилище (ключ `wsm-weeks`), последняя
добирается модулем `wsm_insiders.py`. Здесь они склеиваются, и весь расчёт,
зависящий от инсайдеров, считается заново.
"""
import argparse, json, math, os, sys
import datetime as dt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import amin_run
import wsm_calc as W


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutoff", required=True)
    ap.add_argument("--data", default="data")
    ap.add_argument("--out", default="out")
    ap.add_argument("--new-week", type=float, help="отношение продаж к покупкам свежей недели")
    ap.add_argument("--new-week-date", help="пятница свежей недели")
    a = ap.parse_args()
    cut = dt.date.fromisoformat(a.cutoff)

    vix = W.cboe_series("VIX", a.data)
    v3 = W.cboe_series("VIX3M", a.data)
    v9 = W.cboe_series("VIX9D", a.data)
    skew = W.cboe_series("SKEW", a.data, col=1)
    spx = W.yahoo_series("^GSPC", a.data)
    hyg, lqd = W.yahoo_series("HYG", a.data), W.yahoo_series("LQD", a.data)
    common = [d for d in vix if d in v3 and d in v9]
    volser = {d: vix[d] / (v3[d] / v9[d]) for d in common}
    ratio = {d: hyg[d] / lqd[d] for d in hyg if d in lqd}
    part = W.participation(cut, a.data, skip_fetch=True)

    ins, _ = W.insider_series(cut, a.data)
    было = max(ins)

    # недели из хранилища
    st = amin_run._state_read("wsm-weeks")
    добавлено = []
    if st:
        for w in st["state"]["недели"]:
            d = dt.date.fromisoformat(w["неделя_по"])
            r = w.get("отношение_по_деньгам")
            if d <= cut and r and r > 0 and d not in ins:
                ins[d] = math.log(r)
                добавлено.append(str(d))
    if a.new_week and a.new_week_date:
        d = dt.date.fromisoformat(a.new_week_date)
        if d <= cut:
            ins[d] = math.log(a.new_week)
            добавлено.append(str(d))

    R = json.load(open(os.path.join(a.out, "calc.json"), encoding="utf-8"))
    d = max(ins)
    p, n = W.percentile(ins, ins[d], cut)
    R["компоненты"]["инсайдеры"] = {"значение": round(math.exp(ins[d]), 2),
                                    "логарифм": round(ins[d], 3), "место": p,
                                    "оценка": round(p, 1), "точек": n,
                                    "дата": d.isoformat()}
    parts = {k: v.get("оценка") for k, v in R["компоненты"].items()}
    therm, cover = W.thermometer(parts)
    hist = W.history(volser, skew, ratio, part, ins, cut)
    R["история"] = {x.isoformat(): v for x, v in hist.items()}
    R["исходы"] = W.outcomes(hist, spx, cut, current=therm)
    R["термометр"], R["покрытие"], R["зона"] = therm, cover, W.zone(therm)
    R["чувствительность"] = {k: W.thermometer({q: parts[q] for q in parts if q != k})[0]
                             for k in list(parts)}
    R["инсайдеры_дотянуты"] = {"было_по": было.isoformat(), "стало_по": d.isoformat(),
                               "добавлено_недель": len(добавлено), "недели": добавлено}
    json.dump(R, open(os.path.join(a.out, "calc.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print("инсайдеры: было по %s, стало по %s (+%d недель)" % (было, d, len(добавлено)))
    print("инсайдеры сейчас: отношение %.2f, оценка %.1f" %
          (R["компоненты"]["инсайдеры"]["значение"], R["компоненты"]["инсайдеры"]["оценка"]))
    print("термометр %.1f (%s), покрытие %.0f %%, история по %s, точек %d"
          % (therm, R["зона"], cover, max(hist), len(hist)))
    print("исходы:", json.dumps(R["исходы"], ensure_ascii=False))


if __name__ == "__main__":
    main()
